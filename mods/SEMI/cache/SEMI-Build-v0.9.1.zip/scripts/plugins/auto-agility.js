(function () {
    var id = 'auto-idle-agility';
    var title = 'Auto Idle Agility';
    var desc = 'This will automatically begin idling agiility whenever your character is idle as there are no consequences to running agility courses test';
    var imgSrc = 'assets/media/bank/skillcape_agility.png';
    var agilityIfIdle = function () {
        if (SEMIUtils.currentSkillName() === '' && !game.isUnpausing) {
            startAgility();
        }
    };
    SEMI.add(id, {
        ms: 500,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        onLoop: agilityIfIdle,
    });
})();
