var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var injectDragMenus = function () {
    var prefix = SEMI.ROOT_ID;
    var getEl = function (id) { return SEMIUtils.getElement(id); };
    var sections = [
        'other',
        'socials',
    ];
    var configVersion = 3;
    var menuConfig = { version: configVersion };
    for (var key_1 in SEMI.SIDEBAR_MENUS) {
        var menu = SEMI.SIDEBAR_MENUS[key_1];
        sections.push(menu.ID);
    }
    sections.forEach(function (section) {
        menuConfig[section] = { locked: true, order: [] };
    });
    var orderMenu = function (section) {
        var order = menuConfig[section].order;
        if (order.length === 0) {
            return;
        }
        var menu = getEl("section-" + section + "-inner");
        var menuItems = __spreadArray([], __read(menu.children()));
        var sortedMenu = menuItems.sort(function (menuA, menuB) { return order.indexOf(menuA.id) - order.indexOf(menuB.id); });
        menu.append(sortedMenu);
    };
    var orderMenus = function () {
        sections.forEach(orderMenu);
        lockItems();
    };
    var lockClasses = { false: 'fa-unlock-alt', true: 'fa-lock' };
    var lockMenus = function () {
        sections.forEach(function (x) {
            var state = menuConfig[x].locked;
            getEl("lock-" + x).removeClass(lockClasses[!state]).addClass(lockClasses[state]);
        });
        lockItems();
    };
    var lockMenu = function (x) {
        menuConfig[x].locked = !menuConfig[x].locked;
        lockMenus();
    };
    var lockItems = function () {
        sections.forEach(function (key) {
            var menuItems = getEl("section-" + key + "-inner").children();
            var div = getEl("section-" + key + "-divider");
            if (menuConfig[key].locked) {
                menuItems.addClass('SEMI-locked');
                div.addClass('lock-d-none');
                div.nextAll().addClass('lock-d-none');
            }
            else {
                menuItems.removeClass('SEMI-locked');
                div.removeClass('lock-d-none');
                div.nextAll().removeClass('lock-d-none');
            }
        });
        storeMenuState();
    };
    var makeItemsGhost = function () {
        sections.forEach(function (key) {
            var div = getEl("section-" + key + "-divider");
            div.nextAll().fadeTo(500, 0.5);
            div.prevAll().fadeTo(0.5, 1);
            menuConfig[key].order = __spreadArray([], __read(getEl("section-" + key + "-inner").children())).map(function (x) { return x.id; });
        });
        storeMenuState();
    };
    var loadMenuState = function () {
        var storedMenuConfig = SEMI.getItem('drag-menu-config');
        if (storedMenuConfig !== null) {
            Object.keys(storedMenuConfig).map(function (k) { return (menuConfig[k] = storedMenuConfig[k]); });
            if (!storedMenuConfig.version) {
                var altMagicMenu = 'nav-skill-tooltip-16';
                var altMagicIndex = menuConfig.skills.order.indexOf(altMagicMenu);
                var dividerIndex = menuConfig.skills.order.indexOf(SEMI.ROOT_ID + "-section-skills-divider");
                if (altMagicIndex !== -1 && dividerIndex !== -1 && altMagicIndex > dividerIndex) {
                    menuConfig.skills.order.splice(altMagicIndex, 1);
                    menuConfig.skills.order.splice(dividerIndex, 0, altMagicMenu);
                }
            }
            if (storedMenuConfig.version < 2) {
                menuConfig['auto-skills'].order = menuConfig['auto-skills'].order.map(function (s) {
                    return s.replace('SEMI-menu-skills', 'SEMI-menu-auto-skills');
                });
                menuConfig['auto-combat'].order = menuConfig['auto-combat'].order.map(function (s) {
                    return s.replace('SEMI-menu-combat', 'SEMI-menu-auto-combat');
                });
            }
            menuConfig.version = configVersion;
        }
    };
    var storeMenuState = function () {
        SEMI.setItem('drag-menu-config', menuConfig);
    };
    var skillElements = __spreadArray([], __read($('.nav-main-item'))).filter(function (x) { return x.id.startsWith('nav-skill-tooltip') || x.id === 'farming-glower'; });
    var headers = __spreadArray([], __read($('.nav-main-heading')));
    var combatSkills = skillElements.filter(function (x) { return x.lastElementChild.getAttribute('onClick') === 'changePage(13);'; });
    var nonCombatSkills = skillElements.filter(function (x) { return x.lastElementChild.getAttribute('onClick') !== 'changePage(13);'; });
    var SEMIPlugins = __spreadArray([], __read($("." + prefix + "-button")));
    var otherButtons = __spreadArray([], __read($('.nav-main-item'))).filter(function (x) { return x.id.startsWith(prefix + "-other-"); });
    var socialButtons = __spreadArray([], __read($('.nav-main-item'))).filter(function (x) { return x.id.startsWith(prefix + "-socials-"); });
    var skills = { combat: combatSkills, skills: nonCombatSkills, other: otherButtons, socials: socialButtons };
    var _loop_1 = function (key_2) {
        var menu = SEMI.SIDEBAR_MENUS[key_2];
        skills[menu.ID] = SEMIPlugins.filter(function (x) { return x.id.startsWith(prefix + "-" + menu.ID + "-skill-"); });
    };
    for (var key_2 in SEMI.SIDEBAR_MENUS) {
        _loop_1(key_2);
    }
    loadMenuState();
    var header = function (name) {
        return $(headers.filter(function (x) {
            return (x.id.startsWith(name) ||
                x.innerText.toUpperCase().startsWith(name.toUpperCase().replace('-', ' ')));
        })[0]);
    };
    var makeSortable = function (id) {
        Sortable.create(document.getElementById(id), { onEnd: makeItemsGhost, filter: '.SEMI-locked' });
    };
    var makeDrag = function (name) {
        var fullPrefix = prefix + "-section-" + name;
        if ($("#" + fullPrefix).length !== 1) {
            header(name).before($("<div id=\"" + fullPrefix + "\"><div id=\"" + fullPrefix + "-inner\"></div></div>"));
        }
        $("#" + fullPrefix + "-inner")
            .append(skills[name], $("<div id=\"" + fullPrefix + "-divider\" class=\"nav-main-link nav-compact\"><img class=\"nav-img\" src=\"" + SEMIUtils.iconSrc + "\"><small>Unlocked! Items below this hide when locked.</small></div>"))
            .before(header(name));
        makeSortable(fullPrefix + "-inner");
        addLockIcon(name);
    };
    var addLockIcon = function (name) {
        var el = $("<i class=\"fa fa-lock text-muted ml-1\" id=\"" + prefix + "-lock-" + name + "\"></i>");
        el.on('click', function () { return lockMenu(name); });
        header(name).append(el);
    };
    sections.forEach(function (section) { return makeDrag(section); });
    $("#" + prefix + "-section-combat-inner").before($('#nav-skill-tooltip-69').parent());
    lockMenus();
    orderMenus();
    makeItemsGhost();
    $(".nav-main-heading:contains('Other'):last").remove();
};
