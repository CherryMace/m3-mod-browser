SEMISettingsMigrator = (function () {
    var migrateSettings = function () {
        var currentSettingsVersion = SEMI.getGlobalItem('settings-version');
        if (!currentSettingsVersion) {
            currentSettingsVersion = 0;
        }
        if (currentSettingsVersion < 2) {
            var charID = SEMI.getGlobalItem('previous-character');
            if (!charID) {
                charID = currentCharacter;
            }
            for (var storageKey in SEMI.getSemiData()) {
                if (storageKey != SEMI.LOCAL_SETTINGS_PREFIX + "-previous-character" &&
                    storageKey != SEMI.LOCAL_SETTINGS_PREFIX + "-settings-version" &&
                    !storageKey.startsWith(SEMI.LOCAL_SETTINGS_PREFIX + "-Char")) {
                    console.log(storageKey.substr(SEMI.LOCAL_SETTINGS_PREFIX.length + 1));
                    SEMI.setItem(storageKey.substr(SEMI.LOCAL_SETTINGS_PREFIX.length + 1), SEMI.getGlobalItem(storageKey.substr(SEMI.LOCAL_SETTINGS_PREFIX.length + 1)));
                    SEMI.removeGlobalItem(storageKey.substr(SEMI.LOCAL_SETTINGS_PREFIX.length + 1));
                }
            }
            SEMI.removeGlobalItem('previous-character');
            SEMI.setGlobalItem('settings-version', 2);
        }
    };
    function waitForLoad() {
        if (!SEMI)
            return;
        clearInterval(semiLoader);
        migrateSettings();
    }
    var semiLoader = setInterval(waitForLoad, 50);
})();
