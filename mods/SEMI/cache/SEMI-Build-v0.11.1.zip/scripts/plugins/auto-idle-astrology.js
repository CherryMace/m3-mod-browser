(function () {
    var id = 'auto-idle-astrology';
    var title = 'Auto Idle Astrology';
    var desc = 'This will automatically begin astrology whenever your character is idle. The highest-level constellation available will be used.';
    var imgSrc = 'assets/media/bank/skillcape_astrology.png';
    var astrologyIfIdle = function () {
        if (SEMIUtils.currentSkillName() === '' && !game.isUnpausing) {
            game.astrology.studyConstellationOnClick(Astrology.constellations.slice().reverse().find(function (e) { return skillLevel[22] >= e.level; }));
        }
    };
    SEMI.add(id, {
        ms: 3000,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        onLoop: astrologyIfIdle,
    });
})();
