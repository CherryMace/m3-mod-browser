(function () {
    var id = "living-bank-helper";
    var title = 'Living Bank Helper';
    var desc = 'Displays which items are missing from your bank. Note: If your bank has non-completion items within it, the numbers will look weird when "Only Show Towards Completion" is toggled on.';
    var imgSrc = getItemMedia(CONSTANTS.item.Bank_Slot_Token);
    var emptyObj = { media: 'assets/media/main/question.svg', name: '???' };
    var el = function (i) {
        var empty = !SEMIUtils.isItemFound(i);
        var _a = empty ? emptyObj : items[i], media = _a.media, name = _a.name;
        var e = $("<img id=\"" + id + "-img-" + i + "\" class=\"skill-icon-sm js-tooltip-enable border border-white border-2\" src=\"" + getItemMedia(i) + "\" data-toggle=\"tooltip\" data-html=\"true\" data-placement=\"bottom\" title=\"\" data-original-title=\"" + name + "\">");
        if (empty) {
            e.fadeTo(500, 0.25);
        }
        return e;
    };
    var getMissingItems = function () {
        var onlyShowTowardsCompletion = SEMI.getItem(id + "-towards-completion");
        var bankItemIDs = bank.map(function (x) { return x.id; });
        var allItemIDs = items.map(function (x) { return x.id; });
        var missingIDs = allItemIDs.filter(function (itemID) {
            if (onlyShowTowardsCompletion) {
                return (!bankItemIDs.includes(itemID) &&
                    !items[itemID].ignoreCompletion &&
                    items[itemID].category !== 'Goblin Raid');
            }
            else {
                return !bankItemIDs.includes(itemID) && items[itemID].category !== 'Goblin Raid';
            }
        });
        return missingIDs;
    };
    var getNeededBankSlots = function () {
        var numberOfItemsLeft = getMissingItems().length;
        var openSlotsInBank = getMaxBankSpace() - bank.length;
        return numberOfItemsLeft - openSlotsInBank;
    };
    var autoShow = function () {
        $("#" + id + "-container").html('');
        var missingIDs = getMissingItems();
        for (var i = 0; i < missingIDs.length; i++) {
            $("#" + id + "-container").append(el(missingIDs[i]));
        }
        $("#" + id + "-bank-slots").text(getNeededBankSlots());
        $("#modal-" + id).modal('show');
    };
    var onlyShowTowardsCompletionToggle = function () {
        var onlyShowTowardsCompletion = SEMI.getItem(id + "-towards-completion");
        if (onlyShowTowardsCompletion) {
            $("#" + id + "-towards-completion").addClass('btn-danger');
            $("#" + id + "-towards-completion").removeClass('btn-success');
        }
        else {
            $("#" + id + "-towards-completion").addClass('btn-success');
            $("#" + id + "-towards-completion").removeClass('btn-danger');
        }
        SEMI.setItem(id + "-towards-completion", !onlyShowTowardsCompletion);
        SEMIUtils.customNotify(imgSrc, 'Re-open the window to see the updated listing');
    };
    var injectGUI = function () {
        var x = $('#modal-item-log').clone().first();
        x.attr('id', "modal-" + id);
        $('#modal-item-log').parent().append(x);
        var y = $("#modal-" + id).children().children().children().children('.font-size-sm');
        y.children().children().attr('id', id + "-container");
        $("#modal-" + id + " .block-title").text(title + " Menu");
        var onlyShowTowardsCompletion = SEMI.getItem(id + "-towards-completion");
        var controlSection = $("\n        <div class=\"col-12 bg-gray-400\">\n            <div class=\"flex justify-center\">\n                <div class=\"py-2 px-2\">\n                    <div class=\"row row-deck gutters-tiny\">\n                        <div class=\"col-2 col-md-2\"></div>\n                        <div class=\"col-6 col-md-4\">\n                            <button class=\"btn btn-md btn-" + (onlyShowTowardsCompletion ? 'success' : 'danger') + " SEMI-modal-btn\" id=\"" + id + "-towards-completion\">\n                                Only Show Items Towards Completion\n                            </button>\n                        </div>\n                        <div class=\"col-4 col-md-4 my-1\">\n                            <b>Needed Bank Slots:</b>&nbsp;<div id=\"" + id + "-bank-slots\"></div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>");
        y.before(controlSection);
        var onlyShowTowardsCompletionButton = $("button#" + id + "-towards-completion");
        onlyShowTowardsCompletionButton.on('click', function () { return onlyShowTowardsCompletionToggle(); });
        setTimeout(function () {
            $("#" + id + "-menu-button").on('click', autoShow);
            $("#" + id + "-menu-button").attr('href', null);
        }, 1000);
    };
    SEMI.add(id + '-menu', {
        ms: 0,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        injectGUI: injectGUI,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
    });
})();
