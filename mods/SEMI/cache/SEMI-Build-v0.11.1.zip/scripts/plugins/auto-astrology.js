(function () {
    var id = 'auto-astrology';
    var title = 'Auto Astrology';
    var desc = 'Automatically study the best constellation in Astrology by this logic: If below level 99, the highest-level available. If not and the current constellation is at 99 mastery, the first without 99 mastery if such exists. Otherwise, the last constellation.';
    var imgSrc = 'assets/media/skills/astrology/astrology.svg';
    var astrologyOptimize = function () {
        if (SEMIUtils.currentSkillName() === 'Astrology') {
            var bestMastery = masteryCache[22].levels.findIndex(function (e) { return e < 99; });
            if (skillLevel[22] < 99 && Astrology.constellations.slice().reverse().find(function (e) { return skillLevel[22] >= e.level; }).id !== game.astrology.activeConstellation.id) {
                game.astrology.studyConstellationOnClick(Astrology.constellations.slice().reverse().find(function (e) { return skillLevel[22] >= e.level; }));
            }
            else if (masteryCache[22].levels[game.astrology.activeConstellation.id] === 99 && bestMastery !== -1) {
                game.astrology.studyConstellationOnClick(Astrology.constellations[bestMastery]);
            }
            else if (Astrology.constellations.length - 1 !== game.astrology.activeConstellation.id && bestMastery === -1) {
                game.astrology.studyConstellationOnClick(Astrology.constellations.slice().reverse()[0]);
            }
        }
    };
    SEMI.add(id, {
        ms: 3000,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        onLoop: astrologyOptimize,
    });
})();
