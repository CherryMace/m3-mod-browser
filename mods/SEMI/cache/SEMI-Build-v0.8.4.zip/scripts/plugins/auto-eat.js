(function () {
    var id = 'auto-eat';
    var title = 'AutoEat';
    var desc = "AutoEat in combat will still only eat when your HP is below calculated max hit, but now it will eat to nearly full health instead of just to the max hit value. It eats with efficiency in mind, so it won't eat food if your food healing would cause overhealing. However, it will still eat if you are at risk of dying from max hit near full health, ignoring this efficiency rule. This makes it a little more viable for the v0.16+ combat eating changes. Suggestion: large quantities of low-healing food for maximum efficiency of this bot. Also, if you don't have dungeon equipment swapping and you run out of food without AutoRun also enabled in a dungeon, you will just die.";
    var imgSrc = 'assets/media/shop/autoeat.svg';
    var isInCombat = function () { return player.manager.isInCombat; };
    var shouldBeEating = function () {
        var hp = SEMIUtils.currentHP();
        var hpmax = SEMIUtils.maxHP();
        var hpdeficit = hpmax - hp;
        var currentFood = SEMIUtils.currentFood();
        var hpfood = numberMultiplier * currentFood.item.healsFor;
        var adjustedMaxHit = SEMIUtils.adjustedMaxHit();
        var maxHitEatingCase = hp <= adjustedMaxHit && isInCombat();
        var thievingMaxHit = game.thieving.isActive ? game.thieving.currentNPC.maxHit * numberMultiplier : 0;
        var generalEatingCase = (hpdeficit > hpfood || hp <= thievingMaxHit) && !SEMIUtils.isCurrentSkill('Hitpoints');
        var haveFoodEquipped = currentFood.quantity > 0;
        var eatingCase = (maxHitEatingCase || generalEatingCase) && haveFoodEquipped;
        var logItAll = function () {
            console.log('hp', hp, 'hpmax', hpmax, 'hpdeficit', hpdeficit, 'currentFood', currentFood, 'hpfood', hpfood, 'adjustedMaxHit', adjustedMaxHit, 'maxHitEatingCase', maxHitEatingCase, 'thievingMaxHit', thievingMaxHit, 'generalEatingCase', generalEatingCase, 'eatingCase', eatingCase);
        };
        return eatingCase;
    };
    var autoEat = function () {
        if (shouldBeEating()) {
            player.eatFood();
            if (!SEMIUtils.isCurrentSkill('Hitpoints'))
                return;
            var i = 0;
            while (shouldBeEating()) {
                i++;
                if (i > 999) {
                    console.error('Infinite loop inside AutoEat! Please report this to TheAlpacalypse on discord ASAP');
                    break;
                }
                player.eatFood();
            }
        }
        if (SEMIUtils.currentFood().quantity >= 1) {
            return;
        }
        var isInDungeon = player.manager.areaData.type === 'Dungeon';
        var characterHasDungeonEquipmentSwap = player.modifiers.dungeonEquipmentSwapping === 1;
        if (SEMIUtils.currentFood().quantity === 0 && isInDungeon && !characterHasDungeonEquipmentSwap) {
            return;
        }
        for (var i = 0; i < player.food.slots.length; i++) {
            if (player.food.slots[i].quantity > 0) {
                return player.selectFood(i);
            }
        }
    };
    var onEnable = function () {
        var hpmax = SEMIUtils.maxHP();
        var adjustedMaxHit = SEMIUtils.adjustedMaxHit();
        if (hpmax <= adjustedMaxHit) {
            SEMIUtils.customNotify('assets/media/monsters/ghost.svg', "WARNING: You are engaged with an enemy that can one-hit-kill you. \n Its damage-reduction-adjusted max hit is at or above your max HP. \n This script can't save you now.", { duration: 10000 });
        }
    };
    SEMI.add(id, {
        ms: 100,
        onLoop: autoEat,
        onEnable: onEnable,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
        title: title,
        imgSrc: imgSrc,
        desc: desc,
    });
})();
