var _this = this;
(function () {
    var id = 'auto-smith-bars';
    var title = 'AutoSmith Bars';
    var desc = 'AutoSmith Bars will cycle through your smithing bars and smelt those you have materials for.';
    var imgSrc = 'assets/media/bank/dragonite_bar.png';
    var skill = 'Smithing';
    var config = {
        ignoreIron: false,
    };
    var bars = smithingSelectionTabs[0].recipes;
    var barTypeCount = 0;
    var findBarIndex = function (bar) { return _this.smithingItems.findIndex(function (y) { return y.smithingID === bar.smithingID; }); };
    var getBarTypes = function () {
        barTypes = bars.map(findBarIndex).sort();
    };
    var barTypes = [];
    var getItemId = function () { return _this.smithingItems[barTypes[barTypeCount]].itemID; };
    var moveToNext = function () {
        barTypeCount = (barTypeCount + 1) % barTypes.length;
        selectSmith(barTypes[barTypeCount]);
    };
    var autoSmithBars = function () {
        smithingSelectionTabs.forEach(function (tab) {
            tab.hide();
        });
        smithingSelectionTabs[0].show();
        var ignoringIron = SEMI.getValue(id, 'ignoreIron') && _this.smithingItems[barTypes[barTypeCount]].name === 'Iron Bar';
        if (smithingArtisanMenu.noneSelected) {
            selectSmith(0);
        }
        for (var _ in barTypes) {
            if (!checkSmithingReq(getItemId()) || ignoringIron) {
                moveToNext();
            }
        }
        if (!SEMIUtils.isCurrentSkill(skill)) {
            startSmithing(true);
        }
    };
    var onDisable = function () {
        SEMIUtils.stopSkill(skill);
    };
    var hasConfig = true;
    var configMenu = "<div class=\"form-group\">\n        <div class=\"custom-control custom-switch mb-1\">\n            <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + id + "-iron-toggle\" name=\"" + id + "-iron-toggle\">\n            <label class=\"custom-control-label\" for=\"" + id + "-iron-toggle\">\n                Ignore Iron (for Steel smelting)\n            </label>\n        </div>\n    </div>";
    var saveConfig = function () {
        var toggled = $("#" + id + "-iron-toggle").prop('checked');
        SEMI.setValue(id, 'ignoreIron', toggled);
        SEMI.setItem(id + "-config", SEMI.getValues(id));
        SEMIUtils.customNotify(imgSrc, 'AutoSmith Bars config saved!');
    };
    var updateConfig = function () {
        $("#" + id + "-iron-toggle").prop('checked', SEMI.getValue(id, 'ignoreIron'));
    };
    SEMI.add(id, {
        onLoop: autoSmithBars,
        onEnable: getBarTypes,
        onDisable: onDisable,
        config: config,
        hasConfig: hasConfig,
        configMenu: configMenu,
        saveConfig: saveConfig,
        updateConfig: updateConfig,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        skill: skill,
    });
})();
