var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var _this = this;
(function () {
    var isChrome = navigator.userAgent.match('Chrome');
    var isFirefox = navigator.userAgent.match('Firefox');
    if (!isChrome && !isFirefox) {
        return alert('SEMI is only officially supported on Firefox and Chrome. To try on another browser, you must modify the main function in SEMI.js. The addon will not load otherwise.');
    }
    var getRuntime = function () { return (isChrome ? chrome : browser).runtime; };
    var getURL = function (name) { return getRuntime().getURL(name); };
    var exists = function (id) { return document.contains(document.getElementById(id)); };
    var addScript = function (name, scriptID, async) {
        if (async === void 0) { async = false; }
        var script = document.createElement('script');
        script.src = getURL(name);
        script.setAttribute('id', scriptID);
        if (async) {
            script.setAttribute('async', 'true');
        }
        document.body.appendChild(script);
    };
    var addSemiVersion = function (version) {
        var script = document.createElement('script');
        script.setAttribute('id', 'semiVersion');
        script.innerText = "const SEMI_VERSION='" + version + "';";
        document.body.prepend(script);
    };
    var replaceScript = function (name, scriptID, async) {
        if (async === void 0) { async = false; }
        var el = document.getElementById(scriptID);
        if (exists(scriptID)) {
            el.remove();
        }
        addScript(name, scriptID, async);
    };
    var addPlugin = function (name) {
        replaceScript("scripts/plugins/" + name + ".js", "SEMI-" + name, true);
    };
    var addSemiLib = function (name) {
        replaceScript("scripts/semi/" + name + ".js", "SEMI-" + name);
    };
    var createImage = function (url, imgId) {
        var img = document.createElement('img');
        img.src = getURL(url);
        img.id = imgId;
        img.height = 32;
        img.width = 32;
        return img;
    };
    if (exists('semiVersion')) {
        return alert('SEMI just tried to load, but found that SEMI already exists on the page. This may mean your browser automatically updated the extension and you need to refresh to finish the update!');
    }
    var autoNames = [
        'bonfire',
        'mine',
        'runecraft',
        'agility',
        'sell-gems',
        'master',
        'smith',
        'sell',
        'slayer',
        'slayer-skip',
        'open',
        'bury',
        'equip',
        'loot',
        'farm',
        'lute',
        'eat',
        'run',
    ];
    var pluginNames = __spreadArray(__spreadArray([], __read(autoNames.map(function (name) { return "auto-" + name; }))), [
        'mastery-enhancements',
        'eta',
        'drop-chances',
        'ore-in-bank',
        'calc-to-level',
        'destroy-crops',
        'xp-per-hour',
        'save-on-close',
        'sort-override',
        'living-bank-helper',
    ]);
    var libNames = ['fold-menus', 'drag-menus', 'menus'];
    var preloadedNames = ['event-bus', 'settings-migrator', 'injections'];
    var checkLoaded = function () { return __awaiter(_this, void 0, void 0, function () {
        var accountName, isCharacterSelected, navbar, semiVersion, semiHeading, coreInjectionPromise;
        return __generator(this, function (_a) {
            accountName = document.getElementById('account-name');
            if (!accountName) {
                return [2];
            }
            isCharacterSelected = accountName.innerText.length > 0;
            if (!isCharacterSelected) {
                return [2];
            }
            clearInterval(preLoader);
            navbar = document.getElementsByClassName('nav-main')[0];
            semiVersion = getRuntime().getManifest().version;
            addSemiVersion(semiVersion);
            semiHeading = document.createElement('li');
            semiHeading.className = 'nav-main-heading';
            navbar.appendChild(semiHeading);
            semiHeading.style.fontSize = '12pt';
            semiHeading.style.color = 'white';
            semiHeading.style.textTransform = 'none';
            semiHeading.textContent = " SEMI v" + semiVersion;
            semiHeading.title = 'Scripting Engine for Melvor Idle';
            semiHeading.id = 'SEMI-heading';
            semiHeading.insertBefore(createImage('icons/border-48.png', 'SEMI-menu-icon'), semiHeading.childNodes[0]);
            coreInjectionPromise = new Promise(function (resolve, reject) {
                replaceScript('scripts/core.js', 'semi-inject-core');
                setTimeout(function () { return resolve(true); }, 250);
            });
            coreInjectionPromise.then(function (res) { return (res !== true ? console.error('BADS!') : console.log('good')); });
            replaceScript('scripts/utils.js', 'semi-inject-utils');
            preloadedNames.forEach(addSemiLib);
            return [2];
        });
    }); };
    var preLoader = setInterval(checkLoaded, 500);
    var loadingTimer = function (fn, ms) {
        return function (pluginName, i) {
            setTimeout(function () {
                fn(pluginName);
            }, i * ms);
        };
    };
    var loadPlugins = function () {
        if (!exists('SEMI-canary')) {
            return;
        }
        clearInterval(pluginLoader);
        libNames.forEach(addSemiLib);
        pluginNames.forEach(loadingTimer(addPlugin, 1));
    };
    var pluginLoader = setInterval(loadPlugins, 50);
})();
