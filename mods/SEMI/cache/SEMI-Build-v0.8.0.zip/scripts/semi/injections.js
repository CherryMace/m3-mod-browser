SEMIInjections = (function () {
    var doInjections = function () {
        injectLoadGameRaw();
        injectAddItemToBank();
    };
    var injectAddItemToBank = function () {
        if (typeof addItemToBank === 'undefined') {
            console.error('addItemToBank cannot be found!');
            return;
        }
        var orgAddItemToBank = addItemToBank;
        addItemToBank = function (itemID, quantity, found, showNotification, ignoreBankSpace) {
            if (found === void 0) { found = true; }
            if (showNotification === void 0) { showNotification = true; }
            if (ignoreBankSpace === void 0) { ignoreBankSpace = false; }
            if (showNotification)
                itemNotify(itemID, quantity);
            if (SEMIEventBus.AddItemToBankPre(itemID, quantity, found, showNotification, ignoreBankSpace)) {
                return true;
            }
            var result = orgAddItemToBank(itemID, quantity, found, false, ignoreBankSpace);
            if (!result) {
                return result;
            }
            SEMIEventBus.AddItemToBankPost(itemID, quantity, found, showNotification, ignoreBankSpace);
            return result;
        };
    };
    var injectLoadGameRaw = function () {
        if (typeof loadGameRaw === 'undefined') {
            console.error('loadGameRaw cannot be found!');
            return;
        }
        var orgLoadGameRaw = loadGameRaw;
        loadGameRaw = function (save) {
            var savegame = getSaveJSON(save);
            var semiKeys = 0;
            for (var storageKey in savegame) {
                if (storageKey.startsWith(SEMI.LOCAL_SETTINGS_PREFIX + "-") && storageKey !== savegame[storageKey]) {
                    semiKeys++;
                    localStorage.setItem(storageKey, JSON.stringify(savegame[storageKey]));
                }
            }
            console.log("Loaded SEMI Data from Cloud Save. Found " + semiKeys + " items.");
            orgLoadGameRaw(save);
        };
    };
    function waitForLoad() {
        if (!SEMI)
            return;
        clearInterval(semiLoader);
        doInjections();
    }
    var semiLoader = setInterval(waitForLoad, 50);
})();
