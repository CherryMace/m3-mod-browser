var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
(function () {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j;
    var id = 'auto-mine';
    var title = 'AutoMine';
    var desc = "AutoMine will mine highest XP ore first automatically. SEMI's version will not switch ores until mining action is complete. You can set your mining priorities by dragging and dropping in the Mining page while the script is running.";
    var imgSrc = 'assets/media/shop/pickaxe_dragon.svg';
    var skill = 'Mining';
    var menuConfig = {};
    var storeConfig = function () {
        SEMI.setItem('AM-priority-config', menuConfig);
    };
    var storeAutoMineOrder = function () {
        var menu = $('#SEMI-Auto-Mine-drag-div');
        menuConfig['AM'].order = __spreadArray([], __read(menu.children())).map(function (x) { return x.id; });
        storeConfig();
        orderMenu();
    };
    var indexOrInf = function (arr) { return function (el) {
        var i = arr.indexOf(el);
        return i === -1 ? Infinity : i;
    }; };
    var orderMenu = function () {
        var menu = $('#SEMI-Auto-Mine-drag-div');
        var order = menuConfig['AM'].order;
        if (order.length === 0) {
            return;
        }
        var menuItems = __spreadArray([], __read(menu.children()));
        var indexOf = indexOrInf(order);
        var sortedMenu = menuItems.sort(function (menuA, menuB) { return indexOf(menuA.id) - indexOf(menuB.id); });
        menu.append(sortedMenu);
    };
    var injectAutoMineGUI = function () {
        if ($("#" + id).length) {
            return;
        }
        menuConfig['AM'] = { coalRatio: 'default', order: [] };
        var storedMenuConfig = SEMI.getItem('AM-priority-config');
        if (storedMenuConfig !== null) {
            menuConfig['AM'] = storedMenuConfig['AM'];
        }
        var ores = [
            'copper',
            'tin',
            'iron',
            'coal',
            'silver',
            'gold',
            'mithril',
            'adamantite',
            'runite',
            'dragonite',
            'rune_essence',
        ];
        var createDragDiv = function (i) {
            var title = ores[i].charAt(0).toUpperCase() + ores[i].slice(1) + " Ore";
            var src = "assets/media/skills/mining/rock_" + ores[i] + ".svg";
            if (i === 10) {
                title = 'Rune Essence';
                src = "assets/media/bank/" + ores[i] + ".png";
            }
            return "<div id=\"AutoMineDrag" + i + "\" class=\"AMbtn btn btn-outline-primary\" style=\"padding: 2px ; margin: 2px;\" data-tippy-content=\"" + title + "\"><img src=\"" + src + "\" width=\"36\" height=\"36\"></div>";
        };
        var bars = ['bronze', 'iron', 'steel', 'silver', 'gold', 'mithril', 'adamantite', 'runite', 'dragonite'];
        var createBarButton = function (i) {
            var src = "assets/media/bank/" + bars[i] + "_bar.png";
            if (i === bars.length) {
                src = 'assets/media/shop/pickaxe_dragon.svg';
            }
            return "<div id=\"AMbtn" + i + "\" class=\"AMbtn btn btn-outline-primary\" style=\"padding: 2px ; margin: 2px;\"><img src=\"" + src + "\" width=\"36\" height=\"36\"></div>";
        };
        var createCoalRadioButton = function (value, description, tooltip, defaultOption) {
            if (defaultOption === void 0) { defaultOption = false; }
            var name = id + "-coal-ratio";
            var elementId = description + "-" + value;
            return "\n                <div class=\"custom-control custom-radio custom-control-inline custom-control\">\n                    <input class=\"custom-control-input\" type=\"radio\" id=\"" + elementId + "\" name=\"" + name + "\" value=\"" + value + "\"" + (menuConfig['AM'].coalRatio === value || (defaultOption && !menuConfig['AM'].coalRatio)
                ? ' checked'
                : '') + ">\n                    <label class=\"custom-control-label\" for=\"" + elementId + "\" data-tippy-content=\"" + tooltip + "\">" + description + "</label>\n                </div>";
        };
        var barOptions = "\n            <div class=\"custom-control-inline\">Coal ratio:</div>\n            " + createCoalRadioButton('default', 'Default', 'For smithing without cape or Superheat I-III', true) + "\n            " + createCoalRadioButton('half', 'Half', 'For smithing with cape') + "\n            " + createCoalRadioButton('none', 'None', 'For Superheat IV') + "\n            <div>" + (bars.map(function (_, i) { return createBarButton(i); }).join('') + createBarButton(bars.length)) + "</div>";
        var createBlock = function (title, description, content) {
            return "\n                <div class=\"col-md-6\">\n                    <div class=\"block block-rounded block-link-pop border-top border-mining border-4x\" style=\"padding-bottom: 12px; display: flex; flex-direction: column\">\n                        <div class=\"block-header text-center\"><h3 class=\"block-title\">" + title + "</h3></div>\n                        <div class=\"block-content text-center font-w400 font-size-sm\" style=\"padding-top: 4px;\">" + description + "</div>\n                        <div class=\"block-content text-center\" style=\"padding-top: 12px; margin-top: auto;\">" + content + "</div>\n                    </div>\n                </div>";
        };
        var prioritySetting = createBlock('AutoMine Priority Setting', 'Set priority directly by dragging.<br><-- Highest Priority || Lower Priority -->', "<div id=\"SEMI-Auto-Mine-drag-div\">" + ores.map(function (_, i) { return createDragDiv(i); }).join('') + "</div>");
        var barSelection = createBlock('AutoMine Bar Selection', 'Mine by ratios of resources in your bank. Ex: 4 coal per 1 mithril.<br>Click current selection to de-select and return to priority-based mining.', barOptions);
        var autoMineDiv = "<div id=\"" + id + "\" class=\"row row-deck\">" + prioritySetting + barSelection + "</div>";
        $('#mining-container .row:first').after($(autoMineDiv));
        var _loop_1 = function (i) {
            $("#AMbtn" + i).on('click', function () { return AMselect(i); });
        };
        for (var i = 0; i < bars.length + 1; i++) {
            _loop_1(i);
        }
        for (var i = 0; i < bars.length; i++) {
            $("#AMbtn" + i).attr('data-tippy-content', bars[i].charAt(0).toUpperCase() + bars[i].slice(1) + " Bar");
        }
        $("#AMbtn" + bars.length).attr('data-tippy-content', 'Default AM mineArray setting: prioritize XP');
        $("#" + id + " input[name=\"" + id + "-coal-ratio\"]").change(function () {
            menuConfig['AM'].coalRatio = event.target.value;
            storeConfig();
        });
        var makeSortable = function (id) {
            Sortable.create(document.getElementById(id), {
                animation: 150,
                filter: '.SEMI-locked',
                onEnd: storeAutoMineOrder,
            });
        };
        makeSortable('SEMI-Auto-Mine-drag-div');
        tippy("#" + id + " [data-tippy-content]", { animation: false });
        highlightBarBtn(AMselection);
        orderMenu();
    };
    var ORES = {
        Copper: 0,
        Tin: 1,
        Iron: 2,
        Coal: 3,
        Silver: 4,
        Gold: 5,
        Mithril: 6,
        Adamantite: 7,
        Runite: 8,
        Dragonite: 9,
        RuneEssence: 10,
    };
    var oreIDs = [45, 46, 47, 48, 49, 50, 51, 52, 53, 54];
    var mineArrays = [
        [ORES.Copper, ORES.Tin],
        [ORES.Iron],
        [ORES.Iron, ORES.Coal],
        [ORES.Silver],
        [ORES.Gold],
        [ORES.Mithril, ORES.Coal],
        [ORES.Adamantite, ORES.Coal],
        [ORES.Runite, ORES.Coal],
        [ORES.Dragonite, ORES.Runite, ORES.Coal],
        [
            ORES.Dragonite,
            ORES.Runite,
            ORES.Adamantite,
            ORES.Mithril,
            ORES.Gold,
            ORES.Silver,
            ORES.Coal,
            ORES.Iron,
            ORES.Tin,
            ORES.Copper,
            ORES.RuneEssence,
        ],
        [ORES.RuneEssence],
    ];
    var AMselection = -1;
    var barRatios = [
        (_a = {}, _a[ORES.Copper] = 1, _a[ORES.Tin] = 1, _a),
        (_b = {}, _b[ORES.Iron] = 1, _b),
        (_c = {}, _c[ORES.Iron] = 1, _c[ORES.Coal] = 2, _c),
        (_d = {}, _d[ORES.Silver] = 1, _d),
        (_e = {}, _e[ORES.Gold] = 1, _e),
        (_f = {}, _f[ORES.Mithril] = 1, _f[ORES.Coal] = 4, _f),
        (_g = {}, _g[ORES.Adamantite] = 1, _g[ORES.Coal] = 6, _g),
        (_h = {}, _h[ORES.Runite] = 1, _h[ORES.Coal] = 8, _h),
        (_j = {}, _j[ORES.Dragonite] = 1, _j[ORES.Runite] = 2, _j[ORES.Coal] = 12, _j),
    ];
    var highlightBarBtn = function (n) {
        $('.AMbtn').removeClass('btn-primary');
        $("#AMbtn" + n).addClass('btn-primary');
    };
    var AMselect = function (n) {
        if (n === AMselection) {
            n = -1;
        }
        highlightBarBtn(n);
        AMselection = n;
        if (n !== -1) {
            mineArray = mineArrays[n];
        }
    };
    var onEnable = function () {
        if (!SEMIUtils.isCurrentSkill(skill)) {
            mineRock(0);
        }
        injectAutoMineGUI();
    };
    var onDisable = function () {
        SEMIUtils.stopSkill(skill);
        removeAutoMineGUI();
    };
    var mineArray = [
        ORES.Dragonite,
        ORES.Runite,
        ORES.Adamantite,
        ORES.Mithril,
        ORES.Gold,
        ORES.Silver,
        ORES.Coal,
        ORES.Iron,
        ORES.Tin,
        ORES.Copper,
        ORES.RuneEssence,
    ];
    var autoMine = function (rocks) {
        var e_1, _a, e_2, _b;
        if (rocks === void 0) { rocks = mineArray; }
        if (!SEMIUtils.isCurrentSkill(skill))
            return;
        var swingRatio = Number(document.getElementById("mining-rock-progress-" + currentRock).style.width.split('%')[0]);
        if (AMselection !== 9 && AMselection !== -1) {
            var resourceRatios_1 = [];
            try {
                for (var rocks_1 = __values(rocks), rocks_1_1 = rocks_1.next(); !rocks_1_1.done; rocks_1_1 = rocks_1.next()) {
                    var rock = rocks_1_1.value;
                    if (rock === ORES.Coal && menuConfig['AM'].coalRatio === 'none') {
                        resourceRatios_1[rock] = Infinity;
                    }
                    else {
                        resourceRatios_1[rock] = SEMIUtils.getBankQty(oreIDs[rock]) / barRatios[AMselection][rock];
                        if (rock === ORES.Coal && menuConfig['AM'].coalRatio === 'half') {
                            resourceRatios_1[rock] *= 2;
                        }
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (rocks_1_1 && !rocks_1_1.done && (_a = rocks_1.return)) _a.call(rocks_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            mineArray.sort(function (a, b) { return resourceRatios_1[a] - resourceRatios_1[b]; });
        }
        var order = menuConfig['AM'].order;
        if (order.length !== 0 && AMselection === -1) {
            var indexOf_1 = indexOrInf(order);
            mineArray = [
                ORES.Dragonite,
                ORES.Runite,
                ORES.Adamantite,
                ORES.Mithril,
                ORES.Gold,
                ORES.Silver,
                ORES.Coal,
                ORES.Iron,
                ORES.Tin,
                ORES.Copper,
                ORES.RuneEssence,
            ];
            mineArray.sort(function (a, b) { return indexOf_1("AutoMineDrag" + a) - indexOf_1("AutoMineDrag" + b); });
        }
        try {
            for (var rocks_2 = __values(rocks), rocks_2_1 = rocks_2.next(); !rocks_2_1.done; rocks_2_1 = rocks_2.next()) {
                var rock = rocks_2_1.value;
                if (!SEMIUtils.isCurrentSkill(skill)) {
                    mineRock(rock);
                }
                if (!rockData[rock].depleted && miningData[rock].level <= SEMIUtils.currentLevel(skill)) {
                    if (currentRock !== rock && swingRatio < 10) {
                        mineRock(rock);
                    }
                    return;
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (rocks_2_1 && !rocks_2_1.done && (_b = rocks_2.return)) _b.call(rocks_2);
            }
            finally { if (e_2) throw e_2.error; }
        }
        storeAutoMineOrder();
    };
    var removeAutoMineGUI = function () {
        $("#" + id + " [data-tippy-content]").each(function (_, e) { return e._tippy.destroy(); });
        $("#" + id).remove();
    };
    SEMI.add(id, { ms: 100, onLoop: autoMine, onEnable: onEnable, onDisable: onDisable, desc: desc, title: title, imgSrc: imgSrc, skill: skill });
})();
