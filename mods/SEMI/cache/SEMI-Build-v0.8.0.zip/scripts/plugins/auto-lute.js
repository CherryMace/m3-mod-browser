(function () {
    var id = 'auto-lute';
    var title = 'AutoLute';
    var desc = "AutoLute monitors your combat opponent's health and switches to Lute for the final kill of a dungeon, or the killing blow for normal combat, for the 5x GP reward.";
    var imgSrc = 'assets/media/bank/almighty_lute.png';
    var autoLute = function () {
        var enemyHp = player.manager.enemy.hitpoints;
        var playerMaxHit = player.stats.maxHit;
        var isInDungeon = player.manager.areaData.type === 'Dungeon';
        var dungeon = isInDungeon ? DUNGEONS[player.manager.areaData.id] : undefined;
        var monster = player.manager.enemy.data.id;
        var isFinalMonster = dungeon !== undefined ? monster === dungeon.monsters[dungeon.monsters.length - 1] : false;
        var shouldSwitchToLute = dungeon !== undefined ? isFinalMonster : true;
        var lute = CONSTANTS.item.Almighty_Lute;
        var slot = 'Weapon';
        var wieldingLute = SEMIUtils.currentEquipmentInSlot(slot) === lute;
        var ableToKill = enemyHp > 0 && playerMaxHit >= enemyHp;
        var inCombat = player.manager.isInCombat;
        var newEnemyLoading = player.manager.fightInProgress;
        if (ableToKill &&
            shouldSwitchToLute &&
            !wieldingLute &&
            checkBankForItem(lute) &&
            newEnemyLoading &&
            inCombat) {
            SEMIUtils.equipSwap(lute, slot);
        }
        else if ((enemyHp === 0 || !newEnemyLoading || !inCombat) && SEMIUtils.equipSwapConfig[slot].swapped) {
            SEMIUtils.equipSwap(0, slot);
        }
    };
    SEMI.add(id, {
        ms: 100,
        onLoop: autoLute,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
        title: title,
        imgSrc: imgSrc,
        desc: desc,
    });
})();
