(function () {
    var id = 'auto-run';
    var title = 'AutoRun';
    var desc = 'AutoRun will automatically run from combat if you are out of food, runes, or ammo, or if you can be one-hit-killed by the enemy.';
    var imgSrc = 'assets/media/skills/combat/run.svg';
    var autoRun = function () {
        if (!SEMIUtils.isCurrentSkill('Hitpoints')) {
            return;
        }
        var usingRanged = player.attackType === 'ranged';
        var ammo = player.equipment.slots.Quiver.quantity;
        var hpmax = SEMIUtils.maxHP();
        var deadlyEnemyMaxHit = SEMIUtils.adjustedMaxHit() > hpmax;
        if (deadlyEnemyMaxHit) {
            return runFromCombat("courage: the adjusted max hit of the current enemy (" + SEMIUtils.maxHitOfCurrentEnemy() + " raw DMG, " + SEMIUtils.adjustedMaxHit() + " %reduced DMG) is greater than your max hp! (" + hpmax + " HP)");
        }
        if (player.food.slots[player.food.selectedSlot].quantity < 1) {
            return runFromCombat('food.');
        }
        if (usingRanged && ammo < 1) {
            return runFromCombat('ammo.');
        }
        if (player.attackType === 'magic' &&
            ((!player.usingAncient && !checkRuneCount(0, player.spellSelection.standard, false)) ||
                (player.usingAncient && !checkRuneCount(3, player.spellSelection.ancient, false)))) {
            return runFromCombat('runes.');
        }
    };
    var runFromCombat = function (reason) {
        var today = new Date();
        var date = today.toDateString();
        var time = today.toTimeString().split(' ')[0];
        var dateTime = date + " @ " + time;
        SEMIUtils.stopSkill('Hitpoints');
        SEMIUtils.customNotify(imgSrc, "SEMI: Exited Auto Combat @ " + dateTime + " because " + username + " is out of " + reason, { duration: 15000 });
        console.log("SEMI: Exited Auto Combat @ " + dateTime + " because " + username + " is out of " + reason);
        if (SEMI.isEnabled('auto-slayer')) {
            SEMI.disable('auto-slayer');
        }
    };
    SEMI.add(id, { ms: 500, onLoop: autoRun, pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT, title: title, desc: desc, imgSrc: imgSrc });
})();
