var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
(function () {
    var id = 'auto-runecraft';
    var title = 'AutoRunecraft';
    var desc = 'AutoRunecraft will runecraft runes based on the rune use ratios you select.';
    var imgSrc = 'assets/media/bank/rune_chaos.png';
    var skill = 'Runecrafting';
    var menuConfig = {};
    var defaultRatioConfig = {};
    var MODE_LINEAR = 1;
    var MODE_LOWEST_CAST = 2;
    var MODE_ENDLESS = 3;
    var debugLog = function () {
        var msg = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            msg[_i] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(["[" + title + "]"], __read(msg)));
    };
    var RUNE_DATA = {};
    var RUNE_DATA_ORDER = [];
    runecraftingItems.forEach(function (item, index) {
        var runeItem = items[item.itemID];
        if (runeItem.type == 'Rune' && runeItem.runecraftingID != null) {
            RUNE_DATA[item.itemID] = {
                action: index,
                category: runeItem.runecraftingCategory,
                itemID: item.itemID,
                item: runeItem,
                recipe: item,
            };
            RUNE_DATA_ORDER.push(RUNE_DATA[item.itemID]);
            defaultRatioConfig[runeItem.itemID] = 0;
        }
    });
    RUNE_DATA_ORDER.sort(function (a, b) {
        return a.action + a.category * 1000 > b.action + b.category * 1000 ? 1 : -1;
    });
    var USE_HOOK_SWITCH = true;
    var scriptState = {};
    var getConfig = function () {
        var storedMenuConfig = SEMI.getItem(id + "-config");
        if (storedMenuConfig !== null) {
            Object.keys(defaultRatioConfig)
                .filter(function (itemID) {
                return storedMenuConfig.runeRatio[itemID] == null;
            })
                .forEach(function (itemID) {
                storedMenuConfig.runeRatio[itemID] = 0;
            });
            return storedMenuConfig;
        }
        return {
            runeRatio: defaultRatioConfig,
            craftingMode: MODE_ENDLESS,
            baseCastCount: 10000,
            baseRestockCount: 500,
        };
    };
    var storeConfig = function () {
        SEMI.setItem(id + "-config", menuConfig['ARC']);
    };
    var resetScriptState = function () {
        scriptState.restockEssence = false;
        scriptState.restockRune = null;
        scriptState.switchToRune = null;
    };
    var onEnable = function () {
        resetScriptState();
        injectAutoRunecraftGUI();
    };
    var onDisable = function () {
        resetScriptState();
        SEMIUtils.stopSkill(skill);
        removeAutoRunecraftGUI();
    };
    var injectAutoRunecraftGUI = function () {
        if ($("#" + id).length) {
            return;
        }
        menuConfig['ARC'] = getConfig();
        var createRuneButton = function (item) {
            return "\n            <div id=\"arc-btn-" + item.itemID + "\" class=\"col-sm-6 col-md-3 col-xl-2\">\n                <div class=\"block block-rounded-double bg-combat-inner-dark pl-2 pr-2 pt-1 pb-2 border-top " + (item.category == 0 ? 'border-smithing' : 'border-crafting') + " border-2x\">\n                    <div class=\"row row-deck gutters-tiny\">\n                        <div class=\"col-12\"><small class=\"font-w700 text-left text-combat-smoke m-1\"><img src=\"" + getItemMedia(item.itemID) + "\" class=\"skill-icon-xs mr-1\"> " + item.item.name + "</small></div>\n                        <div class=\"col-12\"><input type=\"text\" class=\"form-control form-control-small\" id=\"arc-ratio-" + item.itemID + "\" placeholder=\"0\"></input></div>\n                        <div class=\"col-12 small pt-1\" style=\"text-align:center;\">\n                            <div class=\"border-right border-smithing border-1x\" style=\"width: 50%;display:inline-block;\">\n                                Quantity:<br><span id=\"arc-view-have-" + item.itemID + "\">" + numberWithCommas(runeCount(item.itemID)) + "</span>\n                            </div>\n                            <div style=\"width: 50%;display:inline-block;\">\n                                Cast Possible:<br><span id=\"arc-view-cast-" + item.itemID + "\">" + runesCastFormat(item.itemID) + "</span>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>";
        };
        var autoRunecraftDiv = "\n                <div id=\"" + id + "\" class=\"col-12\">\n                    <div class=\"block block-rounded block-link-pop border-top border-mining border-4x\" style=\"padding-bottom: 12px; display: flex; flex-direction: column\">\n                        <div class=\"block-header text-center\"><h3 class=\"block-title\">AutoRunecraft Rune Selection</h3></div>\n                        <div class=\"block-content text-center font-w400 font-size-sm\" style=\"padding-top: 4px;\">\n                            Craft by ratios of your selection. Choose the base spell cast count you wish to craft for, then calculate your rune use for each cast and put it into the rune boxes. Will begin mining rune essence if you run out. Combination Runes will craft 500 of the require ingreadients if it runs out to contine crafting them.\n                        </div>\n                        <div class=\"block-content\" style=\"padding-top: 12px; margin-top: auto;\">\n                            <div class=\"row row-deck gutters-tiny\">\n                                <div class=\"col-sm-6 col-md-4\">\n                                    <div class=\"block block-rounded-double bg-combat-inner-dark p-3\">\n                                        <div class=\"border-bottom border-mining border-2x pb-2\">Crafting Mode:</div>\n                                        <div class=\"form-group pt-2 mb-0\">\n                                            <div id=\"arc-cmd-1\" class=\"custom-control custom-radio custom-control-inline custom-control-lg\">\n                                                <input type=\"radio\" class=\"custom-control-input\" id=\"arc-crafting-mode-1\" name=\"arc-craft-mode\" value=\"1\">\n                                                <label class=\"custom-control-label\" for=\"arc-crafting-mode-1\">Linear</label>\n                                            </div>\n                                            <div id=\"arc-cmd-2\" class=\"custom-control custom-radio custom-control-inline custom-control-lg\">\n                                                <input type=\"radio\" class=\"custom-control-input\" id=\"arc-crafting-mode-2\" name=\"arc-craft-mode\" value=\"2\">\n                                                <label class=\"custom-control-label\" for=\"arc-crafting-mode-2\">Lowest Cast</label>\n                                            </div>\n                                            <div id=\"arc-cmd-3\" class=\"custom-control custom-radio custom-control-inline custom-control-lg\">\n                                                <input type=\"radio\" class=\"custom-control-input\" id=\"arc-crafting-mode-3\" name=\"arc-craft-mode\" value=\"3\">\n                                                <label class=\"custom-control-label\" for=\"arc-crafting-mode-3\">Endless Crafting</label>\n                                            </div>\n                                        </div>\n                                    </div>\n                                </div>\n                                <div class=\"col-sm-6 col-md-4\">\n                                    <div class=\"block block-rounded-double bg-combat-inner-dark p-3\">\n                                        <div class=\"border-bottom border-mining border-2x pb-2\">Max Cast: <small>[Linear / Lowest Cast]</small></div>\n                                        <div class=\"form-group pt-2 mb-0\">\n                                            <input type=\"text\" class=\"form-control form-control-small\" id=\"arc-cast-count\" placeholder=\"10000\"></input>\n                                        </div>\n                                    </div>\n                                </div>\n                                <div class=\"col-sm-6 col-md-4\">\n                                    <div class=\"block block-rounded-double bg-combat-inner-dark p-3\">\n                                        <div class=\"border-bottom border-mining border-2x pb-2\">Rune Essence Restock Count:</div>\n                                        <div class=\"form-group pt-2 mb-0\">\n                                            <input type=\"text\" class=\"form-control form-control-small\" id=\"arc-restock-count\" placeholder=\"1000\"></input>\n                                        </div>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"row row-deck gutters-tiny\">\n                                " + RUNE_DATA_ORDER.map(function (runeItem, index) { return createRuneButton(runeItem); }).join('') + "\n                            </div>\n                        </div>\n                    </div>\n                </div>";
        var inputDefaultFill = function () {
            $("#arc-crafting-mode-" + menuConfig['ARC'].craftingMode).prop('checked', true);
            $('#arc-cast-count').val(menuConfig['ARC'].baseCastCount);
            $('#arc-restock-count').val(menuConfig['ARC'].baseRestockCount);
            $.each(menuConfig['ARC'].runeRatio, function (index, value) {
                $("#arc-ratio-" + index + ":text").val(value);
            });
        };
        var inputEventTriggers = function () {
            $('[name=arc-craft-mode]').on('click', function () {
                menuConfig['ARC'].craftingMode = parseInt($(this).val());
                storeConfig();
            });
            $.each(RUNE_DATA, function (index, value) {
                $('#arc-ratio-' + index).on('input', function () {
                    menuConfig['ARC'].runeRatio[index] = parseInt($(this).val());
                    updateRuneCounts(value.itemID);
                    storeConfig();
                });
            });
            $('#arc-cast-count').on('input', function () {
                menuConfig['ARC'].baseCastCount = parseInt($(this).val());
                storeConfig();
            });
            $('#arc-restock-count').on('input', function () {
                menuConfig['ARC'].baseRestockCount = parseInt($(this).val());
                storeConfig();
            });
        };
        var inputAddTippy = function () {
            [
                'Crafts each rune until the Max Cast setting is met before switching.</div>',
                'Crafts each rune until the Max Cast setting is met, switching to the rune that has the lowest amount of cast currently possible.',
                'Crafts runes endlessly following lowest cast amount.',
            ].forEach(function (desc, i) {
                tippy("#arc-cmd-" + (i + 1), {
                    content: "<div class=\"text-center\">" + desc + "</div>",
                    placement: 'top',
                    allowHTML: true,
                    interactive: false,
                    animation: false,
                });
            });
        };
        $('#runecrafting-container .row .col-12:first').after($(autoRunecraftDiv));
        inputDefaultFill();
        inputEventTriggers();
        inputAddTippy();
    };
    var removeAutoRunecraftGUI = function () {
        $("#" + id).remove();
    };
    var updateRuneCounts = function (itemID) {
        $("#arc-view-have-" + itemID).text(numberWithCommas(runeCount(itemID)));
        $("#arc-view-cast-" + itemID).text(runesCastFormat(itemID));
    };
    var runeCount = function (itemID) {
        return SEMIUtils.getBankQty(itemID);
    };
    var runesCast = function (itemID) {
        return menuConfig['ARC'].runeRatio[itemID] > 0
            ? Math.floor(runeCount(itemID) / menuConfig['ARC'].runeRatio[itemID])
            : -1;
    };
    var runesCastFormat = function (itemID) {
        var castAmount = runesCast(itemID);
        return castAmount < 0 ? '-' : numberWithCommas(castAmount);
    };
    var getSelectedRuneID = function () {
        return isRunecrafting ? runecraftingItems[selectedRunecraft].itemID : null;
    };
    var beginScriptCrafting = function (runeItem) {
        runecraftingCategory(runeItem.category);
        selectRunecraft(runeItem.action);
        startRunecrafting(true);
    };
    var autoRunecraft = function () {
        var e_1, _a, e_2, _b;
        try {
            for (var RUNE_DATA_ORDER_1 = __values(RUNE_DATA_ORDER), RUNE_DATA_ORDER_1_1 = RUNE_DATA_ORDER_1.next(); !RUNE_DATA_ORDER_1_1.done; RUNE_DATA_ORDER_1_1 = RUNE_DATA_ORDER_1.next()) {
                var runeItem = RUNE_DATA_ORDER_1_1.value;
                updateRuneCounts(runeItem.itemID);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (RUNE_DATA_ORDER_1_1 && !RUNE_DATA_ORDER_1_1.done && (_a = RUNE_DATA_ORDER_1.return)) _a.call(RUNE_DATA_ORDER_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        var runeEssenceCount = runeCount(CONSTANTS.item.Rune_Essence);
        if (runeEssenceCount === 0) {
            scriptState.restockEssence = true;
            debugLog('Begun Restocking Rune Essence...');
        }
        if (scriptState.restockEssence) {
            var runeEssRestockMin = Math.max(1, menuConfig['ARC'].baseRestockCount);
            debugLog("...Waiting on Rune Essence [" + runeEssenceCount + " / " + runeEssRestockMin + "]...");
            if (runeEssenceCount >= runeEssRestockMin) {
                scriptState.restockEssence = false;
                debugLog('Restocking Rune Essence Finished');
                return;
            }
            else if (currentRock != 10) {
                mineRock(10);
                debugLog('Begin Mining Rune Essence');
                return;
            }
            return;
        }
        var limitedCrafting = menuConfig['ARC'].craftingMode == MODE_LINEAR || menuConfig['ARC'].craftingMode == MODE_LOWEST_CAST;
        var currentRune = getSelectedRuneID();
        if (menuConfig['ARC'].craftingMode == MODE_LINEAR && currentRune != null) {
            var runeCastable = runesCast(currentRune);
            if (runeCastable >= 0 && runeCastable < menuConfig['ARC'].baseCastCount) {
                debugLog("Crafting Linearly, nothing to change... [" + runeCastable + " / " + menuConfig['ARC'].baseCastCount + "]");
                return;
            }
        }
        if (scriptState.restockRune != null) {
            var restockItemQty = runeCount(scriptState.restockRune.itemID);
            debugLog("...Waiting on " + scriptState.restockRune.item.name + " Restock [" + restockItemQty + " / 500]...");
            if (restockItemQty > 500) {
                debugLog('Restocking Rune Finished');
                scriptState.restockRune = null;
                return;
            }
            if (isRunecrafting && currentRune != scriptState.restockRune.itemID) {
                debugLog('Restocking Rune...');
                beginScriptCrafting(scriptState.restockRune);
                return;
            }
            return;
        }
        var lowestRune = null;
        var lowestCast = Number.POSITIVE_INFINITY;
        try {
            for (var RUNE_DATA_ORDER_2 = __values(RUNE_DATA_ORDER), RUNE_DATA_ORDER_2_1 = RUNE_DATA_ORDER_2.next(); !RUNE_DATA_ORDER_2_1.done; RUNE_DATA_ORDER_2_1 = RUNE_DATA_ORDER_2.next()) {
                var runeItem = RUNE_DATA_ORDER_2_1.value;
                if (skillLevel[CONSTANTS.skill.Runecrafting] >= runeItem.recipe.level) {
                    var runeCastable = runesCast(runeItem.itemID);
                    if (runeCastable >= 0) {
                        if (limitedCrafting && runeCastable >= menuConfig['ARC'].baseCastCount) {
                            continue;
                        }
                        if (runeCastable < lowestCast) {
                            lowestCast = runeCastable;
                            lowestRune = runeItem;
                        }
                        if (menuConfig['ARC'].craftingMode == MODE_LINEAR) {
                            break;
                        }
                    }
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (RUNE_DATA_ORDER_2_1 && !RUNE_DATA_ORDER_2_1.done && (_b = RUNE_DATA_ORDER_2.return)) _b.call(RUNE_DATA_ORDER_2);
            }
            finally { if (e_2) throw e_2.error; }
        }
        if (lowestRune == null) {
            if (currentRock != 10) {
                debugLog('No rune to craft, mining Rune Essence...');
                mineRock(10);
            }
            return;
        }
        var craftItemRequirements = lowestRune.item.runecraftReq;
        if (craftItemRequirements.length > 1) {
            debugLog("Checking Combination Rune [" + lowestRune.item.name + "] Requirements");
            for (var i = 1; i < craftItemRequirements.length; i++) {
                var craftRuneItem = craftItemRequirements[i];
                if (runeCount(craftRuneItem.id) < craftRuneItem.qty) {
                    debugLog('Begin Combination Rune Requirements...');
                    scriptState.restockRune = RUNE_DATA[craftRuneItem.id];
                    lowestRune = scriptState.restockRune;
                    break;
                }
            }
        }
        if (lowestRune.itemID == currentRune) {
            debugLog("Already Crafting Lowest Rune [" + lowestRune.item.name + "]");
            return;
        }
        debugLog("Begin Crafting Lowest Rune [" + lowestRune.item.name + "]...");
        beginScriptCrafting(lowestRune);
    };
    SEMI.add(id, {
        ms: 5000,
        onLoop: autoRunecraft,
        onEnable: onEnable,
        onDisable: onDisable,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        skill: skill,
    });
})();
