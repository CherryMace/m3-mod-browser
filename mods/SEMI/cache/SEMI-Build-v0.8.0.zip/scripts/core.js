var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var SEMI = (function () {
    var ROOT_ID = 'SEMI-menu';
    var LOCAL_SETTINGS_PREFIX = 'SEMI';
    var SUPPORTED_GAME_VERSION = 'Alpha v0.22';
    var SIDEBAR_MENUS = {
        TWEAK: {
            ID: 'tweaks',
            Title: 'Quality of Life Improvements that do not automate any game play',
            Header: 'Tweaks',
        },
        AUTO_COMBAT: {
            ID: 'auto-combat',
            Title: undefined,
            Header: 'Auto Combat',
        },
        AUTO_SKILL: {
            ID: 'auto-skills',
            Title: 'One at a time, please! Mixing any two idle skill automations will cause problems as you can only idle one thing at once. Mixing these skill automations with combat is impossible, except for AutoReplant.',
            Header: 'Auto Skills',
        },
    };
    var PLUGIN_TYPE = {
        AUTO_SKILL: SIDEBAR_MENUS.AUTO_SKILL.ID,
        AUTO_COMBAT: SIDEBAR_MENUS.AUTO_COMBAT.ID,
        TWEAK: SIDEBAR_MENUS.TWEAK.ID,
    };
    var setItem = function (id, value, charID) {
        if (charID === void 0) { charID = -1; }
        if (charID == -1) {
            charID = currentCharacter;
        }
        localStorage.setItem(LOCAL_SETTINGS_PREFIX + "-Char" + charID + "-" + id, JSON.stringify(value));
    };
    var setGlobalItem = function (id, value) {
        localStorage.setItem(LOCAL_SETTINGS_PREFIX + "-" + id, JSON.stringify(value));
    };
    var getItem = function (id, charID) {
        if (charID === void 0) { charID = -1; }
        if (charID == -1) {
            charID = currentCharacter;
        }
        return JSON.parse(localStorage.getItem(LOCAL_SETTINGS_PREFIX + "-Char" + charID + "-" + id));
    };
    var getGlobalItem = function (id) {
        return JSON.parse(localStorage.getItem(LOCAL_SETTINGS_PREFIX + "-" + id));
    };
    var removeItem = function (id, charID) {
        if (charID === void 0) { charID = -1; }
        if (charID == -1) {
            charID = currentCharacter;
        }
        localStorage.removeItem(LOCAL_SETTINGS_PREFIX + "-Char" + charID + "-" + id);
    };
    var removeGlobalItem = function (id) {
        localStorage.removeItem(LOCAL_SETTINGS_PREFIX + "-" + id);
    };
    var getSemiData = function () {
        var backupKeyData = {};
        for (var storageKey in localStorage) {
            if (storageKey.startsWith(LOCAL_SETTINGS_PREFIX + "-")) {
                backupKeyData[storageKey] = JSON.parse(localStorage.getItem(storageKey));
            }
        }
        return backupKeyData;
    };
    var getSemiCharacterData = function (charID) {
        if (charID === void 0) { charID = -1; }
        if (charID == -1) {
            charID = currentCharacter;
        }
        var backupKeyData = {};
        for (var storageKey in localStorage) {
            if (storageKey.startsWith(LOCAL_SETTINGS_PREFIX + "-Char" + charID)) {
                backupKeyData[storageKey] = JSON.parse(localStorage.getItem(storageKey));
            }
        }
        return backupKeyData;
    };
    var backupSEMI = function () {
        var backupKeyData = getSemiData();
        $('#exportSEMISettings').text(JSON.stringify(backupKeyData));
        var copyText = document.getElementById('exportSEMISettings');
        copyText.select();
        copyText.setSelectionRange(0, 999969);
        document.execCommand('copy');
        SEMIUtils.customNotify('assets/media/main/settings_header.svg', 'SEMI configs exported to textarea and copied to clipboard!', { duration: 10000 });
    };
    var restoreSEMI = function () {
        if ($('#importSEMISettings').val())
            return;
        var restoredConfig = JSON.parse($('#importSEMISettings').val());
        if (restoredConfig == null || typeof restoredConfig !== 'object')
            return;
        for (var storageKey in restoredConfig) {
            if (storageKey.startsWith(LOCAL_SETTINGS_PREFIX + "-") && storageKey !== restoredConfig[storageKey]) {
                localStorage.setItem(storageKey, JSON.stringify(restoredConfig[storageKey]));
            }
        }
        SEMIUtils.customNotify('assets/media/main/settings_header.svg', 'SEMI configs restored from your import! Refresh to complete the import process.', { duration: 10000 });
    };
    var resetSEMI = function () {
        for (key in localStorage) {
            if (key.startsWith(LOCAL_SETTINGS_PREFIX + "-")) {
                localStorage.removeItem(key);
            }
        }
        SEMIUtils.customNotify('assets/media/main/settings_header.svg', 'SEMI configs erased from your local storage! Refresh to complete the reset process.', { duration: 10000 });
    };
    var mergeOnto = function (x, y) {
        Object.keys(y).forEach(function (key) {
            x[key] = y[key];
        });
    };
    var createElement = function (name, options, children) {
        if (options === void 0) { options = {}; }
        if (children === void 0) { children = []; }
        var x = document.createElement(name);
        x.setAttribute('class', options.class || '');
        mergeOnto(x, options);
        children.forEach(function (child) { return x.appendChild(child); });
        return x;
    };
    var makeMenuItem = function (desc, imgSrc, fName, title, name, rootId, hasConfig, configMenu, configMenuOnShown) {
        if (hasConfig === void 0) { hasConfig = false; }
        if (configMenuOnShown === void 0) { configMenuOnShown = undefined; }
        var imgEl = createElement('img', { src: imgSrc, id: name + "-img", class: 'nav-img' });
        var textEl = createElement('span', { innerHTML: title, class: 'nav-main-link-name' });
        tippy(textEl, {
            content: desc,
            arrow: true,
            placement: 'auto',
        });
        var statusEl = createElement('i', {
            id: name + "-status",
            class: 'fas fa-times text-danger',
            style: 'width: 15px;',
        });
        if (hasConfig) {
            var configBtnEl = createElement('i', {
                id: name + "-config-btn",
                class: "fas fa-cog",
                style: "padding: 13px 0 13px 13px;",
            });
            var configMenuEl = tippy(configBtnEl, {
                content: "<div id=\"" + name + "-config-menu\">\n                    " + configMenu + "\n                </div>\n                <button type=\"button\" id=\"" + name + "-config-save-btn\" class=\"btn btn-sm btn-primary\" onclick=\"SEMI.saveConfigFromMenu('" + name + "');\">\n                    <i class=\"fa fa-check mr-1\"></i>Save\n                </button>",
                allowHTML: true,
                interactive: true,
                appendTo: document.body,
                interactiveBorder: 30,
                trigger: 'click',
                zIndex: 9999,
                placement: 'right',
                onShown: configMenuOnShown,
                maxWidth: 'none',
            });
            configBtnEl.addEventListener('click', function (event) {
                SEMI.updateConfig(name);
                event.preventDefault();
            });
            var buttonEl = createElement('a', {
                href: "javascript:" + fName + ";",
                id: name + "-button",
                class: 'nav-main-link nav-compact',
                style: "padding-left: 5px; padding-right: 10px;",
            }, [statusEl, imgEl, textEl, configBtnEl]);
            var mainEl = createElement('li', { id: rootId + '-skill-' + name, class: "nav-main-item " + ROOT_ID + "-button" }, [buttonEl]);
            return mainEl;
        }
        else {
            var buttonEl = createElement('a', {
                href: "javascript:" + fName + ";",
                id: name + "-button",
                class: 'nav-main-link nav-compact',
                style: "padding-left: 5px;",
            }, [statusEl, imgEl, textEl]);
            var mainEl = createElement('li', { id: rootId + '-skill-' + name, class: "nav-main-item " + ROOT_ID + "-button" }, [buttonEl]);
            return mainEl;
        }
    };
    var plugins = {};
    var pluginNames = [];
    var data = {};
    var add = function (name, options) {
        if (options === void 0) { options = {}; }
        var defaults = {
            onLoop: function () { },
            injectGUI: function () { },
            removeGUI: function () { },
            onToggle: function () { },
            onEnable: function () { },
            onDisable: function () { },
            ms: 1000,
            skill: '',
            statusId: name + "-status",
            title: '',
            desc: '',
            imgSrc: '',
            f: "SEMI.toggle('" + name + "')",
            pluginType: PLUGIN_TYPE.AUTO_SKILL,
            config: {},
            hasConfig: false,
            configMenu: '<div>This is a default config menu!</div>',
            saveConfig: function () { },
            updateConfig: function () { },
            onConfigMenuShown: function () { },
        };
        var opts = __assign(__assign({}, defaults), options);
        data[name] = {};
        setValues(name, opts.config);
        opts.imgSrc = opts.imgSrc === '' && opts.skill !== '' ? SEMIUtils.skillImg(opts.skill) : opts.imgSrc;
        pluginNames.push(name);
        var addToMenu = function () {
            var plugin = plugins[name];
            if (plugin.imgSrc === '') {
                return;
            }
            var menuRootId = ROOT_ID + "-" + plugin.pluginType;
            var pluginEl = makeMenuItem(plugin.desc, plugin.imgSrc, plugin.f, plugin.title, name, menuRootId, plugin.hasConfig, plugin.configMenu, plugin.onConfigMenuShown);
            $("#" + menuRootId + "-section-unsorted").append(pluginEl);
        };
        var removeFromMenu = function () {
        };
        var disable = function () {
            var plugin = plugins[name];
            plugin.enabled = false;
            plugin.onDisable();
            console.log(name + " Disabled!");
            if (plugin.imgSrc !== '') {
                SEMIUtils.customNotify(plugin.imgSrc, plugin.title + " Disabled!", {
                    duration: 1000,
                    lowPriority: true,
                });
            }
            if (plugin.ms !== 0 && plugin.interval) {
                clearInterval(plugin.interval);
            }
            plugin.updateStatus();
            plugin.removeGUI();
        };
        var enable = function () {
            var plugin = plugins[name];
            plugin.enabled = true;
            if (plugin.onEnable() === false) {
                console.log(plugin.title + " failed to start!");
                return false;
            }
            console.log(name + " Enabled!");
            if (plugin.imgSrc !== '') {
                SEMIUtils.customNotify(plugin.imgSrc, plugin.title + " Enabled!", {
                    duration: 1000,
                    lowPriority: true,
                });
            }
            if (plugin.ms !== 0) {
                plugin.interval = setInterval(plugin.onLoop, plugin.ms);
            }
            plugin.onLoop();
            plugin.updateStatus();
        };
        var toggle = function () {
            var plugin = plugins[name];
            if (plugin.skill && !SEMIUtils.isSkillUnlocked(plugin.skill)) {
                SEMIUtils.customNotify(plugin.imgSrc, plugin.title + " cannot be toggled, as the core skill is not unlocked!", { duration: 1000 });
                return;
            }
            plugin.enabled = !plugin.enabled;
            plugin.onToggle();
            plugin.updateStatus();
            if (plugin.enabled) {
                plugin.enable();
                if (plugin.skill !== '') {
                    if (plugin.skill !== 'Slayer' && plugin.skill !== 'Prayer') {
                        SEMIUtils.changePage(plugin.skill);
                    }
                }
                return;
            }
            return plugin.disable();
        };
        var updateStatus = function () {
            setItem(name + "-status", plugins[name].enabled);
            var alternateStatusPlugins = [
                'auto-sell',
                'auto-open',
                'auto-bury',
            ];
            if (alternateStatusPlugins.includes(name)) {
                var updater = function () {
                    $("#" + name + "-status").text(plugins[name].enabled ? 'Enabled' : 'Disabled');
                    $("#" + name + "-menu-status").attr('class', plugins[name].enabled ? 'fas fa-check text-success' : 'fas fa-times text-danger');
                };
                return updater();
            }
            if ($("#" + name + "-status") !== null) {
                $("#" + name + "-status").attr('class', plugins[name].enabled ? 'fas fa-check text-success' : 'fas fa-times text-danger');
            }
        };
        var injectGUI = function () {
            addToMenu();
            opts.injectGUI();
        };
        var removeGUI = function () {
            removeFromMenu();
            opts.removeGUI();
        };
        var useSaved = Boolean(getItem('remember-state'));
        var wasEnabled = Boolean(getItem(name + "-status"));
        var enabled = wasEnabled && useSaved;
        if (enabled) {
            if (name == 'auto-cook') {
                setTimeout(enable, 5000);
            }
            else {
                setTimeout(enable, 1000);
            }
        }
        if (SEMI.getItem(name + "-config") !== null) {
            SEMI.setValues(name, SEMI.getItem(name + "-config"));
        }
        var plugin = __assign(__assign({}, opts), { toggle: toggle, interval: null, enable: enable, disable: disable, updateStatus: updateStatus, injectGUI: injectGUI, removeGUI: removeGUI, enabled: enabled });
        plugins[name] = plugin;
    };
    var injectGUI = function (name) {
        plugins[name].injectGUI();
    };
    var removeGUI = function (name) {
        plugins[name].removeGUI();
    };
    var toggle = function (name) {
        plugins[name].toggle();
    };
    var enable = function (name) {
        plugins[name].enable();
    };
    var disable = function (name) {
        plugins[name].disable();
    };
    var isEnabled = function (name) {
        if (name in plugins) {
            return plugins[name].enabled;
        }
        console.warn("Attempted to check 'isEnabled' of " + name);
    };
    var saveConfigFromMenu = function (name) {
        plugins[name].saveConfig();
    };
    var updateConfig = function (name) {
        plugins[name].updateConfig();
    };
    var setValue = function (name, key, value) {
        data[name][key] = value;
    };
    var getValue = function (name, key) { return data[name][key]; };
    var getValues = function (name) { return data[name]; };
    var setValues = function (name, data) {
        Object.keys(data).forEach(function (key) { return SEMI.setValue(name, key, data[key]); });
    };
    var replaceGameFunc = function (fName, func) {
        var script = document.createElement('script');
        script.setAttribute('id', fName + '-replacement-script');
        script.textContent = func;
        document.body.append(script);
    };
    return {
        add: add,
        toggle: toggle,
        enable: enable,
        disable: disable,
        isEnabled: isEnabled,
        saveConfigFromMenu: saveConfigFromMenu,
        updateConfig: updateConfig,
        setValue: setValue,
        getValue: getValue,
        setValues: setValues,
        getValues: getValues,
        injectGUI: injectGUI,
        removeGUI: removeGUI,
        pluginNames: pluginNames,
        createElement: createElement,
        setItem: setItem,
        getItem: getItem,
        removeItem: removeItem,
        backupSEMI: backupSEMI,
        restoreSEMI: restoreSEMI,
        resetSEMI: resetSEMI,
        ROOT_ID: ROOT_ID,
        PLUGIN_TYPE: PLUGIN_TYPE,
        SUPPORTED_GAME_VERSION: SUPPORTED_GAME_VERSION,
        LOCAL_SETTINGS_PREFIX: LOCAL_SETTINGS_PREFIX,
        SIDEBAR_MENUS: SIDEBAR_MENUS,
        getSemiData: getSemiData,
        getGlobalItem: getGlobalItem,
        setGlobalItem: setGlobalItem,
        removeGlobalItem: removeGlobalItem,
        getSemiCharacterData: getSemiCharacterData,
        replaceGameFunc: replaceGameFunc,
    };
})();
