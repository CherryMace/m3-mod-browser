var autoSellShow = (function () {
    var id = "auto-sell";
    var title = 'AutoSell';
    var desc = 'AutoSell is a script for selling items you no longer want.';
    var imgSrc = 'assets/media/main/gp.svg';
    var faceOpacity = 0.25;
    var hiddenOpacity = 0;
    var isItemEnabledToSell = {};
    var isItemMatchFilter = {};
    var fadeAll = function () {
        for (var i = 0; i < SEMIUtils.itemsLength(); i++) {
            var x = $("#" + id + "-img-" + i);
            if (x.length === 0) {
                continue;
            }
            var shouldBeFaded = !isItemEnabledToSell[i];
            var shouldBeHidden = Object.keys(isItemMatchFilter).length === 0 ? false : !isItemMatchFilter[i];
            var currentState = typeof x.css('opacity') === 'undefined' ? '1' : x.css('opacity');
            var isFaded = currentState === faceOpacity + '';
            var isHidden = currentState === hiddenOpacity + '';
            if (!shouldBeHidden) {
                x.css('pointer-events', '');
            }
            if (shouldBeHidden) {
                if (!isHidden) {
                    x.css('pointer-events', 'none');
                    x.fadeTo(500, hiddenOpacity);
                }
            }
            else if (shouldBeFaded) {
                if (!isFaded) {
                    x.fadeTo(500, faceOpacity);
                }
            }
            else if (isFaded || isHidden) {
                x.fadeTo(500, 1);
            }
        }
    };
    var toggleAutoEnabled = function (i) {
        isItemEnabledToSell[i] = !isItemEnabledToSell[i];
        autoSell();
        fadeAll();
    };
    var el = function (i) {
        var empty = !SEMIUtils.isItemFound(i);
        var name = items[i].name;
        var media;
        if (empty) {
            media = 'assets/media/main/question.svg';
        }
        else {
            media = getItemMedia(i);
        }
        var e = $("<img id=\"" + id + "-img-" + i + "\" class=\"skill-icon-sm js-tooltip-enable border border-white border-2\" src=\"" + media + "\" data-toggle=\"tooltip\" data-html=\"true\" data-placement=\"bottom\" title=\"\" data-original-title=\"" + name + "\">");
        e.on('click', function () { return toggleAutoEnabled(i); });
        return e;
    };
    var autoSell = function () {
        var allButOneIsEnabled = SEMI.getItem(id + "-sell-one");
        for (var i = bank.length - 1; i >= 0; i--) {
            var itemID = bank[i].id;
            if (isItemEnabledToSell[itemID] && SEMI.isEnabled(id)) {
                var qty = void 0;
                if (allButOneIsEnabled) {
                    qty = bank[i].qty - 1;
                }
                else {
                    qty = bank[i].qty;
                }
                if (qty === 0) {
                    continue;
                }
                var gpBefore = gp;
                SEMIUtils.sellItemWithoutConfirmation(itemID, qty);
                SEMIUtils.customNotify(items[itemID].media, "Selling " + numberWithCommas(qty) + " of " + items[itemID].name + " for " + numberWithCommas(gp - gpBefore) + " GP", { lowPriority: true });
            }
        }
    };
    var setupContainer = function () {
        $("#" + id + "-container").html('');
        for (var i = 0; i < SEMIUtils.itemsLength(); i++) {
            $("#" + id + "-container").append(el(i));
        }
        var loadedAutoEnabled = SEMI.getItem(id + "-config");
        if (loadedAutoEnabled !== null) {
            if (Array.isArray(loadedAutoEnabled)) {
                for (var i = 0; i < loadedAutoEnabled.length; i++) {
                    if (loadedAutoEnabled[i]) {
                        isItemEnabledToSell[i] = true;
                    }
                }
            }
            else {
                isItemEnabledToSell = loadedAutoEnabled;
            }
        }
        fadeAll();
    };
    var onDisable = function () {
        $("#" + id + "-status").addClass('btn-danger');
        $("#" + id + "-status").removeClass('btn-success');
    };
    var onEnable = function () {
        $("#" + id + "-status").addClass('btn-success');
        $("#" + id + "-status").removeClass('btn-danger');
        autoSell();
    };
    var autoShow = function () {
        $("#modal-" + id).modal('show');
    };
    var allButOneToggle = function () {
        var allButOneIsEnabled = SEMI.getItem(id + "-sell-one");
        if (allButOneIsEnabled) {
            $("#" + id + "-sell-one").addClass('btn-danger');
            $("#" + id + "-sell-one").removeClass('btn-success');
        }
        else {
            $("#" + id + "-sell-one").addClass('btn-success');
            $("#" + id + "-sell-one").removeClass('btn-danger');
        }
        SEMI.setItem(id + "-sell-one", !allButOneIsEnabled);
    };
    var injectGUI = function () {
        var x = $('#modal-item-log').clone().first();
        x.attr('id', "modal-" + id);
        $('#modal-item-log').parent().append(x);
        var y = $("#modal-" + id).children().children().children().children('.font-size-sm');
        y.children().children().attr('id', id + "-container");
        var allButOne = SEMI.getItem(id + "-sell-one");
        var controlSection = $("\n        <div class=\"col-12 bg-gray-400\">\n            <div class=\"block block-rounded py-2 px-2\">\n                <div class=\"row row-deck gutters-tiny\">\n                <div class=\"col-2 col-md-2\">\n                    <button class=\"btn btn-md btn-danger SEMI-modal-btn\" id=\"" + id + "-status\">Disabled</button>\n                </div>\n                <div class=\"col-2 col-md-2\">\n                    <button class=\"btn btn-md btn-" + (allButOne ? 'success' : 'danger') + " SEMI-modal-btn\" id=\"" + id + "-sell-one\">All But One</button>\n                </div>\n                <div class=\"col-8 col-md-8\">\n                    <input class=\"form-control\" type=\"text\" id=\"" + id + "-filter\" placeholder=\"Search for items ... (text | regex)\">\n                </div>\n                </div>\n            </div>\n        </div>");
        y.before(controlSection);
        var enableAutoButton = $("button#" + id + "-status");
        var enableAllButOneButton = $("button#" + id + "-sell-one");
        var searchInput = $("input#" + id + "-filter");
        enableAutoButton.on('click', function () { return SEMI.toggle("" + id); });
        enableAllButOneButton.on('click', function () { return allButOneToggle(); });
        searchInput.on('change', function (event) {
            var value = event.currentTarget.value;
            if (!value || value.length === 0) {
                isItemMatchFilter = {};
                fadeAll();
                return;
            }
            var _value = RegExp(value.replace(/^\/|\/$/g, ''), 'i');
            isItemMatchFilter = {};
            for (var i = 0; i < SEMIUtils.itemsLength(); i++) {
                var name_1 = items[i].name;
                if (name_1.match(_value)) {
                    isItemMatchFilter[i] = true;
                }
            }
            fadeAll();
        });
        $("#modal-" + id + " .block-title").text(title + " Menu");
        $("#modal-" + id).on('hidden.bs.modal', function () {
            SEMI.setItem(id + "-config", isItemEnabledToSell);
        });
        setupContainer();
        setTimeout(function () {
            $("#" + id + "-menu-button").on('click', autoShow);
            $("#" + id + "-menu-button").attr('href', null);
        }, 1000);
    };
    SEMI.add(id, {
        ms: 50,
        onEnable: onEnable,
        onDisable: onDisable,
        onLoop: autoSell,
        title: title,
        desc: desc,
    });
    SEMI.add(id + '-menu', {
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        injectGUI: injectGUI,
    });
})();
