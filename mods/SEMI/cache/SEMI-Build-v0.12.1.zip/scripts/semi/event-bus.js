var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
SEMIEventBus = (function () {
    var _addItemToBankHandlers = [];
    var RegisterAddItemToBankHandler = function (handler) {
        _addItemToBankHandlers.push(handler);
    };
    var _skillChangeHandlers = [];
    var RegisterSkillChangeHandler = function (handler) {
        _skillChangeHandlers.push(handler);
    };
    var _currentSkill = -1;
    var TriggerSkillChanged = function () {
        var e_1, _a;
        var _prevSkill = _currentSkill;
        _currentSkill = SEMIUtils.currentSkillId();
        try {
            for (var _skillChangeHandlers_1 = __values(_skillChangeHandlers), _skillChangeHandlers_1_1 = _skillChangeHandlers_1.next(); !_skillChangeHandlers_1_1.done; _skillChangeHandlers_1_1 = _skillChangeHandlers_1.next()) {
                var handler = _skillChangeHandlers_1_1.value;
                try {
                    if (handler.HandleSkillChange) {
                        handler.HandleSkillChange(_prevSkill, _currentSkill);
                    }
                }
                catch (e) {
                    console.error("SEMI: SkillChangeHandler Failed.");
                    console.error(e);
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_skillChangeHandlers_1_1 && !_skillChangeHandlers_1_1.done && (_a = _skillChangeHandlers_1.return)) _a.call(_skillChangeHandlers_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
    };
    var checkIfSkillChanged = function () {
        if (SEMIUtils.currentSkillId() != _currentSkill) {
            TriggerSkillChanged();
        }
    };
    var startEventBusTimers = function () {
        if (typeof SEMIUtils === 'undefined' || !SEMIUtils.utilsReady()) {
            return;
        }
        console.log('Starting Event Bus');
        clearInterval(eventBusWaiter);
        setInterval(checkIfSkillChanged, 100);
    };
    var eventBusWaiter = setInterval(startEventBusTimers, 50);
    var AddItemToBankPre = function (itemID, quantity, found, showNotification, ignoreBankSpace) {
        var e_2, _a;
        if (found === void 0) { found = true; }
        if (showNotification === void 0) { showNotification = true; }
        if (ignoreBankSpace === void 0) { ignoreBankSpace = false; }
        try {
            for (var _addItemToBankHandlers_1 = __values(_addItemToBankHandlers), _addItemToBankHandlers_1_1 = _addItemToBankHandlers_1.next(); !_addItemToBankHandlers_1_1.done; _addItemToBankHandlers_1_1 = _addItemToBankHandlers_1.next()) {
                var handler = _addItemToBankHandlers_1_1.value;
                try {
                    if (handler.HandleAddItemToBankPre &&
                        handler.HandleAddItemToBankPre(itemID, quantity, found, showNotification, ignoreBankSpace)) {
                        return true;
                    }
                }
                catch (e) {
                    console.error("SEMI: ItemHandler Failed.");
                    console.error(e);
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_addItemToBankHandlers_1_1 && !_addItemToBankHandlers_1_1.done && (_a = _addItemToBankHandlers_1.return)) _a.call(_addItemToBankHandlers_1);
            }
            finally { if (e_2) throw e_2.error; }
        }
    };
    var AddItemToBankPost = function (itemID, quantity, found, showNotification, ignoreBankSpace) {
        var e_3, _a;
        if (found === void 0) { found = true; }
        if (showNotification === void 0) { showNotification = true; }
        if (ignoreBankSpace === void 0) { ignoreBankSpace = false; }
        try {
            for (var _addItemToBankHandlers_2 = __values(_addItemToBankHandlers), _addItemToBankHandlers_2_1 = _addItemToBankHandlers_2.next(); !_addItemToBankHandlers_2_1.done; _addItemToBankHandlers_2_1 = _addItemToBankHandlers_2.next()) {
                var handler = _addItemToBankHandlers_2_1.value;
                try {
                    if (handler.HandleAddItemToBankPost) {
                        handler.HandleAddItemToBankPost(itemID, quantity, found, showNotification, ignoreBankSpace);
                    }
                }
                catch (e) {
                    console.error("SEMI: ItemHandler Failed.");
                    console.error(e);
                }
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (_addItemToBankHandlers_2_1 && !_addItemToBankHandlers_2_1.done && (_a = _addItemToBankHandlers_2.return)) _a.call(_addItemToBankHandlers_2);
            }
            finally { if (e_3) throw e_3.error; }
        }
    };
    return {
        AddItemToBankPost: AddItemToBankPost,
        AddItemToBankPre: AddItemToBankPre,
        RegisterAddItemToBankHandler: RegisterAddItemToBankHandler,
        RegisterSkillChangeHandler: RegisterSkillChangeHandler,
        TriggerSkillChanged: TriggerSkillChanged,
    };
})();
