(function () {
    var id = 'auto-bonfire';
    var title = 'AutoBonfire';
    var desc = 'AutoBonfire will keep a bonfire lit when you have a type of wood selected in Firemaking. The author suggests having an abundance of wood if using this! Now only begins a bonfire when logs are currently burning.';
    var imgSrc = 'assets/media/skills/firemaking/bonfire_active.svg';
    var skill = 'Firemaking';
    var autoBonfire = function () {
        if (!game.firemaking.isBonfireActive && SEMIUtils.isCurrentSkill('Firemaking')) {
            game.firemaking.lightBonfire();
        }
    };
    var onEnable = function () {
        SEMIUtils.customNotify(imgSrc, 'To begin, start burning some logs.', { duration: 5000 });
    };
    SEMI.add(id, { ms: 500, onLoop: autoBonfire, onEnable: onEnable, desc: desc, imgSrc: imgSrc, title: title, skill: skill });
})();
