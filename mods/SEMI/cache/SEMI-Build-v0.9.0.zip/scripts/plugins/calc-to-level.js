var Skill = CONSTANTS.skill;
var getData = function (skill) {
    var _a;
    var hasCraftCape = SEMIUtils.currentEquipmentInSlot('Cape') === CONSTANTS.item.Crafting_Skillcape;
    var craftInterval = hasCraftCape ? 1500 : 3000;
    var data = (_a = {},
        _a[Skill.Woodcutting] = { interval: 2000, key: 'xp', itemData: logsData, selectedItem: selectedLog },
        _a[Skill.Cooking] = { interval: 3000, key: 'cookingXP', itemData: items, selectedItem: selectedFood },
        _a[Skill.Smithing] = { interval: 2000, key: 'smithingXP', itemData: smithingItems, selectedItem: selectedSmith },
        _a[Skill.Fletching] = {
            interval: 2000,
            key: 'fletchingXP',
            itemData: fletchingItems,
            selectedItem: selectedFletch,
        },
        _a[Skill.Crafting] = {
            interval: craftInterval,
            key: 'craftingXP',
            itemData: craftingItems,
            selectedItem: selectedCraft,
        },
        _a[Skill.Runecrafting] = {
            interval: 2000,
            key: 'runecraftingXP',
            itemData: runecraftingItems,
            selectedItem: selectedRunecraft,
        },
        _a[Skill.Herblore] = {
            interval: 2000,
            key: 'herbloreXP',
            itemData: herbloreItemData,
            selectedItem: selectedHerblore,
        },
        _a);
    return data[skill];
};
var calcToLvl = function (skill) {
    var validSkills = [2, 3, 5, 13, 14, 15, 19];
    if (!validSkills.includes(skill))
        return;
    var alternateCalcSkills = [5, 13, 14, 15];
    var name = skillName[skill];
    var data = getData(skill);
    var selectedItem = data.selectedItem;
    if (selectedItem == null)
        return;
    var expToLvl = exp.level_to_xp(Number($("#" + name + "-lvl-in").val())) + 1 - skillXP[skill];
    var itemsToLvl;
    var item = data.itemData[selectedItem];
    if (alternateCalcSkills.includes(skill)) {
        itemsToLvl = Math.round(expToLvl / items[item.itemID][data.key]) + 1;
    }
    else {
        itemsToLvl = Math.round(expToLvl / item[data.key]) + 1;
    }
    $("#" + name + "-needed").text(numberWithCommas(itemsToLvl));
    var craftTimeMin = data.interval / 1000 / 60;
    var timeToLvl = itemsToLvl * craftTimeMin;
    $("#" + name + "-calc-time").text(SEMIUtils.formatTimeFromMinutes(timeToLvl));
};
var calcItemsInjectBtn = function (skill) {
    if (skill === void 0) { skill = Skill.Firemaking; }
    var validSkills = [
        Skill.Firemaking,
        Skill.Cooking,
        Skill.Smithing,
        Skill.Fletching,
        Skill.Crafting,
        Skill.Runecrafting,
        Skill.Herblore,
    ];
    if (!validSkills.includes(skill)) {
        return;
    }
    var name = skillName[skill];
    return $("\n        <hr style=\"border-top: 1px solid gold !important;\">\n        <div class=\"col-12\">\n            How many of my selected item do I need to reach level <input type=\"number\" id=\"" + name + "-lvl-in\" name=\"" + name + "-lvl-in\" min=\"2\" max=\"99\" style=\"width: 60px;\">?\n            <br>\n            <div class=\"font-size-sm font-w600 text-uppercase text-center text-muted\">\n                <small class=\"mr-2\">\n                    <button type=\"button\" class=\"btn btn-success m-3\" onclick=\"calcToLvl(" + skill + ");\" title=\"You'll need to click this after selecting your craftable item, and click it each time you want to re-calculate.\">Calculate</button>\n                </small>\n            </div>\n            <hr>\n            <span id=\"" + name + "-needed\">#</span> needed to reach selected level.\n            <hr>\n            Creating this many will take this much time: <span id=\"" + name + "-calc-time\">...</span>\n        </div>");
};
var injectItemsCalculators = function () {
    $('#firemaking').children().children().first().append(calcItemsInjectBtn(Skill.Firemaking));
    $('#cooking').children().children().first().append(calcItemsInjectBtn(Skill.Cooking));
    $('#smithing-category-container')
        .children()
        .children()
        .children()
        .first()
        .append(calcItemsInjectBtn(Skill.Smithing));
    $('#fletching-container .block-content.block-content-full').first().after(calcItemsInjectBtn(Skill.Fletching));
    $('#crafting-container .block-content.block-content-full').first().after(calcItemsInjectBtn(Skill.Crafting));
    $('#runecrafting-container .block-content.block-content-full')
        .first()
        .after(calcItemsInjectBtn(Skill.Runecrafting));
    $('#herblore-progress').parent().parent().append(calcItemsInjectBtn(Skill.Herblore));
};
var _initializeCalcLvl = function (skillName) {
    $("#" + skillName + "-lvl-in").val(SEMIUtils.currentLevel(skillName) + 1);
};
var initializeCalcLvl = function () {
    _initializeCalcLvl('Firemaking');
    _initializeCalcLvl('Cooking');
    _initializeCalcLvl('Smithing');
    _initializeCalcLvl('Fletching');
    _initializeCalcLvl('Crafting');
    _initializeCalcLvl('Runecrafting');
    _initializeCalcLvl('Herblore');
};
