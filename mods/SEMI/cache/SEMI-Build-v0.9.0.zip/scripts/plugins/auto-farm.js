var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
(function () {
    var id = 'auto-farm-equip';
    var title = 'AutoFarmEquip';
    var desc = "If not in combat, equips Farming Cape, Bob's Rake and Signet Ring if you have them before harvesting and replanting. Be careful enabling this option with a full bank, can cause a loop where equipment gets continually swapped until bank space is opened up.";
    var imgSrc = 'assets/media/bank/skillcape_farming.png';
    var saveConfig = function () {
        [
            CONSTANTS.item.Bobs_Rake,
            CONSTANTS.item.Farming_Skillcape,
            CONSTANTS.item.Aorpheats_Signet_Ring,
            CONSTANTS.item.Bobs_Gloves,
            CONSTANTS.item.Seed_Pouch,
        ].forEach(function (equipConfigItem) {
            var toggled = $("#" + id + "-" + equipConfigItem).prop('checked');
            SEMI.setValue(id, id + "-" + equipConfigItem, toggled);
        });
        SEMI.setItem(id + "-config", SEMI.getValues(id));
        SEMIUtils.customNotify(imgSrc, title + " config saved!");
    };
    var farmingItems = [
        CONSTANTS.item.Bobs_Rake,
        CONSTANTS.item.Farming_Skillcape,
        CONSTANTS.item.Aorpheats_Signet_Ring,
        CONSTANTS.item.Bobs_Gloves,
        CONSTANTS.item.Seed_Pouch,
    ];
    var updateConfig = function () {
        farmingItems.forEach(function (equipConfigItem) {
            $("#" + id + "-" + equipConfigItem).prop('checked', SEMI.getValue(id, id + "-" + equipConfigItem));
        });
    };
    var configMenuToggle = function (item) {
        var _a;
        return "<div class=\"custom-control custom-switch mb-1\">\n        <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + id + "-" + item + "\" name=\"" + id + "-" + item + "\">\n        <label class=\"custom-control-label\" for=\"" + id + "-" + item + "\">\n            " + ((_a = items[item]) === null || _a === void 0 ? void 0 : _a.name) + "\n        </label>\n    </div>";
    };
    var configMenu = "<div class=\"form-group\">\n    " + farmingItems.map(function (x) { return configMenuToggle(x); }).join('') + "\n</div>";
    SEMI.add(id, {
        ms: 0,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        configMenu: configMenu,
        hasConfig: true,
        saveConfig: saveConfig,
        updateConfig: updateConfig,
    });
})();
(function () {
    var id = 'auto-farm';
    var title = 'AutoFarm';
    var desc = 'AutoFarm by Visua will automatically farm everything for you, planting seeds according to your selected priority, buying and using compost when it needs to. Will use gloop if you have it.';
    var imgSrc = SEMIUtils.skillImg('farming');
    var version = 2;
    var patchTypes = ['allotments', 'herbs', 'trees'];
    var toPatchType = { ALLOTMENT: patchTypes[0], HERB: patchTypes[1], TREE: patchTypes[2] };
    var priorityTypes = {
        custom: { id: 'custom', description: 'Custom priority', tooltip: 'Drag seeds to change their priority' },
        mastery: {
            id: 'mastery',
            description: 'Highest mastery',
            tooltip: 'Seeds with maxed mastery are excluded<br>Click seeds to disable/enable them',
        },
        replant: { id: 'replant', description: 'Replant', tooltip: 'Lock patches to their current seeds' },
        lowestQuantity: {
            id: 'lowestQuantity',
            description: 'Lowest Quantity',
            tooltip: 'Crops with the lowest quantity in the bank are planted',
        },
    };
    var allSeeds = {
        allotments: __spreadArray([], __read(allotmentSeeds)).sort(function (a, b) { return b.level - a.level; }).map(function (s) { return s.itemID; }),
        herbs: __spreadArray([], __read(herbSeeds)).sort(function (a, b) { return b.level - a.level; }).map(function (s) { return s.itemID; }),
        trees: __spreadArray([], __read(treeSeeds)).sort(function (a, b) { return b.level - a.level; }).map(function (s) { return s.itemID; }),
    };
    var observer;
    var config = {
        version: version,
        disabledSeeds: {},
    };
    patchTypes.forEach(function (patchType) {
        config[patchType] = {
            enabled: false,
            priorityType: priorityTypes.custom.id,
            priority: allSeeds[patchType],
            lockedPatches: {},
        };
    });
    function canBuyCompost(n) {
        if (n === void 0) { n = 5; }
        if (SEMIUtils.hasCapeOn('Farming')) {
            return false;
        }
        var cost = n * items[CONSTANTS.item.Compost].buysFor;
        return gp - cost > 0;
    }
    function buyCompost() {
        var compostID = SHOP.Materials.map(function (x) { return x.name; }).indexOf('Compost');
        buyShopItem('Materials', compostID);
    }
    function findNextSeed(patch, patchId) {
        var patchType = toPatchType[patch.type];
        var patchTypeConfig = config[patchType];
        var lockedSeed = patchTypeConfig.lockedPatches[patchId];
        var priority = [];
        if (lockedSeed !== undefined) {
            priority = [lockedSeed];
        }
        else if (patchTypeConfig.priorityType === priorityTypes.custom.id) {
            priority = patchTypeConfig.priority;
        }
        else if (patchTypeConfig.priorityType === priorityTypes.mastery.id) {
            priority = allSeeds[patchType]
                .filter(function (s) { return !config.disabledSeeds[s] && getSeedMasteryLevel(s) < 99; })
                .sort(function (a, b) { return getSeedMastery(b) - getSeedMastery(a); });
        }
        else if (patchTypeConfig.priorityType === priorityTypes.lowestQuantity.id) {
            priority = allSeeds[patchType]
                .filter(function (s) { return !config.disabledSeeds[s]; })
                .sort(function (a, b) { return getSeedCropQuantity(a) - getSeedCropQuantity(b); });
        }
        var nextSeed = -1;
        for (var k = 0; k < priority.length; k++) {
            var seedId = priority[k];
            if (seedId !== -1 && skillLevel[CONSTANTS.skill.Farming] >= items[seedId].farmingLevel) {
                var bankId = SEMIUtils.getBankId(seedId);
                if (bankId !== false && bank[bankId].qty >= items[seedId].seedsRequired) {
                    nextSeed = seedId;
                    break;
                }
            }
        }
        return nextSeed;
    }
    function handlePatch(areaId, patchId) {
        var patch = newFarmingAreas[areaId].patches[patchId];
        if (!config[toPatchType[patch.type]].enabled || !patch.unlocked || !(patch.hasGrown || !patch.seedID)) {
            return;
        }
        if (patch.hasGrown) {
            var grownId = items[patch.seedID].grownItemID;
            var bankId = SEMIUtils.getBankId(grownId);
            if (bankId == false && SEMIUtils.isBankFull()) {
                return;
            }
            harvestSeed(areaId, patchId);
        }
        var nextSeed = findNextSeed(patch, patchId);
        if (nextSeed === -1) {
            return;
        }
        if (!patch.gloop) {
            if (checkBankForItem(CONSTANTS.item.Weird_Gloop)) {
                addGloop(areaId, patchId);
            }
            else if (getSeedMasteryLevel(nextSeed) < 50 &&
                getMasteryPoolProgress(CONSTANTS.skill.Farming) < masteryCheckpoints[1]) {
                if (canBuyCompost()) {
                    getCompost();
                }
                addCompost(areaId, patchId, 5);
            }
        }
        selectedPatch = [areaId, patchId];
        selectedSeed = nextSeed;
        plantSeed();
    }
    function autoFarm() {
        var _a;
        var anyPatchReady = false;
        for (var i = 0; i < newFarmingAreas.length; i++) {
            for (var j = 0; j < newFarmingAreas[i].patches.length; j++) {
                var patch = newFarmingAreas[i].patches[j];
                if (((_a = config[toPatchType[patch.type]]) === null || _a === void 0 ? void 0 : _a.enabled) &&
                    patch.unlocked &&
                    (patch.hasGrown || (!patch.seedID && findNextSeed(patch, j) !== -1))) {
                    anyPatchReady = true;
                    break;
                }
            }
        }
        if (anyPatchReady) {
            if (!player.manager.isInCombat) {
                swapFarmingEquipment(true);
                SEMIUtils.equipSwapConfig.script = id;
            }
            for (var i = 0; i < newFarmingAreas.length; i++) {
                for (var j = 0; j < newFarmingAreas[i].patches.length; j++) {
                    handlePatch(i, j);
                }
            }
            if (SEMIUtils.equipSwapConfig.script === id) {
                swapFarmingEquipment(false);
                SEMIUtils.equipSwapConfig.script = '';
            }
        }
        patchTypes.forEach(function (patchType) {
            if (config[patchType].priorityType === priorityTypes.mastery.id) {
                orderMasteryPriorityMenu(patchType);
            }
        });
    }
    function equipIfNotEquipped(item, slot) {
        if (SEMIUtils.currentEquipmentInSlot(slot) === item) {
            return true;
        }
        if (checkBankForItem(item)) {
            SEMIUtils.equipSwap(item, slot);
            return true;
        }
        return false;
    }
    function swapFarmingEquipment(swapTo) {
        if (swapTo === void 0) { swapTo = true; }
        if (!SEMI.isEnabled('auto-farm-equip')) {
            return;
        }
        var equipConfigs = SEMI.getValues('auto-farm-equip');
        if (swapTo) {
            if (equipConfigs["auto-farm-equip-" + CONSTANTS.item.Bobs_Rake]) {
                equipIfNotEquipped(CONSTANTS.item.Bobs_Rake, 'Weapon');
            }
            if (equipConfigs["auto-farm-equip-" + CONSTANTS.item.Aorpheats_Signet_Ring]) {
                equipIfNotEquipped(CONSTANTS.item.Aorpheats_Signet_Ring, 'Ring');
            }
            if (equipConfigs["auto-farm-equip-" + CONSTANTS.item.Bobs_Gloves]) {
                equipIfNotEquipped(CONSTANTS.item.Bobs_Gloves, 'Gloves');
            }
            if (equipConfigs["auto-farm-equip-" + CONSTANTS.item.Seed_Pouch]) {
                equipIfNotEquipped(CONSTANTS.item.Seed_Pouch, 'Quiver');
            }
            if (equipConfigs["auto-farm-equip-" + CONSTANTS.item.Farming_Skillcape]) {
                var capeIds = [
                    CONSTANTS.item.Cape_of_Completion,
                    CONSTANTS.item.Max_Skillcape,
                    CONSTANTS.item.Farming_Skillcape,
                ];
                var capeId = capeIds.find(function (itemId) { return checkBankForItem(itemId) && checkRequirements(items[itemId].equipRequirements); });
                if (capeId !== undefined)
                    equipIfNotEquipped(capeId, 'Cape');
            }
        }
        else {
            ['Weapon', 'Ring', 'Cape', 'Quiver', 'Gloves'].forEach(function (x) {
                if (SEMIUtils.equipSwapConfig[x].swapped) {
                    SEMIUtils.equipSwap(0, x);
                }
            });
        }
    }
    function getCompost() {
        if (checkBankForItem(CONSTANTS.item.Compost)) {
            var qty = SEMIUtils.getBankQty(CONSTANTS.item.Compost);
            if (qty < 5) {
                buyQty = 5 - qty;
                buyCompost();
            }
        }
        else {
            buyQty = 5;
            buyCompost();
        }
    }
    function getSeedMastery(seedId) {
        return MASTERY[CONSTANTS.skill.Farming].xp[items[seedId].masteryID[1]];
    }
    function getSeedCropQuantity(seedId) {
        return SEMIUtils.getBankQty(items[seedId].grownItemID);
    }
    function getSeedMasteryLevel(seedId) {
        return getMasteryLevel(CONSTANTS.skill.Farming, items[seedId].masteryID[1]);
    }
    function orderMasteryPriorityMenu(patchType) {
        var menu = $("#" + id + "-" + patchType + "-prioritysettings-mastery");
        menu.children()
            .toArray()
            .filter(function (e) { return getSeedMasteryLevel($(e).data('seed-id')) >= 99; })
            .forEach(function (e) { return $(e).remove(); });
        var sortedMenuItems = menu
            .children()
            .toArray()
            .sort(function (a, b) { return getSeedMastery($(b).data('seed-id')) - getSeedMastery($(a).data('seed-id')); });
        menu.append(sortedMenuItems);
    }
    function injectGUI() {
        if ($("#" + id).length) {
            return;
        }
        var disabledOpacity = 0.25;
        function storeConfig() {
            SEMI.setItem(id + "-config-" + currentCharacter, config);
        }
        function loadConfig() {
            var storedConfig = SEMI.getItem(id + "-config-" + currentCharacter);
            if (!storedConfig) {
                return;
            }
            config = __assign(__assign({}, config), storedConfig);
            if (config.version === 1) {
                patchTypes.forEach(function (patchType) {
                    if (config[patchType].priority[0] === allSeeds.herbs[0]) {
                        config[patchType].priority = allSeeds[patchType];
                    }
                });
                for (var i = 0; i < newFarmingAreas.length; i++) {
                    for (var j = 0; j < newFarmingAreas[i].patches.length; j++) {
                        var patch = newFarmingAreas[i].patches[j];
                        if (!patch.unlocked && patch.seedID) {
                            patch.seedID = 0;
                            patch.compost = 0;
                            patch.timePlanted = 0;
                            patch.timeout = null;
                            patch.hasGrown = false;
                            patch.gloop = false;
                        }
                    }
                }
            }
            config.version = version;
            storeConfig();
        }
        loadConfig();
        function createPatchTypeDiv(patchType) {
            function createSeedDiv(seedId) {
                var grownItem = items[items[seedId].grownItemID];
                return "\n                    <div class=\"btn btn-outline-secondary " + id + "-priority-selector\" data-seed-id=\"" + seedId + "\" data-tippy-content=\"" + grownItem.name + "\" style=\"margin: 2px; padding: 6px; float: left;\">\n                        <img src=\"" + grownItem.media + "\" width=\"30\" height=\"30\">\n                    </div>";
            }
            function createPriorityTypeSelector(priorityType) {
                var prefix = id + "-" + patchType + "-prioritytype";
                var elementId = prefix + "-" + priorityType.id;
                return "\n                    <div class=\"custom-control custom-radio custom-control-inline\">\n                        <input class=\"custom-control-input\" type=\"radio\" id=\"" + elementId + "\" name=\"" + prefix + "\" value=\"" + priorityType.id + "\"" + (config[patchType].priorityType === priorityType.id ? ' checked' : '') + ">\n                        <label class=\"custom-control-label\" for=\"" + elementId + "\" data-tippy-content=\"" + priorityType.tooltip + "\">" + priorityType.description + "</label>\n                    </div>";
            }
            var prefix = id + "-" + patchType;
            var prioritySettings = prefix + "-prioritysettings";
            var seedDivs = allSeeds[patchType].map(createSeedDiv).join('');
            return "\n                <div id=\"" + prefix + "\" class=\"col-12 col-md-6 col-xl-4\">\n                    <div class=\"block block-rounded block-link-pop border-top border-farming border-4x\" style=\"padding-bottom: 12px;\">\n                        <div class=\"block-header border-bottom\">\n                            <h3 class=\"block-title\">" + title + " " + patchType + "</h3>\n                            <div class=\"custom-control custom-switch\">\n                                <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + prefix + "-enabled\" name=\"" + prefix + "-enabled\"" + (config[patchType].enabled ? ' checked' : '') + ">\n                                <label class=\"custom-control-label\" for=\"" + prefix + "-enabled\">Enable</label>\n                            </div>\n                        </div>\n                        <div class=\"block-content\" style=\"padding-top: 12px\">\n                            " + Object.values(priorityTypes).map(createPriorityTypeSelector).join('') + "\n                        </div>\n                        <div class=\"block-content\" style=\"padding-top: 12px\">\n                            <div id=\"" + prioritySettings + "-custom\">\n                                " + seedDivs + "\n                                <button id=\"" + prioritySettings + "-reset\" class=\"btn btn-primary locked\" data-tippy-content=\"Reset order to default (highest to lowest level)\" style=\"margin: 5px 0 0 2px; float: right;\">Reset</button>\n                            </div>\n                            <div id=\"" + prioritySettings + "-mastery\" class=\"" + id + "-seed-toggles\">\n                                " + seedDivs + "\n                            </div>\n                            <div id=\"" + prioritySettings + "-lowestQuantity\" class=\"" + id + "-seed-toggles\">\n                                " + seedDivs + "\n                            </div>\n                        </div>\n                    </div>\n                </div>";
        }
        var autoFarmDiv = "\n            <div id=\"" + id + "\" class=\"row row-deck gutters-tiny\">\n                " + patchTypes.map(createPatchTypeDiv).join('') + "\n            </div>";
        $('#farming-container .row:first').after($(autoFarmDiv));
        function addStateChangeHandler(patchType) {
            $("#" + id + "-" + patchType + "-enabled").change(function (event) {
                config[patchType].enabled = event.currentTarget.checked;
                storeConfig();
            });
        }
        patchTypes.forEach(addStateChangeHandler);
        function showSelectedPriorityTypeSettings(patchType) {
            var e_1, _a;
            try {
                for (var _b = __values(Object.values(priorityTypes)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var priorityType = _c.value;
                    $("#" + id + "-" + patchType + "-prioritysettings-" + priorityType.id).toggle(priorityType.id === config[patchType].priorityType);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        patchTypes.forEach(showSelectedPriorityTypeSettings);
        function lockPatch(patchType, patchId, seedId) {
            if (seedId !== undefined) {
                config[patchType].lockedPatches[patchId] = seedId;
            }
            else {
                delete config[patchType].lockedPatches[patchId];
            }
        }
        function addPriorityTypeChangeHandler(patchType) {
            function lockAllPatches(auto) {
                if (auto === void 0) { auto = false; }
                var area = newFarmingAreas[patchTypes.indexOf(patchType)];
                for (var i = 0; i < area.patches.length; i++) {
                    lockPatch(patchType, i, auto ? undefined : area.patches[i].seedID || -1);
                }
                $("." + id + "-seed-selector").remove();
                addSeedSelectors();
            }
            $("#" + id + " input[name=\"" + id + "-" + patchType + "-prioritytype\"]").change(function (event) {
                if (config[patchType].priorityType === priorityTypes.replant.id) {
                    lockAllPatches(true);
                }
                config[patchType].priorityType = event.currentTarget.value;
                if (event.currentTarget.value === priorityTypes.replant.id) {
                    lockAllPatches();
                }
                showSelectedPriorityTypeSettings(patchType);
                storeConfig();
            });
        }
        patchTypes.forEach(addPriorityTypeChangeHandler);
        function makeSortable(patchType) {
            var elementId = id + "-" + patchType + "-prioritysettings-custom";
            Sortable.create(document.getElementById(elementId), {
                animation: 150,
                filter: '.locked',
                onMove: function (event) {
                    if (event.related) {
                        return !event.related.classList.contains('locked');
                    }
                },
                onEnd: function () {
                    config[patchType].priority = __spreadArray([], __read($("#" + elementId + " ." + id + "-priority-selector"))).map(function (x) { return +$(x).data('seed-id'); });
                    storeConfig();
                },
            });
        }
        patchTypes.forEach(makeSortable);
        function orderCustomPriorityMenu(patchType) {
            var priority = config[patchType].priority;
            if (!priority.length) {
                return;
            }
            var menu = $("#" + id + "-" + patchType + "-prioritysettings-custom");
            var menuItems = __spreadArray([], __read(menu.children()));
            function indexOfOrInf(el) {
                var i = priority.indexOf(+el);
                return i === -1 ? Infinity : i;
            }
            var sortedMenu = menuItems.sort(function (a, b) { return indexOfOrInf($(a).data('seed-id')) - indexOfOrInf($(b).data('seed-id')); });
            menu.append(sortedMenu);
        }
        function addPriorityResetClickHandler(patchType) {
            $("#" + id + "-" + patchType + "-prioritysettings-reset").on('click', function () {
                config[patchType].priority = allSeeds[patchType];
                orderCustomPriorityMenu(patchType);
                storeConfig();
            });
        }
        patchTypes.forEach(addPriorityResetClickHandler);
        $("." + id + "-seed-toggles div").each(function (_, e) {
            var toggle = $(e);
            var seedId = toggle.data('seed-id');
            if (config.disabledSeeds[seedId]) {
                toggle.css('opacity', disabledOpacity);
            }
        });
        $("." + id + "-seed-toggles div").on('click', function (event) {
            var toggle = $(event.currentTarget);
            var seedId = toggle.data('seed-id');
            if (config.disabledSeeds[seedId]) {
                delete config.disabledSeeds[seedId];
            }
            else {
                config.disabledSeeds[seedId] = true;
            }
            var opacity = config.disabledSeeds[seedId] ? disabledOpacity : 1;
            toggle.fadeTo(200, opacity);
            storeConfig();
        });
        patchTypes.forEach(function (patchType) {
            orderCustomPriorityMenu(patchType);
            orderMasteryPriorityMenu(patchType);
        });
        function createDropdown(patchType) {
            function createDropdownItem(name, icon, seedId) {
                return "\n                    <button class=\"dropdown-item\"" + (seedId !== undefined ? " data-seed-id=\"" + seedId + "\"" : '') + " style=\"outline: none;\">\n                        <span style=\"margin-right: 12px; vertical-align: text-top;\">" + icon + "</span>" + name + "\n                    </button>";
            }
            return "\n            <div class=\"dropdown " + id + "-seed-selector\" style=\"position: absolute; right: 19px;\">\n                <button type=\"button\" class=\"btn btn-outline-secondary dropdown-toggle\" data-toggle=\"dropdown\" style=\"padding-left: 8px; padding-right: 8px;\"><span class=\"" + id + "-seed-selector-icon\" style=\"margin-right: 6px; vertical-align: text-top; margin-top: 1px;\"></span><span class=\"" + id + "-seed-selector-text\"></span></button>\n                <div class=\"dropdown-menu font-size-sm\" style=\"border-color: #6c757d; border-radius: 0.25rem; padding: 0.25rem 0;\">\n                    " + createDropdownItem('Auto', '<img src="assets/media/main/settings_header.svg" width="20" height="20">') + "\n                    " + allSeeds[patchType]
                .map(function (seedId) {
                return createDropdownItem(items[items[seedId].grownItemID].name, "<img src=\"" + items[items[seedId].grownItemID].media + "\" width=\"20\" height=\"20\">", seedId);
            })
                .join('') + "\n                    " + createDropdownItem('None', '<i class="fa fa-ban" style="width: 20px; font-size: 20px; color: #c81f1f;"></i>', -1) + "\n                </div>\n            </div>";
        }
        function addSeedSelectors() {
            function updateDropdownSelection(patchType, patchId, dropdown) {
                dropdown.find('.dropdown-item.active').removeClass('active');
                var button = dropdown.children('button');
                var selectedSeed = config[patchType].lockedPatches[patchId];
                var selected;
                if (selectedSeed !== undefined) {
                    selected = dropdown.find(".dropdown-item[data-seed-id=\"" + selectedSeed + "\"]");
                    button.find("." + id + "-seed-selector-text").text('');
                }
                else {
                    selected = dropdown.find('.dropdown-item:not([data-seed-id])');
                    button.find("." + id + "-seed-selector-text").text('Auto');
                }
                selected.addClass('active');
                button.find("." + id + "-seed-selector-icon").html(selected.find('span').html());
            }
            $('#farming-area-container h3').each(function (patchId, e) {
                var header = $(e);
                if (header.siblings().length) {
                    return;
                }
                var patchType = toPatchType[header.text()];
                if (patchType === undefined) {
                    return;
                }
                var dropdown = $(createDropdown(patchType));
                updateDropdownSelection(patchType, patchId, dropdown);
                dropdown.find('.dropdown-item').on('click', function (event) {
                    lockPatch(patchType, patchId, $(event.currentTarget).data('seed-id'));
                    storeConfig();
                    updateDropdownSelection(patchType, patchId, dropdown);
                });
                header.after(dropdown);
            });
        }
        addSeedSelectors();
        if (observer) {
            observer.disconnect();
        }
        observer = new MutationObserver(addSeedSelectors);
        observer.observe(document.getElementById('farming-area-container'), { childList: true });
        tippy("#" + id + " [data-tippy-content]", { animation: false, allowHTML: true });
    }
    function removeGUI() {
        if (observer) {
            observer.disconnect();
        }
        $("#" + id + " [data-tippy-content]").each(function (_, e) { return e._tippy.destroy(); });
        $("#" + id).remove();
        $("." + id + "-seed-selector").remove();
    }
    SEMI.add(id, {
        ms: 15000,
        onLoop: autoFarm,
        onEnable: injectGUI,
        onDisable: removeGUI,
        desc: desc,
        title: title,
        imgSrc: imgSrc,
        skill: 'Farming',
    });
    if (SEMI.getItem('auto-replant-status') !== null)
        SEMI.removeItem('auto-replant-status');
})();
