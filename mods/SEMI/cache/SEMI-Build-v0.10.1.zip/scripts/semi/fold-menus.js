var injectEyes = (function () {
    var toggleMoreMenus = function (x) {
        moreMenus[x] = !moreMenus[x];
        storeMenuState();
        showMenus();
    };
    var eye = function (section) {
        var eyeEl = $("<i class=\"far fa-eye text-muted ml-1\" id=\"" + SEMI.ROOT_ID + "-eye-" + section + "\"></i>");
        eyeEl.on('click', function () { return toggleMoreMenus(section); });
        return eyeEl;
    };
    var loadMenuState = function () {
        var storedMenuConfig = SEMI.getItem('fold-menu-config');
        if (storedMenuConfig !== null) {
            Object.keys(storedMenuConfig).map(function (k) { return (moreMenus[k] = storedMenuConfig[k]); });
        }
    };
    var storeMenuState = function () {
        SEMI.setItem('fold-menu-config', moreMenus);
    };
    var injectEyes = function () {
        var socials = $(".nav-main-heading:contains('Socials')").nextUntil('.nav-main-heading');
        var other = $(".nav-main-heading:contains('Other')").nextUntil('.nav-main-heading');
        for (var i = 0; i < socials.length; i++) {
            socials[i].id = SEMI.ROOT_ID + "-socials-" + i;
        }
        for (var i = 0; i < other.length; i++) {
            other[i].id = SEMI.ROOT_ID + "-other-" + i;
        }
        $(".nav-main-heading:contains('Other'):first").append(eye('other'));
        $(".nav-main-heading:contains('Socials')").append(eye('socials'));
        for (var key_1 in SEMI.SIDEBAR_MENUS) {
            var menu = SEMI.SIDEBAR_MENUS[key_1];
            SEMIUtils.getElement(menu.ID + "-header").append(eye(menu.ID));
        }
        $('#SEMI-heading').append(eye('main'));
        loadMenuState();
        showMenus();
    };
    var moreMenus = { other: true, socials: true, main: true };
    var idMap = {
        socials: 'socials-',
        other: 'other-',
    };
    var showMenu = function (id) {
        var state = moreMenus.main && moreMenus[id];
        var className = 'fa-eye' + (state ? '' : '-slash');
        var toRemove = 'fa-eye' + (!state ? '' : '-slash');
        var eye = SEMIUtils.getElement("eye-" + id);
        eye.removeClass(toRemove);
        eye.addClass(className);
        if (id == 'main') {
            var els = $(".SEMI-header, ." + SEMI.ROOT_ID + "-btn");
            if (state) {
                els.removeClass('fold-d-none');
            }
            else {
                els.addClass('fold-d-none');
            }
        }
        else {
            var els = SEMIUtils.getElements(idMap[id]);
            if (state) {
                els.removeClass('fold-d-none');
            }
            else {
                els.addClass('fold-d-none');
            }
        }
    };
    var showMenus = function () {
        showMenu('socials');
        showMenu('other');
        showMenu('main');
        for (var key_2 in SEMI.SIDEBAR_MENUS) {
            var menu = SEMI.SIDEBAR_MENUS[key_2];
            idMap[menu.ID] = menu.ID + "-skill-";
            if (!moreMenus.hasOwnProperty(menu.ID))
                moreMenus[menu.ID] = true;
            showMenu(menu.ID);
        }
        SEMIUtils.getElements('eye-').removeClass('fold-d-none');
    };
    return injectEyes;
})();
