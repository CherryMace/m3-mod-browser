(function () {
    var name = 'offline-time-limit';
    var title = 'Remove 12 hour offline limit (Beta)';
    var desc = 'Removes the 12 hour time limit when processing offline time';
    var imgSrc = 'assets/media/main/milestones_header.svg';
    var origUpdateOffline = updateOffline;
    function getCharacterId() {
        if (localStorage.getItem('MI-forceReload-')) {
            return localStorage.getItem('MI-forceReload-');
        }
        return currentCharacter;
    }
    function injectSelf() {
        if (!Boolean(SEMI.getItem(name + "-status", getCharacterId()))) {
            updateOffline = origUpdateOffline;
            return;
        }
        if (typeof updateOffline === 'undefined') {
            return;
        }
        console.log('Attempting to modify Main.js updateOffline');
        var UpdateOfflineNew = updateOffline.toString();
        UpdateOfflineNew = UpdateOfflineNew.replace('if (timeDiff > 43200000) timeDiff = 43200000;', 'let hoursGone = (timeDiff / 1000 / 60 / 60);');
        if (UpdateOfflineNew == updateOffline.toString()) {
            console.error('Failed to find 12 hour limit');
            return;
        }
        UpdateOfflineNew = UpdateOfflineNew.replace(/if \(timeGone >= 12\) goneFor \+= .+?\r\n/i, '');
        UpdateOfflineNew = UpdateOfflineNew.replace(/if \(timeGone >= 12\) goneFor \+= .+?\n/i, '');
        if (UpdateOfflineNew == updateOffline.toString()) {
            console.error('Failed to find 12 hour message for removal.');
        }
        UpdateOfflineNew = UpdateOfflineNew.replace('Loading your offline progress.', 'Loading \' + ((hoursGone > 1) ? (Math.floor(hoursGone) + " hours") : Math.floor(hoursGone * 60) + " minutes") + \' of offline progress.');
        if (UpdateOfflineNew == updateOffline.toString()) {
            console.error('Failed to find 12 hour message for removal.');
        }
        SEMI.replaceGameFunc('updateOffline', UpdateOfflineNew);
        console.log('Successfully removed 12 hour limit.');
        if (!Boolean(SEMI.getItem('remember-state'))) {
            SEMIUtils.customNotify(imgSrc, 'You enabled the 12 hour time limit remover, but do not have plugins auto-enable when SEMI loads. We suggest enabling that in the SEMI settings for this script to be useful.', { duration: 5000 });
        }
    }
    var addSelfToSemi = function () {
        if (typeof SEMIUtils === 'undefined' || !SEMIUtils.utilsReady()) {
            return;
        }
        clearInterval(semiLoader);
        SEMI.add(name, {
            title: title,
            desc: desc,
            imgSrc: imgSrc,
            pluginType: SEMI.PLUGIN_TYPE.TWEAK,
            onEnable: injectSelf,
            onDisable: injectSelf,
        });
    };
    function waitForLoad() {
        if (!SEMI)
            return;
        clearInterval(semiLoaderInject);
        injectSelf();
    }
    var semiLoaderInject = setInterval(waitForLoad, 50);
    var semiLoader = setInterval(addSelfToSemi, 200);
})();
