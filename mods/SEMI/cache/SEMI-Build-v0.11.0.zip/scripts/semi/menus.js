var SEMIetcGUI = {
    thievingXP: true,
    xph: true,
    timeRemaining: true,
    masteryEnhancements: true,
    lessNotifications: false,
    dropChances: true,
};
var semiSetMenu = (function () {
    var header = $('#SEMI-heading');
    var injectSidebarSections = function () {
        for (var key_1 in SEMI.SIDEBAR_MENUS) {
            var menu = SEMI.SIDEBAR_MENUS[key_1];
            var menuHeader = "<li class=\"nav-main-heading SEMI-header\" id=\"" + SEMI.ROOT_ID + "-" + menu.ID + "-header\" " + (menu.Title !== undefined ? "title=\"" + menu.Title + "\"" : '') + ">" + menu.Header + "</li>";
            var menuSection = "<div id=\"" + SEMI.ROOT_ID + "-" + menu.ID + "-section-unsorted\"></div>";
            header.after(menuHeader, menuSection);
        }
        var semiNavImg = "<img class=\"nav-img\" src=\"" + SEMIUtils.iconSrc + "\">";
        var semiNavInner = "<a class=\"nav-main-link nav-compact " + SEMI.ROOT_ID + "-btn\" id=\"" + SEMI.ROOT_ID + "-info-button\">" + semiNavImg + "<span class=\"nav-main-link-name\">SEMI Menu</span></a>";
        var semiNavEl = $("<li class=\"nav-main-item\" id=\"" + SEMI.ROOT_ID + "-info-header\">" + semiNavInner + "</li>");
        $('#sidebar').find('.nav-main').append(semiNavEl);
        $("#" + SEMI.ROOT_ID + "-info-button").on('click', function () { return semiInfo(); });
    };
    var otherScriptsText = "\n  <ul>\n  <li><a href=\"https://greasyfork.org/en/scripts/394855-melvor-auto-replant\" target=\"_blank\">Melvor Auto Replant by Arcanus</a></li>\n  <li><a href=\"https://discordapp.com/channels/625838709203271680/664637399028072470/669475769671483392\" target=\"_blank\">AutoBonfire by Dream</a></li>\n  <li>Auto Mine & Auto Sell Gems from <a href=\"https://greasyfork.org/en/scripts/395834-melvor-super-control-panel/code\" target=\"_blank\">Melvor Super Control Panel by Strutty & others?</a></li>\n  <li>Thieving Calculator from <a href=\"https://github.com/RedSparr0w/Melvor-Idle-Helper\" target=\"_blank\">Melvor Idle Helper by RedSparr0w</a></li>\n  <li><a href=\"https://discordapp.com/channels/625838709203271680/664637399028072470/681397160465661992\" target=\"_blank\">AutoCook by Unicue</a></li>\n  </ul>";
    var creditsText = "\n  <ul>\n  <li>Maintainer & owner: AldousWatts</li>\n  <li>Contributor: DanielRX\n    <ul>\n    <li>Massive refactoring</li>\n    <li>Dragable Menus</li>\n    <li>Repository improvements</li>\n    <li>Many other script cleanups and contributions</li>\n    </ul>\n  </li>\n  <li>Contributor: Visua\n    <ul>\n    <li>AutoFarm</li>\n    <li>Core fixes and upgrades</li>\n    <li>0.17 update script repair</li>\n    <li>Debugging, refactoring, and more</li>\n    </ul>\n  </li>\n  <li>Contributor: Zeldo\n    <ul>\n    <li>Offline Timer script</li>\n    <li>AutoEquip Best Item script (beta)</li>\n    <li>Per-character config</li>\n    <li>Core upgrades & additions</li>\n    <li>Refactoring & development improvements</li>\n    </ul>\n  </li>\n  <li>Contributor: AuroraKy\n    <ul>\n    <li>Object-Oriented Core Changes finally included</li>\n    <li>Good ideas & discussions</li>\n    <li>Contributions to other scripts that have made it into SEMI</li>\n    </ul>\n  </li>\n  <li>Contributor: Parataku\n    <ul>\n    <li>Spearheaded Melvor v0.18 super-issue</li>\n    <li>Got many scripts up to date with the changes</li>\n    <li>Completely reworked AutoSlayer to be easier to maintain</li>\n    </ul>\n  </li>\n  <li>Contributor: Shamus Taylor\n    <ul>\n    <li>AutoMastery & Updates</li>\n    <li>Fixes & other contributions</li>\n    </ul>\n  </li>\n  <li>Many other community coders and bug reporters and supportive helpful folks! <i class=\"fas fa-heart\"></i></li>\n  </ul>";
    var injectSEMIInfoPopup = function () {
        var semiInfoPopup = $("\n    <div class=\"modal\" id=\"" + SEMI.ROOT_ID + "-semi-modal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"modal-block-normal\" aria-hidden=\"true\">\n      <div class=\"modal-dialog\" role=\"document\">\n        <div class=\"modal-content\"><div class=\"block block-themed block-transparent mb-0\">\n          <div class=\"block-header bg-primary-dark\">\n            <img class=\"nav-img\" src=\"" + SEMIUtils.iconSrc + "\">\n            <h3 class=\"block-title\">Scripting Engine for Melvor Idle Menu</h3>\n            <div class=\"block-options\">\n              <button type=\"button\" class=\"btn-block-option\" data-dismiss=\"modal\" aria-label=\"Close\">\n                <i class=\"fa fa-fw fa-times\"></i>\n              </button>\n            </div>\n          </div>\n          <div class=\"block-content font-size-sm\" style=\"padding-top: 0 !important;\">\n            <div style=\"font-size: 14pt;\">Toggle SEMI features that aren't in the sidebar:</div>\n            <div class=\"custom-control custom-switch mb-1\">\n              <input type=\"checkbox\" class=\"custom-control-input\" id=\"SEMI-auto-enable\" name=\"SEMI-auto-enable\" onchange=\"SEMI.setItem('remember-state', this.checked)\" " + (Boolean(SEMI.getItem('remember-state')) ? 'checked' : '') + ">\n              <label class=\"custom-control-label\" for=\"SEMI-auto-enable\">Automatically load previously enabled scripts</label>\n            </div>\n            <div class=\"custom-control custom-switch mb-1\">\n              <input type=\"checkbox\" class=\"custom-control-input\" id=\"SEMI-xph-button-enabled\" name=\"SEMI-xph-button-enabled\" onchange=\"SEMIetcGUI.xph = this.checked\" " + (SEMIetcGUI.xph ? 'checked' : '') + ">\n              <label class=\"custom-control-label\" for=\"SEMI-xph-button-enabled\">XPH button: XP per hour calculations done through a button next to the Potion selection button</label>\n            </div>\n            <div class=\"custom-control custom-switch mb-1\">\n              <input type=\"checkbox\" class=\"custom-control-input\" id=\"SEMI-mastery-enhancements-button-enabled\" name=\"SEMI-mastery-enhancements-button-enabled\" onchange=\"SEMIetcGUI.masteryEnhancements = this.checked\" " + (SEMIetcGUI.masteryEnhancements ? 'checked' : '') + ">\n              <label class=\"custom-control-label\" for=\"SEMI-mastery-enhancements-button-enabled\">Mastery Enhancement Script: Adds progress bars for pools to skills in the menu</label>\n            </div>\n            <div class=\"custom-control custom-switch mb-1\">\n              <input type=\"checkbox\" class=\"custom-control-input\" id=\"SEMI-less-notifications-enabled\" name=\"SEMI-less-notifications-enabled\" onchange=\"SEMIetcGUI.lessNotifications = this.checked\" " + (SEMIetcGUI.lessNotifications ? 'checked' : '') + ">\n              <label class=\"custom-control-label\" for=\"SEMI-less-notifications-enabled\">Less notifications: Disables notifications for repetetive actions like auto-sell and auto-bury. Important notifications will still be shown.</label>\n            </div>\n            <div class=\"block-content block-content-full text-right\">\n              <button type=\"button\" id=\"" + SEMI.ROOT_ID + "-etc-toggles-apply-save\" class=\"btn btn-sm btn-primary\">\n                <i class=\"fa fa-check mr-1\"></i>Save Toggles\n              </button>\n            </div>\n            <div style=\"font-size: 14pt;\">\n            SEMI Config Backup, Restore, and Reset:\n            </div>\n            <div class=\"block-content\">\n              <textarea class=\"form-control SEMI-static-textarea\" id=\"exportSEMISettings\" name=\"exportSEMISettings\" rows=\"1\" placeholder=\"Exported SEMI config will be here.\"></textarea>\n              <button type=\"button\" id=\"" + SEMI.ROOT_ID + "-semi-modal-export-button\" class=\"btn btn-sm btn-primary\" onclick=\"SEMI.backupSEMI()\">\n                Export\n              </button>\n            </div>\n            <br>\n            <div class=\"block-content\">\n              <textarea class=\"form-control SEMI-static-textarea\" id=\"importSEMISettings\" name=\"importSEMISettings\" rows=\"1\" placeholder=\"Paste SEMI config here.\"></textarea>\n              <button type=\"button\" id=\"" + SEMI.ROOT_ID + "-semi-modal-import-button\" class=\"btn btn-sm btn-primary\" onclick=\"SEMI.restoreSEMI()\">\n                Import\n              </button>\n            </div>\n            <br>\n            <br>\n            <button id=\"hide-SEMI-info-button\" class=\"btn btn-outline-primary\" type=\"button\">Show SEMI Info</button>\n            <button id=\"SEMI-RESET-button\" class=\"btn btn-danger\" style=\"margin-left: 20px;\" type=\"button\">\n              <i class=\"fa fa-fw fa-times mr-1\"></i>\n              Reset SEMI\n            </button>\n            <div id=\"" + SEMI.ROOT_ID + "-info-box\" class=\"d-none SEMI-fixed-textbox\">\n              <div style=\"font-size: 14pt\"><b>SEMI v" + SEMI_VERSION + "</b></div>\n              Hover over sidebar buttons or some other SEMI elements to see tooltips that describe the scripts/options and give hints.\n              <br>\n              <br>\n              If you unlock the sidebar sections, you can drag and rearrange the items in the section. Dragging an item below the SEMI icon only visible when unlocked will hide the item when the section is locked.\n              <br>\n              <br>\n              <b>Credits:</b>\n              <br>\n              " + creditsText + "\n              Many functions of SEMI were originally based on these scripts by others:\n              " + otherScriptsText + "\n              Source code for SEMI, along with issues page for suggestions/bugs, can be found at the GitLab repository <a href=\"https://gitlab.com/aldousWatts/SEMI\" target=\"_blank\">here.</a>\n            </div>\n            <br>\n            <br>\n          </div>\n        </div>\n      </div>\n    </div>");
        $('#modal-account-change').before(semiInfoPopup);
        $("#hide-SEMI-info-button").on('click', function () { return toggleSEMIMenuInfo(); });
        $("#SEMI-RESET-button").on('click', function () { return resetSEMIPrompt(); });
        $("#" + SEMI.ROOT_ID + "-etc-toggles-apply-save").on('click', function () { return saveEtcToggles(); });
        $("#SEMI-auto-enable-status").on('click', function () { return toggleAutoEnableScripts(); });
    };
    if (SEMI.getItem('etc-GUI-toggles') !== null) {
        SEMIUtils.mergeOnto(SEMIetcGUI, SEMI.getItem('etc-GUI-toggles'));
        if (SEMIetcGUI.destroyCrops !== undefined)
            delete SEMIetcGUI.destroyCrops;
    }
    var setupSEMI = function () {
        if ($('#auto-replant-button').length)
            return;
        injectSidebarSections();
        SEMIUtils.getElement('info-header').before($('<br>'));
        SEMI.setItem('etc-GUI-toggles', SEMIetcGUI);
        SEMI.pluginNames.forEach(function (name) { return SEMI.injectGUI(name); });
        injectSEMIInfoPopup();
        injectEyes();
        injectDragMenus();
        SEMIUtils.customNotify('assets/media/monsters/dragon_black.svg', 'Scripting Engine for Melvor Idle is now loaded and running! Check the bottom of the sidebar.', { duration: 5000 });
    };
    var semiInfo = function () {
        SEMIUtils.getElement('semi-modal').modal(open);
    };
    var toggleSEMIMenuInfo = function () {
        $("#" + SEMI.ROOT_ID + "-info-box").toggleClass('d-none');
        if ($('#hide-SEMI-info-button').text() == 'Show SEMI Info')
            $('#hide-SEMI-info-button').text('Hide SEMI Info');
        else
            $('#hide-SEMI-info-button').text('Show SEMI Info');
    };
    var resetSEMIPrompt = function () {
        var resetResponse = prompt("Wait. This will erase EVERY SINGLE SEMI CONFIGURATION SETTING. This includes every script option, every dragged menu position, every item selection on your AutoSell and such, all AutoMine preferences, EVERYTHING. This is best used for when something has gone very wrong and you'd like to reset SEMI to a fresh start.\n\n    If you are sure you want to do this, please type 'semi' into the prompt.", 'I changed my mind!');
        if (resetResponse === 'semi')
            SEMI.resetSEMI();
    };
    var saveEtcToggles = function () {
        SEMI.setItem('etc-GUI-toggles', SEMIetcGUI);
        SEMIUtils.customNotify('assets/media/main/settings_header.svg', 'Miscellaneous SEMI GUI settings saved! Changes will take place after refreshing the page.', { duration: 10000 });
    };
    var toggleAutoEnableScripts = function () {
        SEMI.getItem('remember-state') ? SEMI.setItem('remember-state', false) : SEMI.setItem('remember-state', true);
        $("#SEMI-auto-enable-status").text(SEMI.getItem('remember-state') ? 'Enabled' : 'Disabled');
        $("#SEMI-auto-enable-status").addClass(SEMI.getItem('remember-state') ? 'btn-success' : 'btn-danger');
        $("#SEMI-auto-enable-status").removeClass(SEMI.getItem('remember-state') ? 'btn-danger' : 'btn-success');
    };
    var hideSemi = function (reason) {
        console.warn("SEMI was not correctly loaded due to " + reason);
        SEMIUtils.getElements().toggleClass('d-none');
    };
    var loadSemi = function () {
        if (typeof SEMIUtils === 'undefined' || !SEMIUtils.utilsReady()) {
            return;
        }
        clearInterval(semiLoader);
        var tryLoad = true;
        var wrongVersion = gameVersion != SEMI.SUPPORTED_GAME_VERSION;
        if (wrongVersion) {
            var msg_1 = "SEMI Alert:\n      This version of SEMI was made for Melvor Idle " + SEMI.SUPPORTED_GAME_VERSION + ". Loading the extension in this game version may cause unexpected behavior or result in errors.\n      IMPORTANT NOTE: Any errors encountered after loading this way should be reported to SEMI DEVS, and NOT Malcs!\n      Try loading it anyways?";
            tryLoad = window.confirm(msg_1);
        }
        if (!tryLoad) {
            return hideSemi('game version incompatibility.');
        }
        setupSEMI();
        var msg = "SEMI v" + SEMI_VERSION + " Loaded";
        var suffix = wrongVersion ? ', but may experience errors.' : '!';
        console.log(msg + suffix);
    };
    var semiLoader = setInterval(loadSemi, 200);
    return { semiSetMenu: semiSetMenu };
})().semiSetMenu;
