var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var SEMIUtils = (function () {
    var ROOT_ID = 'SEMI-menu';
    var getElement = function (id) {
        return $("#" + ROOT_ID + "-" + id).first();
    };
    var getElements = function (id) {
        return id == '' ? $("[id^=" + ROOT_ID + "]") : $("[id^=" + ROOT_ID + "-" + id + "]");
    };
    var iconSrc = getElement('icon').attr('src');
    var customNotify = function (imgsrc, msg, opts) {
        if (imgsrc === void 0) { imgsrc = ''; }
        if (msg === void 0) { msg = 'Custom Notifications!'; }
        if (opts === void 0) { opts = {}; }
        opts = Object.assign({}, {
            duration: 3000,
            lowPriority: false,
        }, opts);
        var lessNotifications = globalThis.SEMI.getItem('etc-GUI-toggles').lessNotifications;
        if (lessNotifications && opts.lowPriority) {
            return;
        }
        Toastify({
            text: "<div class=\"text-center\"><img class=\"notification-img\" src=\"" + imgsrc + "\"><img src=\"" + iconSrc + "\" height=\"auto\" width=\"auto\" style=\"margin: 4px;\"><span class=\"badge badge-success\"> " + msg + " </span></div>",
            duration: opts.duration,
            gravity: 'bottom',
            position: 'center',
            backgroundColor: 'transparent',
            stopOnFocus: false,
        }).showToast();
    };
    var mergeOnto = function (x, y) {
        Object.keys(y).forEach(function (key) {
            x[key] = y[key];
        });
    };
    var getBankQty = function (id) {
        var itemBankID = SEMIUtils.getBankId(id);
        if (itemBankID !== false) {
            return bank[itemBankID].qty;
        }
        return 0;
    };
    var getBankId = function (itemId) {
        var id = globalThis.getBankId(itemId);
        if (id === -1) {
            return false;
        }
        return id;
    };
    var equipFromBank = function (itemID, qty) {
        if (qty === void 0) { qty = 1; }
        if (typeof itemID === 'undefined' || itemID === 0 || !checkBankForItem(itemID)) {
            return false;
        }
        player.equipItem(itemID, player.selectedEquipmentSet, undefined, qty);
        return true;
    };
    var currentEquipment = function () { return player.equipment.slots; };
    var currentEquipmentInSlot = function (slotName) {
        if (!Object.keys(player.equipment.slots).includes(slotName))
            return;
        return player.equipment.slots[slotName].item.id;
    };
    var isBankFull = function () {
        return bank.length >= getMaxBankSpace();
    };
    var unselectItemIfNotInBank = function (itemID) {
        if ((selectedBankItem === itemID || itemsToSell.includes(itemID)) && !checkBankForItem(itemID)) {
            if (selectedBankItem === itemID) {
                deselectBankItem();
            }
            if (itemsToSell.includes(itemID)) {
                addItemToItemSaleArray(itemID);
            }
        }
    };
    var sellItemWithoutConfirmation = function (itemID, qty) {
        if (qty === void 0) { qty = 1; }
        if (!checkBankForItem(itemID)) {
            return false;
        }
        var saleModifier = 1;
        if (items[itemID].type === 'Logs' &&
            getMasteryPoolProgress(CONSTANTS.skill.Woodcutting) >= masteryCheckpoints[2]) {
            saleModifier += 0.5;
        }
        var _selectBankItem = selectBankItem;
        selectBankItem = function () { };
        try {
            processItemSale(itemID, qty, saleModifier);
        }
        catch (e) {
            console.error("SEMI: Unable to sell " + items[itemID].name + " due to an error in processItemSale():");
            console.error(e);
            return false;
        }
        finally {
            selectBankItem = _selectBankItem;
            unselectItemIfNotInBank(itemID);
        }
        return true;
    };
    var buryItemWithoutConfirmation = function (itemID, qty) {
        if (qty === void 0) { qty = 1; }
        if (!checkBankForItem(itemID)) {
            return false;
        }
        var _selectedBankItem = selectedBankItem;
        selectedBankItem = itemID;
        var _buryItemQty = buryItemQty;
        buryItemQty = qty;
        var _selectBankItem = selectBankItem;
        selectBankItem = function () { };
        try {
            buryItem();
        }
        catch (e) {
            console.error("SEMI: Unable to bury " + items[itemID].name + " due to an error in buryItem():");
            console.error(e);
            return false;
        }
        finally {
            selectedBankItem = _selectedBankItem;
            buryItemQty = _buryItemQty;
            selectBankItem = _selectBankItem;
            unselectItemIfNotInBank(itemID);
        }
        return true;
    };
    var openItemWithoutConfirmation = function (itemID, qty) {
        if (qty === void 0) { qty = 1; }
        if (!checkBankForItem(itemID)) {
            return false;
        }
        var _selectedBankItem = selectedBankItem;
        selectedBankItem = itemID;
        var _openItemQty = openItemQty;
        openItemQty = qty;
        var _swalFire = Swal.fire;
        Swal.fire = function () { };
        try {
            openBankItem();
            if (sellItemMode) {
                toggleSellItemMode();
            }
            if (moveItemMode) {
                toggleMoveItemMode();
            }
        }
        catch (e) {
            console.error("SEMI: Unable to open " + items[itemID].name + " due to an error in openBankItem():");
            console.error(e);
            return false;
        }
        finally {
            selectedBankItem = _selectedBankItem;
            openItemQty = _openItemQty;
            Swal.fire = _swalFire;
            unselectItemIfNotInBank(itemID);
        }
        return true;
    };
    var equipSwapConfig = {
        Helmet: {
            slotID: 0,
            swapped: false,
        },
        Platebody: {
            slotID: 1,
            swapped: false,
        },
        Platelegs: {
            slotID: 2,
            swapped: false,
        },
        Boots: {
            slotID: 3,
            swapped: false,
        },
        Weapon: {
            slotID: 4,
            swapped: false,
        },
        Shield: {
            slotID: 5,
            swapped: false,
        },
        Amulet: {
            slotID: 6,
            swapped: false,
        },
        Ring: {
            slotID: 7,
            swapped: false,
        },
        Gloves: {
            slotID: 8,
            swapped: false,
        },
        Quiver: {
            slotID: 9,
            swapped: false,
        },
        Cape: {
            slotID: 10,
            swapped: false,
        },
        script: '',
    };
    var equipSwap = function (idSwap, slotName) {
        var _a, _b;
        var currentlyEquippedItemID = currentEquipmentInSlot(slotName);
        if (!equipSwapConfig[slotName].swapped) {
            equipSwapConfig[slotName].originalID = currentlyEquippedItemID;
            if (slotName === 'Weapon') {
                var currentlyEquippedShield = currentEquipmentInSlot('Shield');
                equipSwapConfig['Shield'].originalID = currentlyEquippedShield;
                if (((_a = items[currentlyEquippedItemID]) === null || _a === void 0 ? void 0 : _a.ammoType) === 2 ||
                    ((_b = items[currentlyEquippedItemID]) === null || _b === void 0 ? void 0 : _b.ammoType) === 3) {
                    equipSwapConfig[slotName].ammo = player.equipment.slots['Quiver'].quantity;
                }
                else {
                    equipSwapConfig[slotName].ammo = 0;
                }
            }
        }
        if (equipSwapConfig[slotName].swapped) {
            equipFromBank(equipSwapConfig[slotName].originalID, equipSwapConfig[slotName].ammo || 1);
            if (slotName === 'Weapon') {
                equipFromBank(equipSwapConfig['Shield'].originalID);
            }
        }
        else {
            equipFromBank(idSwap);
        }
        equipSwapConfig[slotName].swapped = !equipSwapConfig[slotName].swapped;
    };
    var currentLevel = function (skillName, virtualLevel) {
        if (virtualLevel === void 0) { virtualLevel = false; }
        if (virtualLevel) {
            return Math.max(skillLevel[CONSTANTS.skill[skillName]], exp.xp_to_level(skillXP[CONSTANTS.skill[skillName]]) - 1);
        }
        else {
            return skillLevel[CONSTANTS.skill[skillName]];
        }
    };
    var currentLevelById = function (skillId) { return skillLevel[skillId]; };
    var currentXP = function (skillName) { return skillXP[CONSTANTS.skill[skillName]]; };
    var isMaxLevel = function (skillName) { return currentLevel(skillName) >= 99; };
    var isMaxLevelById = function (skillId) { return currentLevelById(skillId) >= 99; };
    var ownsCape = function (skillName) {
        return isMaxLevel(skillName) && checkBankForItem(CONSTANTS.item[skillName + "_Skillcape"]);
    };
    var equippedCapeId = function () { return player.manager.player.equipment.slots.Cape.item.id; };
    var hasCapeOn = function (skillName) {
        return equippedCapeId() == CONSTANTS.item[skillName + "_Skillcape"] ||
            equippedCapeId() == CONSTANTS.item.Max_Skillcape ||
            equippedCapeId() == CONSTANTS.item.Cape_of_Completion;
    };
    var formatTimeFromMinutes = function (min) {
        if (min === void 0) { min = 0; }
        if (min == 0 || min == Infinity) {
            return '...';
        }
        var hrs = min / 60;
        var days = hrs / 24;
        if (min < 60) {
            return min.toFixed(1) + " min";
        }
        else if (min < 1440) {
            return hrs.toFixed(1) + " hrs";
        }
        else if (min >= 1440) {
            return days.toFixed(2) + " days";
        }
    };
    var currentSkillId = function () { return (currentSkillName() == '' ? -1 : CONSTANTS.skill[currentSkillName()]); };
    var currentSkillName = function () {
        if (game.activeSkill === globalThis.ActiveSkills.WOODCUTTING) {
            return 'Woodcutting';
        }
        if (isFishing) {
            return 'Fishing';
        }
        if (game.activeSkill === globalThis.ActiveSkills.FIREMAKING) {
            return 'Firemaking';
        }
        if (isCooking) {
            return 'Cooking';
        }
        if (game.activeSkill === globalThis.ActiveSkills.MINING) {
            return 'Mining';
        }
        if (game.activeSkill === globalThis.ActiveSkills.SMITHING) {
            return 'Smithing';
        }
        if (game.activeSkill === globalThis.ActiveSkills.THIEVING) {
            return 'Thieving';
        }
        if (isFletching) {
            return 'Fletching';
        }
        if (isCrafting) {
            return 'Crafting';
        }
        if (isRunecrafting) {
            return 'Runecrafting';
        }
        if (game.activeSkill === globalThis.ActiveSkills.HERBLORE) {
            return 'Herblore';
        }
        if (player.manager.isInCombat) {
            return 'Hitpoints';
        }
        if (isAgility) {
            return 'Agility';
        }
        if (game.activeSkill === globalThis.ActiveSkills.MAGIC) {
            return 'Alt Magic';
        }
        if (isSummoning) {
            return 'Summoning';
        }
        if (isAstrology) {
            return 'Astrology';
        }
        return '';
    };
    var currentCombatSkillName = function () {
        var _a;
        return (_a = player.attackStyle) === null || _a === void 0 ? void 0 : _a.name;
    };
    var currentCombatSkillId = function () {
        var _a;
        return (_a = player.attackStyle) === null || _a === void 0 ? void 0 : _a.id;
    };
    var stopSkill = function (skillName) {
        if (currentSkillName() !== skillName) {
            return;
        }
        switch (skillName) {
            case 'Mining':
                return game.mining.stop();
            case 'Cooking':
                return startCooking(0, false);
            case 'Smithing':
                return game.smithing.stop();
            case 'Hitpoints':
                return player.manager.stopCombat(true);
            case 'Runecrafting':
                return selectRunecraft(0);
            case 'Summoning':
                return selectSummon(0);
        }
    };
    var isCurrentSkill = function (nameOrId) {
        return typeof nameOrId === 'string' ? currentSkillName() === nameOrId : currentSkillId() === nameOrId;
    };
    var _skillImg = function (skill) { return "assets/media/skills/" + skill + "/" + skill + ".svg"; };
    var skillImg = function (skill) { return _skillImg(skill.toLowerCase()); };
    var pages = [
        'Woodcutting',
        'Shop',
        'Bank',
        'Settings',
        'Changelog',
        'Milestones',
        'Statistics',
        'Fishing',
        'Firemaking',
        'Cooking',
        'Mining',
        'Smithing',
        'Mastery',
        'Combat',
        'Thieving',
        'Farming',
        'Fletching',
        'Crafting',
        'Runecrafting',
        'Herblore',
        'Archaeology',
        'Easter',
    ];
    var currentPageName = function () { return pages[currentPage]; };
    var _changePage = function (name) {
        changePage(pages.indexOf(name));
    };
    var filterItems = function (f) {
        return items
            .map(function (item, i) { return (__assign(__assign({}, item), { i: i })); })
            .filter(f)
            .map(function (_a) {
            var i = _a.i;
            return i;
        });
    };
    var confirmAndCloseModal = function (n) {
        if (n === void 0) { n = 100; }
        setTimeout(function () {
            if (document.getElementsByClassName('swal2-confirm').length == 0)
                return;
            document.getElementsByClassName('swal2-confirm')[0].click();
        }, n);
    };
    var maxHP = function () {
        return player.stats.maxHitpoints;
    };
    var currentHP = function () {
        return player.hitpoints;
    };
    var maxHitOfCurrentEnemy = function () {
        return combatManager.enemy.stats.maxHit;
    };
    var playerIsStunned = function () {
        return player.stun.turns > 0;
    };
    var playerIsAsleep = function () {
        return player.sleep.turns > 0;
    };
    var enemeyNextAttackCanStun = function () {
        var _a, _b;
        return ((_b = (_a = combatManager.enemy.nextAttack.onhitEffects) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.type) === 'Stun';
    };
    var adjustedMaxHit = function () {
        var maxHit = SEMIUtils.maxHitOfCurrentEnemy();
        var enemy = player.manager.enemy;
        var adjustedMaxHit = enemy.getAttackMaxDamage(enemy.nextAttack);
        if (playerIsAsleep()) {
            adjustedMaxHit *= 1.2;
        }
        if (playerIsStunned()) {
            adjustedMaxHit *= 1.2;
        }
        adjustedMaxHit +=
            (player.activeDOTs.size > 0 ? Math.floor(SEMIUtils.maxHP() * 0.02) : 0) +
                combatManager.enemy.modifiers.increasedFlatReflectDamage;
        return Math.ceil(adjustedMaxHit);
    };
    var currentFood = function () { return player.food.slots[player.food.selectedSlot]; };
    function getItemTooltip(itemId) {
        var potionCharges = '';
        var description = '';
        var spec = '';
        var bankClassPopoverBorder = '';
        var bankClassImg = '';
        var bankClassPopover = '';
        var bankClassQty = '';
        var bankMinWidth = '';
        var bankQtyPositioning = '';
        var hp = '';
        var bankLocked = '';
        var bankContainer = '';
        if (items[itemId].isPotion)
            potionCharges =
                "<small class='text-warning'>" + items[itemId].potionCharges + ' Potion Charges</small><br>';
        if (items[itemId].description !== undefined)
            description = "<small class='text-info'>" + items[itemId].description + '</small><br>';
        if (items[itemId].hasSpecialAttack)
            spec =
                "<small class='text-success'>SPECIAL ATTACK<br><span class='text-danger'>" +
                    playerSpecialAttacks[items[itemId].specialAttackID].name +
                    ' (' +
                    playerSpecialAttacks[items[itemId].specialAttackID].chance +
                    "%): </span><span class='text-warning'>" +
                    playerSpecialAttacks[items[itemId].specialAttackID].description +
                    '</span></small> ';
        if (items[itemId].canEat)
            hp =
                "<img class='skill-icon-xs ml-2' src='assets/media/skills/hitpoints/hitpoints.svg'> <span class='text-success'>+" +
                    getFoodHealValue(itemId) +
                    '</span>';
        var bankTooltip = "<div class='text-center'><div class='media d-flex align-items-center push'><div class='mr-3'><img class='bank-img m-1' src='" +
            items[itemId].media +
            "'></div><div class='media-body'><div class='font-w600'>" +
            items[itemId].name +
            '</div>' +
            potionCharges +
            description +
            spec +
            "<div class='font-size-sm'><img class='skill-icon-xs' src='assets/media/main/coins.svg'> " +
            items[itemId].sellsFor +
            hp +
            '<br></div></div></div></div>';
        return bankTooltip;
    }
    var getCharacter = function () {
        return currentCharacter;
    };
    var isSkillUnlocked = function (skillName) {
        return currentGamemode !== CONSTANTS.gamemode.Adventure || skillsUnlocked[CONSTANTS.skill[skillName]];
    };
    var isMonsterKilled = function (monsterID) { return game.stats.monsterKillCount(monsterID) > 0; };
    var isItemFound = function (itemID) { return game.stats.itemFindCount(itemID) > 0; };
    var itemsLength = function () { return items.length; };
    var monsterStatsLength = function () { return game.stats.Monsters.statsMap.size; };
    var _utilsReady = false;
    var utilsReady = function () {
        return _utilsReady;
    };
    var loadUtils = function () {
        if (!isLoaded || typeof SEMI === 'undefined') {
            return;
        }
        clearInterval(utilLoader);
        console.log('Game Loaded. SEMIUtils ready.');
        _utilsReady = true;
        $('body').append('<div id="SEMI-canary"></div>');
    };
    var utilLoader = setInterval(loadUtils, 50);
    return {
        utilsReady: utilsReady,
        changePage: _changePage,
        currentPageName: currentPageName,
        skillImg: skillImg,
        isCurrentSkill: isCurrentSkill,
        stopSkill: stopSkill,
        currentSkillName: currentSkillName,
        currentSkillId: currentSkillId,
        isSkillUnlocked: isSkillUnlocked,
        isMonsterKilled: isMonsterKilled,
        monsterStatsLength: monsterStatsLength,
        isItemFound: isItemFound,
        itemsLength: itemsLength,
        currentEquipment: currentEquipment,
        currentXP: currentXP,
        currentEquipmentInSlot: currentEquipmentInSlot,
        currentLevel: currentLevel,
        formatTimeFromMinutes: formatTimeFromMinutes,
        equipFromBank: equipFromBank,
        isMaxLevel: isMaxLevel,
        ownsCape: ownsCape,
        equippedCapeId: equippedCapeId,
        enemeyNextAttackCanStun: enemeyNextAttackCanStun,
        maxHP: maxHP,
        currentFood: currentFood,
        currentHP: currentHP,
        equipSwap: equipSwap,
        equipSwapConfig: equipSwapConfig,
        isBankFull: isBankFull,
        sellItemWithoutConfirmation: sellItemWithoutConfirmation,
        buryItemWithoutConfirmation: buryItemWithoutConfirmation,
        openItemWithoutConfirmation: openItemWithoutConfirmation,
        hasCapeOn: hasCapeOn,
        confirmAndCloseModal: confirmAndCloseModal,
        maxHitOfCurrentEnemy: maxHitOfCurrentEnemy,
        adjustedMaxHit: adjustedMaxHit,
        playerIsStunned: playerIsStunned,
        playerIsAsleep: playerIsAsleep,
        getCharacter: getCharacter,
        customNotify: customNotify,
        getElements: getElements,
        getElement: getElement,
        getBankQty: getBankQty,
        getBankId: getBankId,
        iconSrc: iconSrc,
        mergeOnto: mergeOnto,
        currentCombatSkillName: currentCombatSkillName,
        currentLevelById: currentLevelById,
        currentCombatSkillId: currentCombatSkillId,
        getItemTooltip: getItemTooltip,
        isMaxLevelById: isMaxLevelById,
    };
})();
