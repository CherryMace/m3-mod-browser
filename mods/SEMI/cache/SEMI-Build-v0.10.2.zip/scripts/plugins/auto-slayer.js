(function () {
    var id = 'auto-slayer';
    var title = 'AutoSlayer';
    var desc = "If using AutoSlayerSkip, it will select a new slayer task within the same tier. Using the Skip option in the AutoSlayer menu will allow you to cycle to a new slayer task in the same tier if you don't have the proper equipment for a currently assigned task. Leave it off if you want to manually select a new tier when complete. Extend option will attempt to extend your current task if you have the coins.";
    var imgSrc = SEMIUtils.skillImg('slayer');
    var config = {
        autodisable: false,
        extend: false,
        unmet: false,
    };
    var originalItem = 0;
    var capePriority = [
        CONSTANTS.item.Slayer_Skillcape,
        CONSTANTS.item.Max_Skillcape,
        CONSTANTS.item.Cape_of_Completion,
    ];
    var waitForEnemyLoaded = false;
    var equipmentSlotNames = [];
    Object.keys(CONSTANTS.equipmentSlot).forEach(function (key) {
        equipmentSlotNames[CONSTANTS.equipmentSlot[key]] = key;
    });
    var newEnemyLoading = player.manager.fightInProgress;
    var slayerTask = combatManager.slayerTask;
    var loop = function () {
        var _a, _b;
        if (combatManager.slayerTask.killsLeft == 0) {
            notifyPlayer(CONSTANTS.skill.Slayer, 'No active slayer task found. Please start a new slayer task.');
            return;
        }
        var isSlayerTaskDisabled = function () {
            return (SEMI.isEnabled('auto-slayer-skip') &&
                typeof SEMI.getItem('ASS-monsterIDS') !== 'undefined' &&
                SEMI.getItem('ASS-monsterIDs').includes(slayerTask.monster.id));
        };
        if (SEMI.getValue(id, 'autodisable')) {
            if (autoSlayer === true) {
                toggleSetting(32);
            }
        }
        if (isSlayerTaskDisabled()) {
            debugLog('This slayer task is disabled. Stopping combat and skipping.');
            combatManager.stopCombat(true, false);
            slayerTask.selectTask(slayerTask.tier, true, true);
            return;
        }
        if (!slayerTask.extended && SEMI.getValue(id, 'extend')) {
            var slayerCoins = player.slayercoins;
            var extensionCost = slayerTask.getExtensionCost();
            if (slayerCoins > extensionCost) {
                debugLog('Can afford slayer task extension cost.');
                slayerTask.extendTask();
            }
        }
        if (waitForEnemyLoaded) {
            if (!combatManager.fightInProgress) {
                return;
            }
            else {
                debugLog('We have engaged enemy.');
                waitForEnemyLoaded = false;
            }
        }
        if (combatManager.enemy.data.id !== slayerTask.monster.id || !SEMIUtils.isCurrentSkill('Hitpoints')) {
            debugLog('stopped fighting');
            player.stopFighting();
            waitForEnemyLoaded = false;
            var targetArea = getMonsterArea(slayerTask.monster.id);
            var requiredItem_1 = targetArea.entryRequirements.filter(function (x) { return x.type == 'SlayerItem'; })[0];
            var requiredItemType_1 = -1;
            var ready = false;
            if (requiredItem_1 !== undefined) {
                debugLog('Needs required item. Fetched information.');
                requiredItemType_1 = items[requiredItem_1.itemID].validSlots[0];
            }
            if (originalItem > 0) {
                debugLog("Re-equipped Item: " + ((_a = items[originalItem]) === null || _a === void 0 ? void 0 : _a.name) + " [" + originalItem + "] [" + requiredItemType_1 + "]");
                SEMIUtils.equipFromBank(originalItem);
                originalItem = 0;
            }
            if (requiredItem_1) {
                debugLog("Required Item: " + items[requiredItem_1.itemID].name + " [" + requiredItem_1.itemID + "] [" + requiredItemType_1 + "]");
                if (capePriority.includes(SEMIUtils.currentEquipmentInSlot('Cape')) ||
                    requiredItem_1.itemID === SEMIUtils.currentEquipmentInSlot(requiredItemType_1) ||
                    requiredItem_1.itemID === SEMIUtils.currentEquipmentInSlot('Passive')) {
                    debugLog("Required item is already equipped.");
                    ready = true;
                }
                else {
                    capePriority.forEach(function (item) {
                        if (SEMIUtils.getBankId(item)) {
                            if ((item === CONSTANTS.item.Cape_of_Completion && checkCompletionCapeRequirements()) ||
                                (item === CONSTANTS.item.Max_Skillcape && checkMaxCapeRequirements()) ||
                                (item !== CONSTANTS.item.Cape_of_Completion && item !== CONSTANTS.item.Max_Skillcape)) {
                                requiredItem_1 = item;
                                requiredItemType_1 = 'Cape';
                                debugLog("Using " + items[requiredItem_1.itemID].name + " as Slayer Item Requirement.");
                            }
                        }
                    });
                }
                if (!ready && SEMIUtils.getBankId(requiredItem_1.itemID)) {
                    originalItem = SEMIUtils.currentEquipmentInSlot(items[requiredItem_1.itemID].type);
                    ready = SEMIUtils.equipFromBank(requiredItem_1.itemID);
                    debugLog("Storing equipped item to equip slayer item: " + ((_b = items[originalItem]) === null || _b === void 0 ? void 0 : _b.name) + " [" + originalItem + "]");
                }
            }
            else {
                debugLog("Nothing special required, is ready.");
                ready = true;
            }
            if (ready && !waitForEnemyLoaded) {
                debugLog('jumping to enemy');
                combatManager.selectMonster(slayerTask.monster.id, getMonsterArea(slayerTask.monster.id));
                waitForEnemyLoaded = true;
            }
            else {
                if (SEMI.getValue(id, 'unmet')) {
                    debugLog("Required item not found, getting a new task.");
                    slayerTask.selectTask(slayerTask.tier, true, true);
                }
                else {
                    debugLog("Missing equipment \"" + items[requiredItem_1.itemID].name + " or script error.\"");
                    notifyPlayer(CONSTANTS.skill.Slayer, "Missing equipment \"" + items[requiredItem_1.itemID].name + "\" for slayer task! Manually select new task or enable auto-skip unmet requirements option.");
                }
            }
        }
    };
    var hasConfig = true;
    var configMenu = "<div class=\"form-group\" style=\"max-width: 300px;\">\n        <b>Disable In-Game Auto-Slayer</b><br/>\n        <span>Enable this option to disable the in-game auto slayer if enabled.</span>\n        <div class=\"custom-control custom-switch\">\n            <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + id + "-config-disable-auto\" name=\"" + id + "-config-disable-auto\">\n            <label class=\"custom-control-label\" for=\"" + id + "-config-disable-auto\">Enabled</label>\n        </div>\n        <br/>\n        <b>Auto-Extend</b><br/>\n        <span>Enable this option to auto-extend all slayer tasks. This will check periodicaly if enough slayer coins are available and extend if possible.</span>\n        <div class=\"custom-control custom-switch\">\n            <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + id + "-config-extend\" name=\"" + id + "-config-extend\">\n            <label class=\"custom-control-label\" for=\"" + id + "-config-extend\">Enabled</label>\n        </div>\n        <br/>\n        <b>Auto-Skip Unmet Requirements</b><br/>\n        <span>Enable this option to auto-skip all slayer tasks if the required equipment is not available.</span>\n        <div class=\"custom-control custom-switch\">\n            <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + id + "-config-unmet\" name=\"" + id + "-config-unmet\">\n            <label class=\"custom-control-label\" for=\"" + id + "-config-unmet\">Enabled</label>\n        </div>\n    </div>";
    var saveConfig = function () {
        var autodisable = Number(document.getElementById(id + "-config-disable-auto").checked);
        var extend = Number(document.getElementById(id + "-config-extend").checked);
        var unmet = Number(document.getElementById(id + "-config-unmet").checked);
        SEMI.setValue(id, 'autodisable', autodisable);
        SEMI.setValue(id, 'extend', extend);
        SEMI.setValue(id, 'unmet', unmet);
        SEMI.setItem(id + "-config", SEMI.getValues(id));
        SEMIUtils.customNotify(imgSrc, "Saved " + title + " Config", {
            duration: 3000,
        });
        updateConfig();
    };
    var updateConfig = function () {
        document.getElementById(id + "-config-disable-auto").checked = SEMI.getValue(id, 'autodisable');
        document.getElementById(id + "-config-extend").checked = SEMI.getValue(id, 'extend');
        document.getElementById(id + "-config-unmet").checked = SEMI.getValue(id, 'unmet');
    };
    var debugLog = function (msg) {
        console.log("[" + title + "] " + msg);
    };
    SEMI.add(id, {
        ms: 4000,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        config: config,
        hasConfig: hasConfig,
        configMenu: configMenu,
        saveConfig: saveConfig,
        updateConfig: updateConfig,
        onLoop: loop,
        skill: 'Slayer',
    });
})();
