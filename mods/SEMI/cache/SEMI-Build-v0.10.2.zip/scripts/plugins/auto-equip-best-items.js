var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
SEMI.AutoEquipBestItems = (function () {
    var id = 'auto-equip-best-item';
    var title = 'AutoEquipBestItem (Beta)';
    var desc = 'Automatically determines the item that is best for your current situation, such as xp items, or increased drops. This script is in beta, it may not include every item.';
    var imgSrc = 'assets/media/main/milestones_header.svg';
    var slotsWeWant = [
        CONSTANTS.equipmentSlot.Helmet,
        CONSTANTS.equipmentSlot.Amulet,
        CONSTANTS.equipmentSlot.Ring,
        CONSTANTS.equipmentSlot.Gloves,
        CONSTANTS.equipmentSlot.Cape,
    ];
    var skillsThatConsumeResources = [
        CONSTANTS.skill.Cooking,
        CONSTANTS.skill.Crafting,
        CONSTANTS.skill.Firemaking,
        CONSTANTS.skill.Fletching,
        CONSTANTS.skill.Herblore,
        CONSTANTS.skill.Runecrafting,
        CONSTANTS.skill.Smithing,
        CONSTANTS.skill.Magic,
    ];
    var skillsThatHaveSecondaryDrops = [
        CONSTANTS.skill.Fishing,
        CONSTANTS.skill.Woodcutting,
        CONSTANTS.skill.Mining,
        CONSTANTS.skill.Thieving,
    ];
    var slotsWeWantImg = {
        0: 'assets/media/bank/armour_helmet.svg',
        6: 'assets/media/bank/misc_amulet.svg',
        7: 'assets/media/bank/misc_ring.svg',
        8: 'assets/media/bank/armour_gloves.svg',
        10: 'assets/media/bank/armour_cape.svg',
    };
    var itemsBySlotConfig = {};
    var itemsBySlotConfigDefault = {
        0: [CONSTANTS.item.Crown_of_Rhaelyx, CONSTANTS.item.Chapeau_Noir],
        6: [CONSTANTS.item.Amulet_of_Looting, CONSTANTS.item.Amulet_of_Fishing, CONSTANTS.item.Clue_Chasers_Insignia],
        7: [
            CONSTANTS.item.Pirates_Lost_Ring,
            CONSTANTS.item.Ancient_Ring_Of_Skills,
            CONSTANTS.item.Aorpheats_Signet_Ring,
            CONSTANTS.item.Gold_Topaz_Ring,
            CONSTANTS.item.Gold_Emerald_Ring,
        ],
        8: [
            CONSTANTS.item.Cooking_Gloves,
            CONSTANTS.item.Gem_Gloves,
            CONSTANTS.item.Mining_Gloves,
            CONSTANTS.item.Smithing_Gloves,
            CONSTANTS.item.Thieving_Gloves,
        ],
        10: [
            CONSTANTS.item.Cape_of_Completion,
            CONSTANTS.item.Max_Skillcape,
            CONSTANTS.item.Woodcutting_Skillcape,
            CONSTANTS.item.Fishing_Skillcape,
            CONSTANTS.item.Cooking_Skillcape,
            CONSTANTS.item.Mining_Skillcape,
            CONSTANTS.item.Smithing_Skillcape,
            CONSTANTS.item.Attack_Skillcape,
            CONSTANTS.item.Strength_Skillcape,
            CONSTANTS.item.Defence_Skillcape,
            CONSTANTS.item.Hitpoints_Skillcape,
            CONSTANTS.item.Thieving_Skillcape,
            CONSTANTS.item.Farming_Skillcape,
            CONSTANTS.item.Ranged_Skillcape,
            CONSTANTS.item.Fletching_Skillcape,
            CONSTANTS.item.Crafting_Skillcape,
            CONSTANTS.item.Runecrafting_Skillcape,
            CONSTANTS.item.Magic_Skillcape,
            CONSTANTS.item.Prayer_Skillcape,
            CONSTANTS.item.Slayer_Skillcape,
            CONSTANTS.item.Herblore_Skillcape,
            CONSTANTS.item.Firemaking_Skillcape,
        ],
    };
    var gatherItemData = function () {
        var e_1, _a, e_2, _b;
        var itemsBySlot = {};
        try {
            for (var slotsWeWant_1 = __values(slotsWeWant), slotsWeWant_1_1 = slotsWeWant_1.next(); !slotsWeWant_1_1.done; slotsWeWant_1_1 = slotsWeWant_1.next()) {
                var slot = slotsWeWant_1_1.value;
                itemsBySlot[slot] = [];
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (slotsWeWant_1_1 && !slotsWeWant_1_1.done && (_a = slotsWeWant_1.return)) _a.call(slotsWeWant_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        var itemId = 0;
        try {
            for (var items_1 = __values(items), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
                var item = items_1_1.value;
                if (Number.isInteger(item.equipmentSlot) && slotsWeWant.includes(item.equipmentSlot)) {
                    item.id = itemId;
                    itemsBySlot[item.equipmentSlot].push(item);
                }
                itemId++;
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (items_1_1 && !items_1_1.done && (_b = items_1.return)) _b.call(items_1);
            }
            finally { if (e_2) throw e_2.error; }
        }
        loadConfig(itemsBySlot);
    };
    var loadConfig = function (itemsBySlot) {
        var e_3, _a, e_4, _b, e_5, _c;
        itemsBySlotConfig = SEMI.getItem(name + "-config");
        if (!itemsBySlotConfig) {
            itemsBySlotConfig = itemsBySlotConfigDefault;
            var newItemsBySlot = {};
            try {
                for (var slotsWeWant_2 = __values(slotsWeWant), slotsWeWant_2_1 = slotsWeWant_2.next(); !slotsWeWant_2_1.done; slotsWeWant_2_1 = slotsWeWant_2.next()) {
                    var slot = slotsWeWant_2_1.value;
                    newItemsBySlot[slot] = [];
                    try {
                        for (var _d = (e_4 = void 0, __values(itemsBySlot[slot])), _e = _d.next(); !_e.done; _e = _d.next()) {
                            var item = _e.value;
                            if (!itemsBySlotConfig[slot].includes(item.id)) {
                                newItemsBySlot[slot].push(item.id);
                            }
                        }
                    }
                    catch (e_4_1) { e_4 = { error: e_4_1 }; }
                    finally {
                        try {
                            if (_e && !_e.done && (_b = _d.return)) _b.call(_d);
                        }
                        finally { if (e_4) throw e_4.error; }
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (slotsWeWant_2_1 && !slotsWeWant_2_1.done && (_a = slotsWeWant_2.return)) _a.call(slotsWeWant_2);
                }
                finally { if (e_3) throw e_3.error; }
            }
            newItemsBySlot[CONSTANTS.equipmentSlot.Helmet].sort(defensiveItemComparator);
            newItemsBySlot[CONSTANTS.equipmentSlot.Gloves].sort(defensiveItemComparator);
            try {
                for (var slotsWeWant_3 = __values(slotsWeWant), slotsWeWant_3_1 = slotsWeWant_3.next(); !slotsWeWant_3_1.done; slotsWeWant_3_1 = slotsWeWant_3.next()) {
                    var slot = slotsWeWant_3_1.value;
                    itemsBySlotConfig[slot] = itemsBySlotConfig[slot].concat(newItemsBySlot[slot]);
                }
            }
            catch (e_5_1) { e_5 = { error: e_5_1 }; }
            finally {
                try {
                    if (slotsWeWant_3_1 && !slotsWeWant_3_1.done && (_c = slotsWeWant_3.return)) _c.call(slotsWeWant_3);
                }
                finally { if (e_5) throw e_5.error; }
            }
        }
    };
    var defensiveItemComparator = function (aId, bId) {
        var a = items[aId];
        var b = items[bId];
        var aLevel = a.defenceLevelRequired || a.magicLevelRequired || a.rangedLevelRequired;
        var bLevel = b.defenceLevelRequired || b.magicLevelRequired || b.rangedLevelRequired;
        if (!aLevel && bLevel)
            return 1;
        if (aLevel && !bLevel)
            return -1;
        if (aLevel < bLevel)
            return 1;
        if (aLevel == bLevel) {
            var aBonus = a.defenceLevelRequired
                ? a.damageReduction
                : a.magicLevelRequired
                    ? a.magicDefenceBonus
                    : a.rangeArrackBonus;
            var bBonus = b.defenceLevelRequired
                ? b.damageReduction
                : b.magicLevelRequired
                    ? b.magicDefenceBonus
                    : b.rangeArrackBonus;
            if (aBonus < bBonus)
                return 1;
            return -1;
        }
        return -1;
    };
    var defaultTab = 7;
    var getConfigMenu = function () {
        var e_6, _a, e_7, _b, e_8, _c;
        var configMenu = "<div id=\"auto-equip-best-item-tabs\"><ul style=\"list-style-type: none;display:grid;grid-template-columns: repeat(" + slotsWeWant.length + ", 1fr);padding: 0rem 1rem;margin-bottom: 0rem;\">";
        try {
            for (var slotsWeWant_4 = __values(slotsWeWant), slotsWeWant_4_1 = slotsWeWant_4.next(); !slotsWeWant_4_1.done; slotsWeWant_4_1 = slotsWeWant_4.next()) {
                var slot = slotsWeWant_4_1.value;
                configMenu += getTabHeader(slot);
            }
        }
        catch (e_6_1) { e_6 = { error: e_6_1 }; }
        finally {
            try {
                if (slotsWeWant_4_1 && !slotsWeWant_4_1.done && (_a = slotsWeWant_4.return)) _a.call(slotsWeWant_4);
            }
            finally { if (e_6) throw e_6.error; }
        }
        configMenu += "</ul>";
        try {
            for (var slotsWeWant_5 = __values(slotsWeWant), slotsWeWant_5_1 = slotsWeWant_5.next(); !slotsWeWant_5_1.done; slotsWeWant_5_1 = slotsWeWant_5.next()) {
                var slot = slotsWeWant_5_1.value;
                configMenu += "<ul id=\"auto-equip-best-item-" + slot + "-list\" style=\"list-style-type: none;display:grid;grid-template-columns: repeat(6, 1fr);padding: 1rem;border-color: #5179d6;border-radius: 0rem 0rem 0.25rem 0.25rem;border: 1px solid;margin-bottom: 1rem;\">";
                try {
                    for (var _d = (e_8 = void 0, __values(itemsBySlotConfig[slot])), _e = _d.next(); !_e.done; _e = _d.next()) {
                        var itemId = _e.value;
                        configMenu += getItemButton(items[itemId]);
                    }
                }
                catch (e_8_1) { e_8 = { error: e_8_1 }; }
                finally {
                    try {
                        if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                    }
                    finally { if (e_8) throw e_8.error; }
                }
                configMenu += "</ul>";
            }
        }
        catch (e_7_1) { e_7 = { error: e_7_1 }; }
        finally {
            try {
                if (slotsWeWant_5_1 && !slotsWeWant_5_1.done && (_b = slotsWeWant_5.return)) _b.call(slotsWeWant_5);
            }
            finally { if (e_7) throw e_7.error; }
        }
        return configMenu + "</div>";
    };
    var getTabHeader = function (slot) {
        return "<li><button type=\"button\" id=\"auto-equip-best-item-tab-" + slot + "\" class=\"btn btn-outline-primary btn-info\" style=\"margin-bottom: 0;border-bottom: none;border-radius: .25rem .25rem 0 0;border-color: white;\" onclick=\"SEMI.AutoEquipBestItems.swapTabs(" + slot + ");\"><img class=\"skill-icon-sm m-0\" src=\"" + slotsWeWantImg[slot] + "\"></button></li>";
    };
    var tooltips = [];
    var swapTabs = function (slot) {
        var e_9, _a;
        try {
            for (var slotsWeWant_6 = __values(slotsWeWant), slotsWeWant_6_1 = slotsWeWant_6.next(); !slotsWeWant_6_1.done; slotsWeWant_6_1 = slotsWeWant_6.next()) {
                var s = slotsWeWant_6_1.value;
                document.getElementById("auto-equip-best-item-tab-" + s).style['border-color'] = 'white';
                $("#auto-equip-best-item-" + s + "-list").hide();
            }
        }
        catch (e_9_1) { e_9 = { error: e_9_1 }; }
        finally {
            try {
                if (slotsWeWant_6_1 && !slotsWeWant_6_1.done && (_a = slotsWeWant_6.return)) _a.call(slotsWeWant_6);
            }
            finally { if (e_9) throw e_9.error; }
        }
        var btn = document.getElementById("auto-equip-best-item-tab-" + slot);
        if (btn) {
            btn.style['border-color'] = '#5179d6';
            $("#auto-equip-best-item-" + slot + "-list").show();
        }
        else {
            console.error('Invalid tab', slot);
        }
        tooltips.forEach(function (instance) {
            instance.destroy();
        });
        tooltips = [];
        $("#auto-equip-best-item-" + slot + "-list")
            .children()
            .each(function (index, child) {
            tooltips.concat(tippy("#auto-equip-best-item-id-" + child.dataset.id, {
                content: SEMIUtils.getItemTooltip(Number(child.dataset.id)),
                placement: 'top',
                allowHTML: true,
                interactive: false,
                animation: false,
                touch: 'hold',
            }));
        });
    };
    var getItemButton = function (item) {
        return "<li class=\"ui-state-default\" data-id=\"" + item.id + "\"><button type=\"button\" id=\"auto-equip-best-item-id-" + item.id + "\" class=\"btn btn-outline-primary m-1\" onclick=\"\"><img class=\"skill-icon-sm m-0\" src=\"" + item.media + "\"></button></li>";
    };
    var onConfigMenuShown = function (instance) {
        var e_10, _a;
        try {
            for (var slotsWeWant_7 = __values(slotsWeWant), slotsWeWant_7_1 = slotsWeWant_7.next(); !slotsWeWant_7_1.done; slotsWeWant_7_1 = slotsWeWant_7.next()) {
                var slot = slotsWeWant_7_1.value;
                var element = document.getElementById("auto-equip-best-item-" + slot + "-list");
                if (element)
                    Sortable.create(element);
            }
        }
        catch (e_10_1) { e_10 = { error: e_10_1 }; }
        finally {
            try {
                if (slotsWeWant_7_1 && !slotsWeWant_7_1.done && (_a = slotsWeWant_7.return)) _a.call(slotsWeWant_7);
            }
            finally { if (e_10) throw e_10.error; }
        }
        swapTabs(defaultTab);
    };
    var saveConfig = function () {
        var e_11, _a, e_12, _b;
        try {
            for (var slotsWeWant_8 = __values(slotsWeWant), slotsWeWant_8_1 = slotsWeWant_8.next(); !slotsWeWant_8_1.done; slotsWeWant_8_1 = slotsWeWant_8.next()) {
                var slot = slotsWeWant_8_1.value;
                var list = document.getElementById("auto-equip-best-item-" + slot + "-list");
                if (list) {
                    itemsBySlotConfig[slot] = [];
                    try {
                        for (var _c = (e_12 = void 0, __values(list.children)), _d = _c.next(); !_d.done; _d = _c.next()) {
                            var element = _d.value;
                            itemsBySlotConfig[slot].push(Number(element.dataset.id));
                        }
                    }
                    catch (e_12_1) { e_12 = { error: e_12_1 }; }
                    finally {
                        try {
                            if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
                        }
                        finally { if (e_12) throw e_12.error; }
                    }
                }
            }
        }
        catch (e_11_1) { e_11 = { error: e_11_1 }; }
        finally {
            try {
                if (slotsWeWant_8_1 && !slotsWeWant_8_1.done && (_a = slotsWeWant_8.return)) _a.call(slotsWeWant_8);
            }
            finally { if (e_11) throw e_11.error; }
        }
        SEMI.setItem(name + "-config", itemsBySlotConfig);
    };
    var skillChangeHandler = function (prevSkillId, currentSkillId) {
        var e_13, _a, e_14, _b, e_15, _c, e_16, _d, e_17, _e;
        if (!Boolean(SEMI.getItem(id + "-status")) || (currentSkillId == -1 && !isMagic)) {
            return;
        }
        if (currentSkillId == -1 && isMagic) {
            currentSkillId = CONSTANTS.skill.Magic;
        }
        var currentCombatSkillId = SEMIUtils.currentCombatSkillId();
        var isSkillMaxLevel = SEMIUtils.isMaxLevelById(currentSkillId);
        var isCombatMaxLevel = SEMIUtils.isMaxLevelById(currentCombatSkillId) && SEMIUtils.isMaxLevelById(CONSTANTS.skill.Hitpoints);
        try {
            for (var _f = __values(itemsBySlotConfig[CONSTANTS.equipmentSlot.Cape]), _g = _f.next(); !_g.done; _g = _f.next()) {
                var itemId = _g.value;
                if (canEquipCape(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                    equipItem(itemId)) {
                    break;
                }
            }
        }
        catch (e_13_1) { e_13 = { error: e_13_1 }; }
        finally {
            try {
                if (_g && !_g.done && (_a = _f.return)) _a.call(_f);
            }
            finally { if (e_13) throw e_13.error; }
        }
        try {
            for (var _h = __values(itemsBySlotConfig[CONSTANTS.equipmentSlot.Helmet]), _j = _h.next(); !_j.done; _j = _h.next()) {
                var itemId = _j.value;
                if (canEquipHelmet(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                    equipItem(itemId)) {
                    break;
                }
            }
        }
        catch (e_14_1) { e_14 = { error: e_14_1 }; }
        finally {
            try {
                if (_j && !_j.done && (_b = _h.return)) _b.call(_h);
            }
            finally { if (e_14) throw e_14.error; }
        }
        try {
            for (var _k = __values(itemsBySlotConfig[CONSTANTS.equipmentSlot.Gloves]), _l = _k.next(); !_l.done; _l = _k.next()) {
                var itemId = _l.value;
                if (canEquipGloves(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                    equipItem(itemId)) {
                    break;
                }
            }
        }
        catch (e_15_1) { e_15 = { error: e_15_1 }; }
        finally {
            try {
                if (_l && !_l.done && (_c = _k.return)) _c.call(_k);
            }
            finally { if (e_15) throw e_15.error; }
        }
        try {
            for (var _m = __values(itemsBySlotConfig[CONSTANTS.equipmentSlot.Ring]), _o = _m.next(); !_o.done; _o = _m.next()) {
                var itemId = _o.value;
                if (canEquipRing(currentSkillId, itemId, isSkillMaxLevel) && equipItem(itemId)) {
                    break;
                }
            }
        }
        catch (e_16_1) { e_16 = { error: e_16_1 }; }
        finally {
            try {
                if (_o && !_o.done && (_d = _m.return)) _d.call(_m);
            }
            finally { if (e_16) throw e_16.error; }
        }
        try {
            for (var _p = __values(itemsBySlotConfig[CONSTANTS.equipmentSlot.Amulet]), _q = _p.next(); !_q.done; _q = _p.next()) {
                var itemId = _q.value;
                if (canEquipAmulet(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                    equipItem(itemId)) {
                    break;
                }
            }
        }
        catch (e_17_1) { e_17 = { error: e_17_1 }; }
        finally {
            try {
                if (_q && !_q.done && (_e = _p.return)) _e.call(_p);
            }
            finally { if (e_17) throw e_17.error; }
        }
    };
    var canEquipCape = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Woodcutting_Skillcape:
                return currentSkillId == CONSTANTS.skill.Woodcutting;
            case CONSTANTS.item.Fishing_Skillcape:
                return currentSkillId == CONSTANTS.skill.Fishing;
            case CONSTANTS.item.Cooking_Skillcape:
                return currentSkillId == CONSTANTS.skill.Cooking;
            case CONSTANTS.item.Mining_Skillcape:
                return currentSkillId == CONSTANTS.skill.Mining;
            case CONSTANTS.item.Smithing_Skillcape:
                return (currentSkillId == CONSTANTS.skill.Smithing &&
                    items[smithingItems[currentSmith].itemID].smithReq.some(function (r) { return r.id === CONSTANTS.item.Coal_Ore; }));
            case CONSTANTS.item.Attack_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Attack;
            case CONSTANTS.item.Strength_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Strength;
            case CONSTANTS.item.Defence_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Defence;
            case CONSTANTS.item.Hitpoints_Skillcape:
                return isInCombat;
            case CONSTANTS.item.Thieving_Skillcape:
                return currentSkillId == CONSTANTS.skill.Thieving;
            case CONSTANTS.item.Farming_Skillcape:
                return currentSkillId == CONSTANTS.skill.Farming;
            case CONSTANTS.item.Ranged_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Ranged;
            case CONSTANTS.item.Fletching_Skillcape:
                return currentSkillId == CONSTANTS.skill.Fletching;
            case CONSTANTS.item.Crafting_Skillcape:
                return currentSkillId == CONSTANTS.skill.Crafting;
            case CONSTANTS.item.Runecrafting_Skillcape:
                return currentSkillId == CONSTANTS.skill.Runecrafting;
            case CONSTANTS.item.Magic_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Magic;
            case CONSTANTS.item.Prayer_Skillcape:
                return isInCombat;
            case CONSTANTS.item.Slayer_Skillcape:
                return isInCombat;
            case CONSTANTS.item.Herblore_Skillcape:
                return currentSkillId == CONSTANTS.skill.Herblore;
            case CONSTANTS.item.Firemaking_Skillcape:
                return currentSkillId == CONSTANTS.skill.Firemaking || !isSkillMaxLevel;
        }
        return true;
    };
    var canEquipGloves = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        var item = items[itemId];
        if (Number.isInteger(item.gloveID) && glovesTracker[item.gloveID].remainingActions <= 0) {
            return false;
        }
        var RUNE_ESSENCE = 10;
        switch (itemId) {
            case CONSTANTS.item.Cooking_Gloves:
                return currentSkillId == CONSTANTS.skill.Cooking;
            case CONSTANTS.item.Mining_Gloves:
                return currentSkillId == CONSTANTS.skill.Mining;
            case CONSTANTS.item.Smithing_Gloves:
                return currentSkillId == CONSTANTS.skill.Smithing;
            case CONSTANTS.item.Thieving_Gloves:
                return currentSkillId == CONSTANTS.skill.Thieving;
            case CONSTANTS.item.Gem_Gloves:
                return currentSkillId == CONSTANTS.skill.Mining && currentRock !== RUNE_ESSENCE;
        }
        if (item.magicLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Magic &&
                item.magicLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Magic));
        }
        if (item.defenceLevelRequired) {
            return (isInCombat &&
                (currentCombatSkillId == CONSTANTS.skill.Attack ||
                    currentCombatSkillId == CONSTANTS.skill.Strength ||
                    currentCombatSkillId == CONSTANTS.skill.Defence) &&
                item.defenceLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Defence));
        }
        if (item.rangedLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Ranged &&
                item.rangedLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Ranged));
        }
        return true;
    };
    var canEquipAmulet = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Amulet_of_Looting:
                return isInCombat;
            case CONSTANTS.item.Amulet_of_Fishing:
                return currentSkillId == CONSTANTS.skill.Fishing;
            case CONSTANTS.item.Clue_Chasers_Insignia:
                return skillsThatHaveSecondaryDrops.includes(currentSkillId);
        }
    };
    var canEquipHelmet = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Chapeau_Noir:
                return currentSkillId == CONSTANTS.skill.Thieving || isInCombat;
            case CONSTANTS.item.Crown_of_Rhaelyx:
                return skillsThatConsumeResources.includes(currentSkillId);
        }
        var item = items[itemId];
        if (item.magicLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Magic &&
                item.magicLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Magic));
        }
        if (item.defenceLevelRequired) {
            return (isInCombat &&
                (currentCombatSkillId == CONSTANTS.skill.Attack ||
                    currentCombatSkillId == CONSTANTS.skill.Strength ||
                    currentCombatSkillId == CONSTANTS.skill.Defence) &&
                item.defenceLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Defence));
        }
        if (item.rangedLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Ranged &&
                item.rangedLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Ranged));
        }
        return true;
    };
    var isCurrentTaskMaxMastery = function () {
        var currentSkillId = SEMIUtils.currentSkillId();
        if (currentSkillId === -1) {
            return false;
        }
        var isMaxMastery = function (masteryId) {
            return getMasteryLevel(currentSkillId, masteryId) >= 99;
        };
        switch (SEMIUtils.currentSkillName()) {
            case 'Woodcutting':
                return currentTrees.every(function (t) { return isMaxMastery(t); });
            case 'Fishing':
                return isMaxMastery(fishingItems[fishingAreas[currentFishingArea].fish[selectedFish[currentFishingArea]]].fishingID);
            case 'Mining':
                return isMaxMastery(currentRock);
            case 'Cooking':
                return isMaxMastery(items[selectedFood].masteryID[1]);
        }
        return false;
    };
    var canEquipRing = function (currentSkill, itemId, isSkillMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Pirates_Lost_Ring:
                return !isSkillMaxLevel && currentSkill == CONSTANTS.skill.Fishing;
            case CONSTANTS.item.Ancient_Ring_Of_Skills:
                return !isInCombat && !isSkillMaxLevel;
            case CONSTANTS.item.Ancient_Ring_Of_Mastery:
                return !isInCombat && !isCurrentTaskMaxMastery();
        }
        return true;
    };
    var equipItem = function (itemId) {
        if (equippedItems.includes(itemId)) {
            return true;
        }
        return SEMIUtils.equipFromBank(itemId);
    };
    gatherItemData();
    SEMIEventBus.RegisterSkillChangeHandler({ HandleSkillChange: skillChangeHandler });
    SEMI.add(id, {
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        hasConfig: true,
        configMenu: getConfigMenu(),
        onConfigMenuShown: onConfigMenuShown,
        saveConfig: saveConfig,
    });
    return { swapTabs: swapTabs };
})();
