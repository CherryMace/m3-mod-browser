var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
(function () {
    var id = 'auto-cook';
    var title = 'AutoCook';
    var desc = 'AutoCook is a script for cooking all the fish you have caught. Incompatible with the experimental setting in Melvor, so it will constantly disable that option. Has an extra delay before auto-enabling because of issues with offline progress.';
    var skill = 'Cooking';
    var fishTypeCount = 0;
    var isFood = function (item) { return 'cookingID' in item && item.cookingID !== undefined; };
    var isSelected = function (b) { return b.id === selectedFood; };
    var getFoods = function () { return bank.filter(function (bankItem) { return isFood(items[bankItem.id]); }).filter(isSelected); };
    var foodQty = function () { return __spreadArray(__spreadArray([], getFoods()), [{ qty: 0 }])[0].qty; };
    var fishType = items
        .map(function (item, i) { return (__assign(__assign({}, item), { i: i })); })
        .filter(isFood)
        .map(function (_a) {
        var i = _a.i;
        return i;
    });
    var moveToNext = function () {
        fishTypeCount = (fishTypeCount + 1) % fishType.length;
        selectFood(fishType[fishTypeCount]);
    };
    var autoCookAll = function () {
        if (pauseOfflineActions)
            changeSetting(22, false);
        for (var _ in fishType) {
            if (foodQty() === 0) {
                moveToNext();
            }
        }
        if (foodQty() !== 0 && !SEMIUtils.isCurrentSkill(skill)) {
            startCooking(0, false);
        }
    };
    var onDisable = function () {
        SEMIUtils.stopSkill(skill);
    };
    SEMI.add(id, { onLoop: autoCookAll, onDisable: onDisable, title: title, desc: desc, skill: skill });
})();
