var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
(function () {
    if (SEMI.getItem('etc-GUI-toggles') !== null) {
        var toggle = SEMI.getItem('etc-GUI-toggles').thievingXP;
        if (toggle !== undefined && !toggle)
            return;
    }
    var thievingCalc = function () {
        var coinRow = function (n) { return "<img src='assets/media/main/coins.svg' height='20px'> " + n + " coins (max)"; };
        var g = function (_a) {
            var lootTable = _a.lootTable, maxCoins = _a.maxCoins;
            var totalWeight = lootTable.map(function (item) { return item[1]; }).reduce(function (a, b) { return a + b; }, 0);
            var makeLootRow = function (_a) {
                var itemId = _a[0], weight = _a[1];
                var item = items[itemId];
                return "<img src='" + item.media + "' height='20px'> " + item.name + " - " + ((weight / totalWeight) *
                    100).toFixed(1) + "%";
            };
            return __spreadArray([coinRow(maxCoins)], lootTable.map(makeLootRow)).join('<br/>');
        };
        var f = function (npc, id) {
            var npcEl = document.getElementById("thieving-npc-" + id).getElementsByClassName('block-content')[0];
            npcEl.classList.add('js-popover');
            var data = { toggle: 'popover', html: 'true', placement: 'bottom', content: g(npc) };
            SEMIUtils.mergeOnto(npcEl.dataset, data);
        };
        thievingNPC.forEach(f);
        $('.js-popover').popover({ container: 'body', animation: false, trigger: 'hover focus' });
    };
    var loadCalc = function () {
        if ($('.js-popover').length !== 0) {
            return clearInterval(calcLoader);
        }
        thievingCalc();
    };
    var calcLoader = setInterval(loadCalc, 1000);
})();
