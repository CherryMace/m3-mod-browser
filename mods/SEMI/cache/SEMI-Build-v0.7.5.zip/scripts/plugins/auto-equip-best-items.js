SEMI.AutoEquipBestItems = (function () {
    var id = 'auto-equip-best-item';
    var title = 'AutoEquipBestItem (Beta)';
    var desc = 'Automatically determines the item that is best for your current situation, such as xp items, or increased drops. This script is in beta, it may not include every item.';
    var imgSrc = 'assets/media/main/milestones_header.svg';
    var slotsWeWant = [
        CONSTANTS.equipmentSlot.Helmet,
        CONSTANTS.equipmentSlot.Amulet,
        CONSTANTS.equipmentSlot.Ring,
        CONSTANTS.equipmentSlot.Gloves,
        CONSTANTS.equipmentSlot.Cape,
    ];
    var skillsThatConsumeResources = [
        CONSTANTS.skill.Cooking,
        CONSTANTS.skill.Crafting,
        CONSTANTS.skill.Firemaking,
        CONSTANTS.skill.Fletching,
        CONSTANTS.skill.Herblore,
        CONSTANTS.skill.Runecrafting,
        CONSTANTS.skill.Smithing,
        CONSTANTS.skill.Magic,
    ];
    var skillsThatHaveSecondaryDrops = [
        CONSTANTS.skill.Fishing,
        CONSTANTS.skill.Woodcutting,
        CONSTANTS.skill.Mining,
        CONSTANTS.skill.Thieving,
    ];
    var slotsWeWantImg = {
        0: 'assets/media/bank/armour_helmet.svg',
        6: 'assets/media/bank/misc_amulet.svg',
        7: 'assets/media/bank/misc_ring.svg',
        8: 'assets/media/bank/armour_gloves.svg',
        10: 'assets/media/bank/armour_cape.svg',
    };
    var itemsBySlotConfig = {};
    var itemsBySlotConfigDefault = {
        0: [CONSTANTS.item.Crown_of_Rhaelyx, CONSTANTS.item.Chapeau_Noir],
        6: [CONSTANTS.item.Amulet_of_Looting, CONSTANTS.item.Amulet_of_Fishing, CONSTANTS.item.Clue_Chasers_Insignia],
        7: [
            CONSTANTS.item.Pirates_Lost_Ring,
            CONSTANTS.item.Ancient_Ring_Of_Skills,
            CONSTANTS.item.Aorpheats_Signet_Ring,
            CONSTANTS.item.Gold_Topaz_Ring,
            CONSTANTS.item.Gold_Emerald_Ring,
        ],
        8: [
            CONSTANTS.item.Cooking_Gloves,
            CONSTANTS.item.Gem_Gloves,
            CONSTANTS.item.Mining_Gloves,
            CONSTANTS.item.Smithing_Gloves,
            CONSTANTS.item.Thieving_Gloves,
        ],
        10: [
            CONSTANTS.item.Cape_of_Completion,
            CONSTANTS.item.Max_Skillcape,
            CONSTANTS.item.Woodcutting_Skillcape,
            CONSTANTS.item.Fishing_Skillcape,
            CONSTANTS.item.Cooking_Skillcape,
            CONSTANTS.item.Mining_Skillcape,
            CONSTANTS.item.Smithing_Skillcape,
            CONSTANTS.item.Attack_Skillcape,
            CONSTANTS.item.Strength_Skillcape,
            CONSTANTS.item.Defence_Skillcape,
            CONSTANTS.item.Hitpoints_Skillcape,
            CONSTANTS.item.Thieving_Skillcape,
            CONSTANTS.item.Farming_Skillcape,
            CONSTANTS.item.Ranged_Skillcape,
            CONSTANTS.item.Fletching_Skillcape,
            CONSTANTS.item.Crafting_Skillcape,
            CONSTANTS.item.Runecrafting_Skillcape,
            CONSTANTS.item.Magic_Skillcape,
            CONSTANTS.item.Prayer_Skillcape,
            CONSTANTS.item.Slayer_Skillcape,
            CONSTANTS.item.Herblore_Skillcape,
            CONSTANTS.item.Firemaking_Skillcape,
        ],
    };
    var gatherItemData = function () {
        var itemsBySlot = {};
        for (var _i = 0, slotsWeWant_1 = slotsWeWant; _i < slotsWeWant_1.length; _i++) {
            var slot = slotsWeWant_1[_i];
            itemsBySlot[slot] = [];
        }
        var itemId = 0;
        for (var _a = 0, items_1 = items; _a < items_1.length; _a++) {
            var item = items_1[_a];
            if (Number.isInteger(item.equipmentSlot) && slotsWeWant.includes(item.equipmentSlot)) {
                item.id = itemId;
                itemsBySlot[item.equipmentSlot].push(item);
            }
            itemId++;
        }
        loadConfig(itemsBySlot);
    };
    var loadConfig = function (itemsBySlot) {
        itemsBySlotConfig = SEMI.getItem(name + "-config");
        if (!itemsBySlotConfig) {
            itemsBySlotConfig = itemsBySlotConfigDefault;
            var newItemsBySlot = {};
            for (var _i = 0, slotsWeWant_2 = slotsWeWant; _i < slotsWeWant_2.length; _i++) {
                var slot = slotsWeWant_2[_i];
                newItemsBySlot[slot] = [];
                for (var _a = 0, _b = itemsBySlot[slot]; _a < _b.length; _a++) {
                    var item = _b[_a];
                    if (!itemsBySlotConfig[slot].includes(item.id)) {
                        newItemsBySlot[slot].push(item.id);
                    }
                }
            }
            newItemsBySlot[CONSTANTS.equipmentSlot.Helmet].sort(defensiveItemComparator);
            newItemsBySlot[CONSTANTS.equipmentSlot.Gloves].sort(defensiveItemComparator);
            for (var _c = 0, slotsWeWant_3 = slotsWeWant; _c < slotsWeWant_3.length; _c++) {
                var slot = slotsWeWant_3[_c];
                itemsBySlotConfig[slot] = itemsBySlotConfig[slot].concat(newItemsBySlot[slot]);
            }
        }
    };
    var defensiveItemComparator = function (aId, bId) {
        var a = items[aId];
        var b = items[bId];
        var aLevel = a.defenceLevelRequired || a.magicLevelRequired || a.rangedLevelRequired;
        var bLevel = b.defenceLevelRequired || b.magicLevelRequired || b.rangedLevelRequired;
        if (!aLevel && bLevel)
            return 1;
        if (aLevel && !bLevel)
            return -1;
        if (aLevel < bLevel)
            return 1;
        if (aLevel == bLevel) {
            var aBonus = a.defenceLevelRequired
                ? a.damageReduction
                : a.magicLevelRequired
                    ? a.magicDefenceBonus
                    : a.rangeArrackBonus;
            var bBonus = b.defenceLevelRequired
                ? b.damageReduction
                : b.magicLevelRequired
                    ? b.magicDefenceBonus
                    : b.rangeArrackBonus;
            if (aBonus < bBonus)
                return 1;
            return -1;
        }
        return -1;
    };
    var defaultTab = 7;
    var getConfigMenu = function () {
        var configMenu = "<div id=\"auto-equip-best-item-tabs\"><ul style=\"list-style-type: none;display:grid;grid-template-columns: repeat(" + slotsWeWant.length + ", 1fr);padding: 0rem 1rem;margin-bottom: 0rem;\">";
        for (var _i = 0, slotsWeWant_4 = slotsWeWant; _i < slotsWeWant_4.length; _i++) {
            var slot = slotsWeWant_4[_i];
            configMenu += getTabHeader(slot);
        }
        configMenu += "</ul>";
        for (var _a = 0, slotsWeWant_5 = slotsWeWant; _a < slotsWeWant_5.length; _a++) {
            var slot = slotsWeWant_5[_a];
            configMenu += "<ul id=\"auto-equip-best-item-" + slot + "-list\" style=\"list-style-type: none;display:grid;grid-template-columns: repeat(6, 1fr);padding: 1rem;border-color: #5179d6;border-radius: 0rem 0rem 0.25rem 0.25rem;border: 1px solid;margin-bottom: 1rem;\">";
            for (var _b = 0, _c = itemsBySlotConfig[slot]; _b < _c.length; _b++) {
                var itemId = _c[_b];
                configMenu += getItemButton(items[itemId]);
            }
            configMenu += "</ul>";
        }
        return configMenu + "</div>";
    };
    var getTabHeader = function (slot) {
        return "<li><button type=\"button\" id=\"auto-equip-best-item-tab-" + slot + "\" class=\"btn btn-outline-primary btn-info\" style=\"margin-bottom: 0;border-bottom: none;border-radius: .25rem .25rem 0 0;border-color: white;\" onclick=\"SEMI.AutoEquipBestItems.swapTabs(" + slot + ");\"><img class=\"skill-icon-sm m-0\" src=\"" + slotsWeWantImg[slot] + "\"></button></li>";
    };
    var tooltips = [];
    var swapTabs = function (slot) {
        for (var _i = 0, slotsWeWant_6 = slotsWeWant; _i < slotsWeWant_6.length; _i++) {
            var s = slotsWeWant_6[_i];
            document.getElementById("auto-equip-best-item-tab-" + s).style['border-color'] = 'white';
            $("#auto-equip-best-item-" + s + "-list").hide();
        }
        var btn = document.getElementById("auto-equip-best-item-tab-" + slot);
        if (btn) {
            btn.style['border-color'] = '#5179d6';
            $("#auto-equip-best-item-" + slot + "-list").show();
        }
        else {
            console.error('Invalid tab', slot);
        }
        tooltips.forEach(function (instance) {
            instance.destroy();
        });
        tooltips = [];
        $("#auto-equip-best-item-" + slot + "-list")
            .children()
            .each(function (index, child) {
            tooltips.concat(tippy("#auto-equip-best-item-id-" + child.dataset.id, {
                content: SEMIUtils.getItemTooltip(Number(child.dataset.id)),
                placement: 'top',
                allowHTML: true,
                interactive: false,
                animation: false,
                touch: 'hold',
            }));
        });
    };
    var getItemButton = function (item) {
        return "<li class=\"ui-state-default\" data-id=\"" + item.id + "\"><button type=\"button\" id=\"auto-equip-best-item-id-" + item.id + "\" class=\"btn btn-outline-primary m-1\" onclick=\"\"><img class=\"skill-icon-sm m-0\" src=\"" + item.media + "\"></button></li>";
    };
    var onConfigMenuShown = function (instance) {
        for (var _i = 0, slotsWeWant_7 = slotsWeWant; _i < slotsWeWant_7.length; _i++) {
            var slot = slotsWeWant_7[_i];
            var element = document.getElementById("auto-equip-best-item-" + slot + "-list");
            if (element)
                Sortable.create(element);
        }
        swapTabs(defaultTab);
    };
    var saveConfig = function () {
        for (var _i = 0, slotsWeWant_8 = slotsWeWant; _i < slotsWeWant_8.length; _i++) {
            var slot = slotsWeWant_8[_i];
            var list = document.getElementById("auto-equip-best-item-" + slot + "-list");
            if (list) {
                itemsBySlotConfig[slot] = [];
                for (var _a = 0, _b = list.children; _a < _b.length; _a++) {
                    var element = _b[_a];
                    itemsBySlotConfig[slot].push(Number(element.dataset.id));
                }
            }
        }
        SEMI.setItem(name + "-config", itemsBySlotConfig);
    };
    var skillChangeHandler = function (prevSkillId, currentSkillId) {
        if (!Boolean(SEMI.getItem(id + "-status")) || (currentSkillId == -1 && !isMagic)) {
            return;
        }
        if (currentSkillId == -1 && isMagic) {
            currentSkillId = CONSTANTS.skill.Magic;
        }
        var currentCombatSkillId = SEMIUtils.currentCombatSkillId();
        var isSkillMaxLevel = SEMIUtils.isMaxLevelById(currentSkillId);
        var isCombatMaxLevel = SEMIUtils.isMaxLevelById(currentCombatSkillId) && SEMIUtils.isMaxLevelById(CONSTANTS.skill.Hitpoints);
        for (var _i = 0, _a = itemsBySlotConfig[CONSTANTS.equipmentSlot.Cape]; _i < _a.length; _i++) {
            var itemId = _a[_i];
            if (canEquipCape(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                equipItem(itemId)) {
                break;
            }
        }
        for (var _b = 0, _c = itemsBySlotConfig[CONSTANTS.equipmentSlot.Helmet]; _b < _c.length; _b++) {
            var itemId = _c[_b];
            if (canEquipHelmet(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                equipItem(itemId)) {
                break;
            }
        }
        for (var _d = 0, _e = itemsBySlotConfig[CONSTANTS.equipmentSlot.Gloves]; _d < _e.length; _d++) {
            var itemId = _e[_d];
            if (canEquipGloves(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                equipItem(itemId)) {
                break;
            }
        }
        for (var _f = 0, _g = itemsBySlotConfig[CONSTANTS.equipmentSlot.Ring]; _f < _g.length; _f++) {
            var itemId = _g[_f];
            if (canEquipRing(currentSkillId, itemId, isSkillMaxLevel) && equipItem(itemId)) {
                break;
            }
        }
        for (var _h = 0, _j = itemsBySlotConfig[CONSTANTS.equipmentSlot.Amulet]; _h < _j.length; _h++) {
            var itemId = _j[_h];
            if (canEquipAmulet(currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) &&
                equipItem(itemId)) {
                break;
            }
        }
    };
    var canEquipCape = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Woodcutting_Skillcape:
                return currentSkillId == CONSTANTS.skill.Woodcutting;
            case CONSTANTS.item.Fishing_Skillcape:
                return currentSkillId == CONSTANTS.skill.Fishing;
            case CONSTANTS.item.Cooking_Skillcape:
                return currentSkillId == CONSTANTS.skill.Cooking;
            case CONSTANTS.item.Mining_Skillcape:
                return currentSkillId == CONSTANTS.skill.Mining;
            case CONSTANTS.item.Smithing_Skillcape:
                return (currentSkillId == CONSTANTS.skill.Smithing &&
                    items[smithingItems[currentSmith].itemID].smithReq.some(function (r) { return r.id === CONSTANTS.item.Coal_Ore; }));
            case CONSTANTS.item.Attack_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Attack;
            case CONSTANTS.item.Strength_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Strength;
            case CONSTANTS.item.Defence_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Defence;
            case CONSTANTS.item.Hitpoints_Skillcape:
                return isInCombat;
            case CONSTANTS.item.Thieving_Skillcape:
                return currentSkillId == CONSTANTS.skill.Thieving;
            case CONSTANTS.item.Farming_Skillcape:
                return currentSkillId == CONSTANTS.skill.Farming;
            case CONSTANTS.item.Ranged_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Ranged;
            case CONSTANTS.item.Fletching_Skillcape:
                return currentSkillId == CONSTANTS.skill.Fletching;
            case CONSTANTS.item.Crafting_Skillcape:
                return currentSkillId == CONSTANTS.skill.Crafting;
            case CONSTANTS.item.Runecrafting_Skillcape:
                return currentSkillId == CONSTANTS.skill.Runecrafting;
            case CONSTANTS.item.Magic_Skillcape:
                return isInCombat && currentCombatSkillId == CONSTANTS.skill.Magic;
            case CONSTANTS.item.Prayer_Skillcape:
                return isInCombat;
            case CONSTANTS.item.Slayer_Skillcape:
                return isInCombat;
            case CONSTANTS.item.Herblore_Skillcape:
                return currentSkillId == CONSTANTS.skill.Herblore;
            case CONSTANTS.item.Firemaking_Skillcape:
                return currentSkillId == CONSTANTS.skill.Firemaking || !isSkillMaxLevel;
        }
        return true;
    };
    var canEquipGloves = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        var item = items[itemId];
        if (Number.isInteger(item.gloveID) && glovesTracker[item.gloveID].remainingActions <= 0) {
            return false;
        }
        var RUNE_ESSENCE = 10;
        switch (itemId) {
            case CONSTANTS.item.Cooking_Gloves:
                return currentSkillId == CONSTANTS.skill.Cooking;
            case CONSTANTS.item.Mining_Gloves:
                return currentSkillId == CONSTANTS.skill.Mining;
            case CONSTANTS.item.Smithing_Gloves:
                return currentSkillId == CONSTANTS.skill.Smithing;
            case CONSTANTS.item.Thieving_Gloves:
                return currentSkillId == CONSTANTS.skill.Thieving;
            case CONSTANTS.item.Gem_Gloves:
                return currentSkillId == CONSTANTS.skill.Mining && currentRock !== RUNE_ESSENCE;
        }
        if (item.magicLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Magic &&
                item.magicLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Magic));
        }
        if (item.defenceLevelRequired) {
            return (isInCombat &&
                (currentCombatSkillId == CONSTANTS.skill.Attack ||
                    currentCombatSkillId == CONSTANTS.skill.Strength ||
                    currentCombatSkillId == CONSTANTS.skill.Defence) &&
                item.defenceLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Defence));
        }
        if (item.rangedLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Ranged &&
                item.rangedLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Ranged));
        }
        return true;
    };
    var canEquipAmulet = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Amulet_of_Looting:
                return isInCombat;
            case CONSTANTS.item.Amulet_of_Fishing:
                return currentSkillId == CONSTANTS.skill.Fishing;
            case CONSTANTS.item.Clue_Chasers_Insignia:
                return skillsThatHaveSecondaryDrops.includes(currentSkillId);
        }
    };
    var canEquipHelmet = function (currentSkillId, currentCombatSkillId, itemId, isSkillMaxLevel, isCombatMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Chapeau_Noir:
                return currentSkillId == CONSTANTS.skill.Thieving || isInCombat;
            case CONSTANTS.item.Crown_of_Rhaelyx:
                return skillsThatConsumeResources.includes(currentSkillId);
        }
        var item = items[itemId];
        if (item.magicLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Magic &&
                item.magicLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Magic));
        }
        if (item.defenceLevelRequired) {
            return (isInCombat &&
                (currentCombatSkillId == CONSTANTS.skill.Attack ||
                    currentCombatSkillId == CONSTANTS.skill.Strength ||
                    currentCombatSkillId == CONSTANTS.skill.Defence) &&
                item.defenceLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Defence));
        }
        if (item.rangedLevelRequired) {
            return (isInCombat &&
                currentCombatSkillId == CONSTANTS.skill.Ranged &&
                item.rangedLevelRequired <= SEMIUtils.currentLevelById(CONSTANTS.skill.Ranged));
        }
        return true;
    };
    var isCurrentTaskMaxMastery = function () {
        var currentSkillId = SEMIUtils.currentSkillId();
        if (currentSkillId === -1) {
            return false;
        }
        var isMaxMastery = function (masteryId) {
            return getMasteryLevel(currentSkillId, masteryId) >= 99;
        };
        switch (SEMIUtils.currentSkillName()) {
            case 'Woodcutting':
                return currentTrees.every(function (t) { return isMaxMastery(t); });
            case 'Fishing':
                return isMaxMastery(fishingItems[fishingAreas[currentFishingArea].fish[selectedFish[currentFishingArea]]].fishingID);
            case 'Mining':
                return isMaxMastery(currentRock);
            case 'Cooking':
                return isMaxMastery(items[selectedFood].masteryID[1]);
        }
        return false;
    };
    var canEquipRing = function (currentSkill, itemId, isSkillMaxLevel) {
        if (!checkBankForItem(itemId) && !equippedItems.includes(itemId)) {
            return false;
        }
        switch (itemId) {
            case CONSTANTS.item.Pirates_Lost_Ring:
                return !isSkillMaxLevel && currentSkill == CONSTANTS.skill.Fishing;
            case CONSTANTS.item.Ancient_Ring_Of_Skills:
                return !isInCombat && !isSkillMaxLevel;
            case CONSTANTS.item.Ancient_Ring_Of_Mastery:
                return !isInCombat && !isCurrentTaskMaxMastery();
        }
        return true;
    };
    var equipItem = function (itemId) {
        if (equippedItems.includes(itemId)) {
            return true;
        }
        return SEMIUtils.equipFromBank(itemId);
    };
    gatherItemData();
    SEMIEventBus.RegisterSkillChangeHandler({ HandleSkillChange: skillChangeHandler });
    SEMI.add(id, {
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        hasConfig: true,
        configMenu: getConfigMenu(),
        onConfigMenuShown: onConfigMenuShown,
        saveConfig: saveConfig,
    });
    return { swapTabs: swapTabs };
})();
