(function () {
    if (SEMI.getItem('etc-GUI-toggles') !== null) {
        var toggle = SEMI.getItem('etc-GUI-toggles').dropChances;
        if (toggle !== undefined && !toggle)
            return;
    }
    var dropChances = function () {
        window.viewMonsterDrops = function (monsterID) {
            if (monsterID === -1)
                monsterID = player.manager.enemy.data.id;
            if (monsterID >= 0 && MONSTERS[monsterID].lootTable !== undefined) {
                var drops = '';
                var dropsOrdered = [];
                var totalWeight = MONSTERS[monsterID].lootTable.reduce(function (sum, a) { return sum + a[1]; }, 0);
                if (MONSTERS[monsterID].lootChance != undefined) {
                    totalWeight = (totalWeight * 100) / MONSTERS[monsterID].lootChance;
                }
                for (var i = 0; i < MONSTERS[monsterID].lootTable.length; i++) {
                    dropsOrdered.push({
                        itemID: MONSTERS[monsterID].lootTable[i][0],
                        w: MONSTERS[monsterID].lootTable[i][1],
                        qty: MONSTERS[monsterID].lootTable[i][2],
                        chance: " (" + ((MONSTERS[monsterID].lootTable[i][1] / totalWeight) * 100).toPrecision(3) + "%)",
                    });
                }
                dropsOrdered.sort(function (a, b) {
                    return b.w - a.w;
                });
                for (var i = 0; i < dropsOrdered.length; i++) {
                    drops +=
                        'Up to ' +
                            dropsOrdered[i].qty +
                            ' x <img class="skill-icon-xs mr-2" src="' +
                            getItemMedia(dropsOrdered[i].itemID) +
                            '">' +
                            items[dropsOrdered[i].itemID].name +
                            dropsOrdered[i].chance +
                            '<br>';
                }
                var bones = '';
                if (MONSTERS[monsterID].bones !== null)
                    bones =
                        'Always Drops:<br><small><img class="skill-icon-xs mr-2" src="' +
                            getItemMedia(MONSTERS[monsterID].bones) +
                            '">' +
                            items[MONSTERS[monsterID].bones].name +
                            '</small><br><br>';
                Swal.fire({
                    title: MONSTERS[monsterID].name,
                    html: bones + 'Possible Extra Drops:<br><small>In order of most common to least common<br>' + drops,
                    imageUrl: MONSTERS[monsterID].media,
                    imageWidth: 64,
                    imageHeight: 64,
                    imageAlt: MONSTERS[monsterID].name,
                });
            }
        };
        window.viewItemContents = function (itemID) {
            if (itemID === void 0) { itemID = -1; }
            if (itemID < 0)
                itemID = selectedBankItem;
            var drops = '';
            var dropsOrdered = [];
            var totalWeight = items[itemID].dropTable.reduce(function (sum, a) { return sum + a[1]; }, 0);
            for (var i = 0; i < items[itemID].dropTable.length; i++) {
                dropsOrdered.push({
                    itemID: items[itemID].dropTable[i][0],
                    w: items[itemID].dropTable[i][1],
                    id: i,
                    chance: " (" + ((items[itemID].dropTable[i][1] / totalWeight) * 100).toPrecision(3) + "%)",
                });
            }
            dropsOrdered.sort(function (a, b) {
                return b.w - a.w;
            });
            for (var i = 0; i < dropsOrdered.length; i++) {
                drops +=
                    'Up to ' +
                        numberWithCommas(items[itemID].dropQty[dropsOrdered[i].id]) +
                        ' x <img class="skill-icon-xs mr-2" src="' +
                        getItemMedia(dropsOrdered[i].itemID) +
                        '">' +
                        items[dropsOrdered[i].itemID].name +
                        dropsOrdered[i].chance +
                        '<br>';
            }
            Swal.fire({
                title: items[itemID].name,
                html: 'Possible Items:<br><small>' + drops,
                imageUrl: getItemMedia(itemID),
                imageWidth: 64,
                imageHeight: 64,
                imageAlt: items[itemID].name,
            });
        };
    };
    var loadCheckInterval = setInterval(function () {
        if (isLoaded) {
            clearInterval(loadCheckInterval);
            dropChances();
        }
    }, 200);
})();
