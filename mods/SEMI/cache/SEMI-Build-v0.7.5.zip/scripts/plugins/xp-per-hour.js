var injectXPHGUI = (function () {
    var skills = {
        'xphc-0': 'Attack',
        'xphc-1': 'Strength',
        'xphc-2': 'Defence',
        'xphc-3': 'Hitpoints',
        'xphc-4': 'Ranged',
        'xphc-5': 'Magic',
        'xphc-6': 'Prayer',
        'xphc-7': 'Slayer',
        xphf: 'Farming',
        xph: '',
        xphc: '',
    };
    var el = { xph: '#xph-dialog', xphf: '#xphf-dialog', xphc: '.xphc' };
    var data = {};
    Object.keys(skills).forEach(function (skill) {
        data[skill] = {
            skill: skills[skill],
            el: el[skill],
            children: 0,
        };
    });
    data.xphc.children = 8;
    var getNextLevel = function (data, key) {
        var nextLevel = SEMIUtils.currentLevel(data[key].skill, showVirtualLevels) + 1;
        if (!showVirtualLevels && nextLevel > 99) {
            nextLevel = 99;
        }
        return nextLevel;
    };
    var resetXPHEl = function (key) {
        if (data[key].children !== 0) {
            for (var i = 0; i < data[key].children; i++) {
                resetXPHEl(key + "-" + i);
            }
        }
        $("#" + key + "-rate").text('...');
        $("#" + key + "-lvl").text('... hrs');
        $("#" + key + "-lvl-in").val(getNextLevel(data, key));
        $("#" + key + "-time").text('0');
    };
    var setupData = function (key) {
        var value = data[key];
        if (value.children !== 0) {
            for (var i = 0; i < value.children; i++) {
                setupData(key + "-" + i);
            }
        }
        value.time = Date.now();
        value.running = true;
        value.exp = SEMIUtils.currentXP(value.skill);
    };
    var formatTimeFromSeconds = function (seconds) {
        if (seconds === 0 || seconds === Infinity) {
            return '...';
        }
        var days = Math.floor(seconds / (60 * 60 * 24));
        return (days ? days + 'd ' : '') + new Date(seconds * 1000).toISOString().substr(11, 8);
    };
    var updateXPHEl = function (key) {
        var _a = data[key], skill = _a.skill, xpPerHour = _a.xpPerHour, time = _a.time, children = _a.children;
        if (children !== 0) {
            for (var i = 0; i < children; i++) {
                updateXPHEl(key + "-" + i);
            }
        }
        var hoursToLvl = 0;
        var nextLevel = Number($("#" + key + "-lvl-in").val());
        if (nextLevel <= SEMIUtils.currentLevel(skill, showVirtualLevels)) {
            nextLevel = getNextLevel(data, key);
            $("#" + key + "-lvl-in").val(nextLevel);
        }
        if (nextLevel > SEMIUtils.currentLevel(skill, true) && xpPerHour > 0) {
            hoursToLvl = (exp.level_to_xp(nextLevel) - SEMIUtils.currentXP(skill)) / xpPerHour;
        }
        var xpPerHourString = Math.round(xpPerHour).toString();
        var pattern = /(-?\d+)(\d{3})/;
        while (pattern.test(xpPerHourString)) {
            xpPerHourString = xpPerHourString.replace(pattern, '$1,$2');
        }
        $("#" + key + "-rate").text(xpPerHourString);
        $("#" + key + "-lvl").text(formatTimeFromSeconds(hoursToLvl * 3600));
        $("#" + key + "-time").text(((Date.now() - time) / 1000).toFixed(0));
    };
    var updateRate = function (key) {
        var _a = data[key], skill = _a.skill, exp = _a.exp, time = _a.time, children = _a.children;
        if (children !== 0) {
            for (var i = 0; i < children; i++) {
                updateRate(key + "-" + i);
            }
        }
        var oldXP = exp || 0;
        var oldTime = time || Date.now();
        var timeSince = (Date.now() - oldTime) / 1000;
        var xpLeft = SEMIUtils.currentXP(skill) - oldXP;
        data[key].xpPerHour = (xpLeft / timeSince) * 3600;
    };
    var stats = [
        'Woodcutting',
        'Fishing',
        'Firemaking',
        'Cooking',
        'Mining',
        'Smithing',
        'Attack',
        'Strength',
        'Defence',
        'Hitpoints',
        'Thieving',
        'Farming',
        'Ranged',
        'Fletching',
        'Crafting',
        'Runecrafting',
        'Magic',
        'Prayer',
        'Slayer',
        'Herblore',
        'Agility',
        'Summoning',
    ];
    var runXPH = function (key, running) {
        if (data[key].running) {
            updateRate(key);
            if (!running) {
                data[key].running = false;
            }
            else {
                updateXPHEl(key);
            }
        }
        else {
            setupData(key);
            resetXPHEl(key);
        }
    };
    var stopRunning = function (key) {
        $(data[key].el).addClass('d-none');
        runXPH(key, false);
        clearInterval(data[key].loop);
    };
    var startRunning = function (key) {
        _startRunning[key]();
        runXPH(key, true);
        $(data[key].el).removeClass('d-none');
        var updater = function () {
            runXPH(key, true);
        };
        data[key].loop = setInterval(updater, 1000);
    };
    var toggleRunning = function (key) {
        if (data[key].running) {
            return stopRunning(key);
        }
        return startRunning(key);
    };
    var XPHtoggledOff = false;
    var startXPH = function () {
        var n = SEMIUtils.currentSkillId();
        if (n === -1) {
            return;
        }
        var key = 'xph';
        var skill = typeof n === 'string' ? n : stats[n];
        if (skill == data[key].skill && !XPHtoggledOff) {
            XPHtoggledOff = true;
            return;
        }
        XPHtoggledOff = false;
        data[key].skill = skill;
        $('#xph-skill').text(data[key].skill);
    };
    var startXPHC = function () {
        if (!SEMIUtils.isCurrentSkill('Hitpoints')) {
            return;
        }
        if ($('#combat-skill-progress-menu').attr('class').split(' ').includes('d-none')) {
            toggleCombatSkillMenu();
        }
        if (SEMIUtils.currentPageName() !== 'Combat') {
            SEMIUtils.changePage('Combat');
        }
    };
    var _startRunning = { xph: startXPH, xphc: startXPHC, xphf: function () { } };
    var xphDisplay = function (n) {
        if (n == 11) {
            return toggleRunning('xphf');
        }
        var currentSkill = SEMIUtils.currentSkillName();
        if (currentSkill !== '' && currentSkill !== 'Hitpoints') {
            return toggleRunning('xph');
        }
        toggleRunning('xphc');
    };
    var COMBAT_LEVELS = 8;
    var injectXPHCGUI = function () {
        $('#combat-skill-progress-menu tr:first').append($('<th id="xphc-th" class="xphc d-none" style="width: 125px; text-align: right;">xp/h</th>'));
        $('#combat-skill-progress-menu tr:not(:first)').append($('<td class="font-w600 xphc d-none" style="text-align: right;"><small>...</small></td>'));
        for (var i = 0; i < COMBAT_LEVELS; i++) {
            $('.xphc:not(:first)')[i].id = 'xphc-' + i + '-rate';
        }
        $('#combat-skill-progress-menu tr:first').append($('<th id="xphc-th2" class="xphc xphcl d-none" style="width: 210px; text-align: right;">Time to Level</th>'));
        $('#combat-skill-progress-menu tr:not(:first)').append($("<td class=\"font-w600 xphc xphcl d-none\" style=\"text-align: right;\"><span>...</span> to <input type=\"number\" id=\"xphc-lvl-in\" name=\"xphc-lvl\" min=\"2\" style=\"width: 60px; margin-left: 0.25em;\"></td>"));
        for (var i = 0; i < COMBAT_LEVELS; i++) {
            $('.xphcl:not(:first) span')[i].id = "xphc-" + i + "-lvl";
            $('.xphcl:not(:first) input')[i].id = "xphc-" + i + "-lvl-in";
        }
    };
    var XPHDialogText = "\n    <div id=\"xph-dialog\" class=\"block-content block-content-full text-center d-none\">\n        <h3 class=\"text-muted m-1\"><span class=\"p-1 bg-info rounded\" id=\"xph-rate\">...</span> <span id=\"xph-skill\"></span> XP per hour.</h3>\n        <br>\n        <h3 class=\"text-muted m-1\"><span class=\"p-1 bg-info rounded\" id=\"xph-time\">0</span> seconds spent running XPH.</h3>\n        <h4 class=\"text-muted m-1\"><span id=\"xph-lvl\">... hrs</span> to <input type=\"number\" id=\"xph-lvl-in\" name=\"xph-lvl-in\" min=\"2\" style=\"width: 60px;\">\n        <br>\n    </div>";
    var XPHFDialogText = "\n    <div id=\"xphf-dialog\" class=\"block-content block-content-full text-center d-none\">\n        <h3 class=\"text-muted m-1\"><span class=\"p-1 bg-info rounded\" id=\"xphf-rate\">...</span> Farming XP per hour.</h3>\n        <br>\n        <h3 class=\"text-muted m-1\"><span class=\"p-1 bg-info rounded\" id=\"xphf-time\">0</span> seconds spent running XPHf.</h3>\n        <h4 class=\"text-muted m-1\"><span id=\"xphf-lvl\">... hrs</span> to <input type=\"number\" id=\"xphf-lvl-in\" name=\"xph-lvl-in\" min=\"2\" style=\"width: 60px;\">\n        <br>\n    </div>";
    var y = "\n    <div class=\"block-content block-content-full text-center\">\n        <span class=\"text-muted m-1\">\n        The button below starts the XPH script for the skill you are currently idling. If you click it while it's running for the skill you're currently idling, it will toggle off.<br>\n        SEMI will display your XP per hour in a dialog below the button.<br>\n        If you're in combat, a custom XPH script will run for all combat skills simultaneously and display in the Combat Page's Skill Progress table.<br><br>\n        </span>\n        <button id=\"xphBtn\" class=\"btn btn-info\">Toggle XPH Display</button>\n        <br><br>\n        <div class=\"text-muted m-1\">\n            SEMI has a specific button and separate script for Farming XPH. [NOTE: Only even remotely accurate after calculating for a few hours. Pairs well with AutoReplant.]\n        </div>\n        <button id=\"xphBtnF\" class=\"btn btn-info\">Toggle XPH for Farming</button>\n    </div>";
    var injectXPHGUI = function () {
        var XPHGUI = "\n            <div class=\"dropdown d-inline-block ml-2\">\n                <button type=\"button\" class=\"btn btn-sm bg-info SEMI-gold\" id=\"page-header-xph-dropdown\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"><small>XP/h</small></button>\n                <div class=\"dropdown-menu dropdown-menu-lg dropdown-menu-right p-0 border-0 font-size-sm\" id=\"header-equipment-dropdown\" aria-labelledby=\"page-header-xph-dropdown\" x-placement=\"bottom-end\" style=\"max-width: 90vw; position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-262px, 33px, 0px);\">\n                    <div class=\"p-2 bg-primary text-center\"><h5 class=\"dropdown-header\"><a class=\"text-white\">Calculate XP Per Hour</a></h5></div>\n                    " + y + "\n                    " + XPHDialogText + "\n                    " + XPHFDialogText + "\n                </div>\n            </div>";
        $('#page-header-potions-dropdown').parent().before($(XPHGUI));
        $('#xphBtn').on('click', function () { return xphDisplay(0); });
        $('#xphBtnF').on('click', function () { return xphDisplay(11); });
        injectXPHCGUI();
        var is_android = navigator.userAgent.indexOf('Android') > -1;
        if (!is_android) {
            return;
        }
        $('#header-theme').children().eq(1).children().removeClass('ml-2');
        $("[id^='page-header-']" + 'button').addClass('SEMI-android-narrow-btn');
    };
    return injectXPHGUI;
})();
