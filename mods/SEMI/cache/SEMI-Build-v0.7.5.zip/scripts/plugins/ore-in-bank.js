(function () {
    var name = 'ore-in-bank';
    var title = 'Show Ore in Bank';
    var desc = 'Shows the amount of ore you have in the bank on the Mining page on each of the ore/rock buttons. WARNING: Redundant with ETA.';
    var imgSrc = 'assets/media/bank/ore_dragonite.png';
    var GUI = {
        className: 'SEMI-ore-amount',
        idName: 'SEMI-ore-amount-',
        prefix: 'You have: ',
    };
    function injectOreAmount() {
        var len = miningData.length;
        for (var i = 0; i < len; i++) {
            var rock = miningData[i];
            var image = '';
            if (rock !== undefined) {
                var item = items[rock.ore];
                image = "<img src=\"" + item.media + "\" data-toggle=\"tooltip\" data-placement=\"top\" data-original-title=\"" + item.name + "\" class=\"skill-icon-xs mr-2 js-tooltip-enabled\"></img>";
            }
            if (document.getElementById("" + GUI.idName + i) === null) {
                $('#mining-rates-' + i).after("<span class=\"" + GUI.className + "\"><br><small id=\"" + GUI.idName + i + "\">" + GUI.prefix + "</small>" + image + "</span>");
            }
        }
        updateOreAmount();
    }
    function updateOreAmount() {
        var len = miningData.length;
        for (var i = 0; i < len; i++) {
            var elementToChange = document.getElementById("" + GUI.idName + i);
            if (elementToChange !== null) {
                $("#" + GUI.idName + i).text("" + GUI.prefix + formatNumber(SEMIUtils.getBankQty(miningData[i].ore)));
            }
        }
    }
    function toggleOreAmount() {
        $("." + GUI.className).toggleClass('d-none');
    }
    SEMI.add(name, {
        onLoop: updateOreAmount,
        onEnable: injectOreAmount,
        onToggle: toggleOreAmount,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        skill: 'Mining',
    });
})();
