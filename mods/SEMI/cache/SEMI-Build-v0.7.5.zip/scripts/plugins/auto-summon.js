(function () {
    var id = 'auto-buy-shards';
    var desc = 'AutoBuyShards will automatically buy shards if there is money and bank space.';
    var imgSrc = 'assets/media/bank/skillcape_summoning.svg';
    var title = 'Auto Buy Shards';
    var skill = 'Summoning';
    var config = {
        gpToKeep: 10000000,
    };
    var shardTypes = [
        CONSTANTS.item.Summoning_Shard_Red,
        CONSTANTS.item.Summoning_Shard_Green,
        CONSTANTS.item.Summoning_Shard_Blue,
        CONSTANTS.item.Summoning_Shard_Silver,
        CONSTANTS.item.Summoning_Shard_Gold,
        CONSTANTS.item.Summoning_Shard_Black,
    ];
    var shardShopIDs = SHOP.Materials.map(function (curr) { return shardTypes.includes(curr.contains.items[0][0]); }).reduce(function (acc, item, ind) {
        if (item) {
            acc.push(ind);
        }
        return acc;
    }, []);
    var getUnlockedFamiliars = function () {
        return Object.keys(summoningData.MarksDiscovered)
            .filter(function (key) { return summoningData.MarksDiscovered[key] > 0; })
            .reverse();
    };
    var getFamiliarItemID = function (familiar) { return summoningItems[familiar].itemID; };
    var getShardTypeIndex = function (shardType) { return shardTypes.indexOf(shardType); };
    var getShardShopID = function (shardTypeID) { return shardShopIDs[shardTypeID]; };
    var buyShard = function (shardType) {
        var shardToBuyIndex = getShardTypeIndex(shardType);
        var shardShopID = getShardShopID(shardToBuyIndex);
        buyQty = 10;
        buyShopItem('Materials', shardShopID);
    };
    var configMenu = "<div class=\"form-group\">\n        <label for=\"" + id + "-config-menu\">GP to Keep:</label>\n        <input type=\"number\" class=\"form-control\" id=\"" + id + "-gp-to-keep\" placeholder=\"100\">\n    </div>";
    var topOffShards = function () {
        return shardTypes.forEach(function (shard) {
            if (SEMIUtils.getBankQty(shard) < 10) {
                buyShard(shard);
            }
        });
    };
    var onEnable = function () {
        console.log('AutoSummon enabled');
        SEMIUtils.stopSkill(skill);
    };
    var onDisable = function () {
        console.log('AutoSummon disabled');
        SEMIUtils.stopSkill(skill);
    };
    var currentlyCrafting = function () {
        return SEMIUtils.currentSkillName() === 'Summoning';
    };
    var autoSummon = function () {
        if (!currentlyCrafting()) {
            var familiarsToCraft = getUnlockedFamiliars();
            familiarsToCraft.every(function (familiar) {
                topOffShards();
                var tabletID = getFamiliarItemID(familiar);
                var tablet = items[tabletID];
                tablet.summoningReq.every(function (recipe, index) {
                    var ableToCraft = checkSummoningReq(tabletID);
                    if (!ableToCraft) {
                        return true;
                    }
                    summoningCategory(1);
                    selectSummon(familiar, index);
                    createSummon(false);
                    return false;
                });
                if (currentlyCrafting()) {
                    return false;
                }
            });
        }
    };
    SEMI.add(id, {
        ms: 5000,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_SKILL,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        onEnable: onEnable,
        onDisable: onDisable,
        onLoop: autoSummon,
    });
})();
