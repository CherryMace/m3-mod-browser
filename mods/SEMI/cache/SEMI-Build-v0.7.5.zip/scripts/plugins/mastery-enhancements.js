(function () {
    if (SEMI.getItem('etc-GUI-toggles') !== null) {
        var toggle = SEMI.getItem('etc-GUI-toggles').masteryEnhancements;
        if (toggle !== undefined && !toggle)
            return;
    }
    ('use strict');
    function addProgressBars() {
        var MAX_XP = 13034432;
        var maxedSkills = [];
        setInterval(function () {
            for (var _i = 0, _a = Object.entries(MASTERY); _i < _a.length; _i++) {
                var _b = _a[_i], skillId = _b[0], mastery = _b[1];
                var poolPercentage = (mastery.pool / getMasteryPoolTotalXP(skillId)) * 100;
                if ($("#skill-nav-mastery-" + skillId + " .progress-bar")[0]) {
                    $("#skill-nav-mastery-" + skillId + " .progress-bar")[0].style.width = poolPercentage + '%';
                    var tip = $("#skill-nav-mastery-" + skillId)[0]._tippy;
                    tip.setContent(poolPercentage.toFixed(2) + '%');
                }
                else {
                    var skillItem = $("#skill-nav-name-" + skillId)[0].parentNode;
                    skillItem.style.flexWrap = 'wrap';
                    skillItem.style.setProperty('padding-top', '.25rem', 'important');
                    var progress = document.createElement('div');
                    var progressBar = document.createElement('div');
                    progress.id = "skill-nav-mastery-" + skillId;
                    progress.className = 'progress active pointer-enabled';
                    progress.style.height = '2px';
                    progress.style.width = '100%';
                    progress.style.margin = '.25rem 0rem';
                    progress.style.setProperty('background', 'rgb(76,80,84)', 'important');
                    progressBar.className = 'progress-bar bg-warning';
                    progressBar.style.width = poolPercentage + '%';
                    progress.appendChild(progressBar);
                    skillItem.appendChild(progress);
                    tippy($("#skill-nav-mastery-" + skillId)[0], {
                        placement: 'right',
                        content: poolPercentage.toFixed(2) + '%',
                    });
                }
                if (!maxedSkills[skillId] && !mastery.xp.some(function (xp) { return xp < MAX_XP; })) {
                    maxedSkills[skillId] = true;
                    $("#skill-nav-mastery-" + skillId + " .progress-bar")[0].classList.replace('bg-warning', 'bg-success');
                }
            }
        }, 10000);
    }
    function loadScript() {
        if (typeof confirmedLoaded !== 'undefined' && confirmedLoaded && !currentlyCatchingUp) {
            clearInterval(interval);
            console.log('Loading Mastery Enhancements');
            addProgressBars();
        }
    }
    var interval = setInterval(loadScript, 500);
})();
