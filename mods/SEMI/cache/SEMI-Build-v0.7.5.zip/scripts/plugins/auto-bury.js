(function () {
    var pluginKind = 'bury';
    var id = "auto-" + pluginKind;
    var title = 'AutoBury';
    var desc = 'AutoBury is a script for burying items you no longer want.';
    var imgSrc = 'assets/media/bank/bones.png';
    var isItemEnabledToBury = {};
    var fadeAll = function () {
        for (var i = 0; i < itemStats.length; i++) {
            var x = $("#" + id + "-img-" + i);
            if (x.length === 0) {
                continue;
            }
            var shouldBeFaded = !isItemEnabledToBury[i];
            var currentState = typeof x.css('opacity') === 'undefined' ? '1' : x.css('opacity');
            var isFaded = currentState === '0.25';
            var isCorrect = isFaded === shouldBeFaded;
            var neededOpacity = shouldBeFaded ? 0.25 : 1;
            if (!isCorrect) {
                x.fadeTo(500, neededOpacity);
            }
        }
    };
    var toggleAutoEnabled = function (i) {
        isItemEnabledToBury[i] = !isItemEnabledToBury[i];
        fadeAll();
    };
    var emptyObj = { media: 'assets/media/main/question.svg', name: '???' };
    var el = function (i) {
        var empty = itemStats[i].timesFound === 0;
        var _a = empty ? emptyObj : items[i], media = _a.media, name = _a.name;
        var e = $("<img id=\"" + id + "-img-" + i + "\" class=\"skill-icon-md js-tooltip-enable\" src=\"" + media + "\" data-toggle=\"tooltip\" data-html=\"true\" data-placement=\"bottom\" title=\"\" data-original-title=\"" + name + "\">");
        if (!empty) {
            e.on('click', function () { return toggleAutoEnabled(i); });
        }
        return e;
    };
    var autoBury = function () {
        for (var i = bank.length - 1; i >= 0; i--) {
            var itemID = bank[i].id;
            if (isItemEnabledToBury[itemID]) {
                var qty = SEMIUtils.getBankQty(itemID);
                SEMIUtils.buryItemWithoutConfirmation(itemID, qty);
                SEMIUtils.customNotify(items[itemID].media, "Burying " + numberWithCommas(qty) + " " + items[itemID].name + " for " + numberWithCommas(items[itemID].prayerPoints * qty) + " Prayer Points", { lowPriority: true });
            }
        }
    };
    var setupContainer = function () {
        $("#" + id + "-container").html('');
        for (var i = 0; i < itemStats.length; i++) {
            if (!('prayerPoints' in items[i])) {
                continue;
            }
            $("#" + id + "-container").append(el(i));
        }
        var loadedAutoEnabled = SEMI.getItem(id + "-config");
        if (loadedAutoEnabled !== null) {
            if (Array.isArray(loadedAutoEnabled)) {
                for (var i = 0; i < loadedAutoEnabled.length; i++) {
                    if (loadedAutoEnabled[i]) {
                        isItemEnabledToBury[i] = true;
                    }
                }
            }
            else {
                isItemEnabledToBury = loadedAutoEnabled;
            }
        }
        fadeAll();
    };
    var onDisable = function () {
        $("#" + id + "-status").addClass('btn-danger');
        $("#" + id + "-status").removeClass('btn-success');
    };
    var onEnable = function () {
        $("#" + id + "-status").addClass('btn-success');
        $("#" + id + "-status").removeClass('btn-danger');
    };
    var autoShow = function () {
        $("#modal-" + id).modal('show');
    };
    var injectGUI = function () {
        var x = $('#modal-item-log').clone().first();
        x.attr('id', "modal-" + id);
        $('#modal-item-log').parent().append(x);
        var y = $("#modal-" + id).children().children().children().children('.font-size-sm');
        y.children().children().attr('id', id + "-container");
        var enableAutoButton = $("<button class=\"btn btn-md btn-danger SEMI-modal-btn\" id=\"" + id + "-status\">Disabled</button>");
        enableAutoButton.on('click', function () { return SEMI.toggle("" + id); });
        y.before(enableAutoButton);
        var refreshLogBtn = $("<button type=\"button\" class=\"btn-block-option\" data-dismiss=\"modal\" aria-label=\"Close\">\n            <i class=\"fas fa-redo text-muted\" title=\"Refresh this log page to reflect your current bone log.\"></i>\n            </button>");
        refreshLogBtn.on('click', function () { return SEMI.refreshBoneLog(); });
        $("#" + id + "-status").parent().find('.fa.fa-fw.fa-times').parent().before(refreshLogBtn);
        $("#modal-" + id + " .block-title").text(title + " Menu");
        $("#modal-" + id).on('hidden.bs.modal', function () {
            SEMI.setItem(id + "-config", isItemEnabledToBury);
        });
        setupContainer();
        setTimeout(function () {
            $("#" + id + "-menu-button").on('click', autoShow);
            $("#" + id + "-menu-button").attr('href', null);
        }, 1000);
    };
    var refreshBoneLog = function () {
        $('.modal.show').find('.fa.fa-fw.fa-times').click();
        $("#modal-" + id).remove();
        injectGUI();
        $("#modal-" + id).modal('show');
        if (SEMI.isEnabled(id)) {
            $("#" + id + "-status").addClass('btn-success');
            $("#" + id + "-status").removeClass('btn-danger');
            $("#" + id + "-status").text('Enabled');
        }
    };
    SEMI.add(id, { onLoop: autoBury, onEnable: onEnable, onDisable: onDisable, title: title, desc: desc });
    SEMI.add(id + '-menu', { title: title, desc: desc, imgSrc: imgSrc, injectGUI: injectGUI });
    SEMIUtils.mergeOnto(SEMI, { refreshBoneLog: refreshBoneLog });
})();
