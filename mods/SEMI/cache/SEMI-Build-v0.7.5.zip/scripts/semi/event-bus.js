SEMIEventBus = (function () {
    var _addItemToBankHandlers = [];
    var RegisterAddItemToBankHandler = function (handler) {
        _addItemToBankHandlers.push(handler);
    };
    var _skillChangeHandlers = [];
    var RegisterSkillChangeHandler = function (handler) {
        _skillChangeHandlers.push(handler);
    };
    var _currentSkill = -1;
    var _isMagic = false;
    var TriggerSkillChanged = function () {
        var _prevSkill = _currentSkill;
        _currentSkill = SEMIUtils.currentSkillId();
        _isMagic = isMagic;
        for (var _i = 0, _skillChangeHandlers_1 = _skillChangeHandlers; _i < _skillChangeHandlers_1.length; _i++) {
            var handler = _skillChangeHandlers_1[_i];
            try {
                if (handler.HandleSkillChange) {
                    handler.HandleSkillChange(_prevSkill, _currentSkill);
                }
            }
            catch (e) {
                console.error("SEMI: SkillChangeHandler Failed.");
                console.error(e);
            }
        }
    };
    var checkIfSkillChanged = function () {
        if (SEMIUtils.currentSkillId() != _currentSkill || isMagic != _isMagic) {
            TriggerSkillChanged();
        }
    };
    var startEventBusTimers = function () {
        if (typeof SEMIUtils === 'undefined' || !SEMIUtils.utilsReady()) {
            return;
        }
        console.log('Starting Event Bus');
        clearInterval(eventBusWaiter);
        setInterval(checkIfSkillChanged, 100);
    };
    var eventBusWaiter = setInterval(startEventBusTimers, 50);
    var AddItemToBankPre = function (itemID, quantity, found, showNotification, ignoreBankSpace) {
        if (found === void 0) { found = true; }
        if (showNotification === void 0) { showNotification = true; }
        if (ignoreBankSpace === void 0) { ignoreBankSpace = false; }
        for (var _i = 0, _addItemToBankHandlers_1 = _addItemToBankHandlers; _i < _addItemToBankHandlers_1.length; _i++) {
            var handler = _addItemToBankHandlers_1[_i];
            try {
                if (handler.HandleAddItemToBankPre &&
                    handler.HandleAddItemToBankPre(itemID, quantity, found, showNotification, ignoreBankSpace)) {
                    return true;
                }
            }
            catch (e) {
                console.error("SEMI: ItemHandler Failed.");
                console.error(e);
            }
        }
    };
    var AddItemToBankPost = function (itemID, quantity, found, showNotification, ignoreBankSpace) {
        if (found === void 0) { found = true; }
        if (showNotification === void 0) { showNotification = true; }
        if (ignoreBankSpace === void 0) { ignoreBankSpace = false; }
        for (var _i = 0, _addItemToBankHandlers_2 = _addItemToBankHandlers; _i < _addItemToBankHandlers_2.length; _i++) {
            var handler = _addItemToBankHandlers_2[_i];
            try {
                if (handler.HandleAddItemToBankPost) {
                    handler.HandleAddItemToBankPost(itemID, quantity, found, showNotification, ignoreBankSpace);
                }
            }
            catch (e) {
                console.error("SEMI: ItemHandler Failed.");
                console.error(e);
            }
        }
    };
    return {
        AddItemToBankPost: AddItemToBankPost,
        AddItemToBankPre: AddItemToBankPre,
        RegisterAddItemToBankHandler: RegisterAddItemToBankHandler,
        RegisterSkillChangeHandler: RegisterSkillChangeHandler,
        TriggerSkillChanged: TriggerSkillChanged,
    };
})();
