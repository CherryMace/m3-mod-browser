var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
(function () {
    var id = 'auto-smith-bars';
    var title = 'AutoSmith Bars';
    var desc = 'AutoSmith Bars will cycle through your smithing bars and smelt those you have materials for.';
    var imgSrc = 'assets/media/bank/dragonite_bar.png';
    var skill = 'Smithing';
    var config = {
        ignoreIron: false,
    };
    var bars = __spreadArray([], __read(smithingBarRecipes.values()));
    var currentBar = 0;
    var moveToNext = function () {
        if (currentBar + 1 >= bars.length) {
            currentBar = 0;
        }
        else {
            currentBar += 1;
        }
        game.smithing.selectRecipeOnClick(currentBar);
    };
    var autoSmithBars = function () {
        smithingSelectionTabs.forEach(function (tab) {
            tab.hide();
        });
        smithingSelectionTabs[0].show();
        var ignoringIron = SEMI.getValue(id, 'ignoreIron') && items[bars[currentBar].itemID].name === 'Iron Bar';
        if (smithingArtisanMenu.noneSelected) {
            game.smithing.selectRecipeOnClick(0);
        }
        for (var _ in bars) {
            if (game.smithing.level < bars[currentBar].level || ignoringIron) {
                moveToNext();
            }
        }
        if (!SEMIUtils.isCurrentSkill(skill)) {
            game.smithing.start();
        }
    };
    var onDisable = function () {
        SEMIUtils.stopSkill(skill);
    };
    var hasConfig = true;
    var configMenu = "<div class=\"form-group\">\n        <div class=\"custom-control custom-switch mb-1\">\n            <input type=\"checkbox\" class=\"custom-control-input\" id=\"" + id + "-iron-toggle\" name=\"" + id + "-iron-toggle\">\n            <label class=\"custom-control-label\" for=\"" + id + "-iron-toggle\">\n                Ignore Iron (for Steel smelting)\n            </label>\n        </div>\n    </div>";
    var saveConfig = function () {
        var toggled = $("#" + id + "-iron-toggle").prop('checked');
        SEMI.setValue(id, 'ignoreIron', toggled);
        SEMI.setItem(id + "-config", SEMI.getValues(id));
        SEMIUtils.customNotify(imgSrc, 'AutoSmith Bars config saved!');
    };
    var updateConfig = function () {
        $("#" + id + "-iron-toggle").prop('checked', SEMI.getValue(id, 'ignoreIron'));
    };
    SEMI.add(id, {
        onLoop: autoSmithBars,
        onDisable: onDisable,
        config: config,
        hasConfig: hasConfig,
        configMenu: configMenu,
        saveConfig: saveConfig,
        updateConfig: updateConfig,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        skill: skill,
    });
})();
