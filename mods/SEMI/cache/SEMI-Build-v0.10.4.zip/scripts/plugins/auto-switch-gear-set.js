(function () {
    var id = 'auto-switch-gear-set';
    var title = 'Auto Switch Gear Set';
    var desc = 'Auto Switch Gear Set will switch your current gear set to match the combat style of the enemy you are currently facing. If you do not have valid sets equipped to swap to, exits combat. This does not care if you have no armor, so do have full sets on all slots.';
    var imgSrc = getItemMedia(CONSTANTS.item.Slayer_Helmet_Master);
    var isInCombat = function () { return combatManager.isInCombat; };
    var enemyStyle = function () { return combatManager.enemy.attackType; };
    var getSetAttackTypes = function () {
        return player.equipmentSets.map(function (x) { var _a; return (_a = x.slots['Weapon']) === null || _a === void 0 ? void 0 : _a.item.attackType; });
    };
    var getWantedSet = function () {
        var currentSets = getSetAttackTypes();
        if (enemyStyle() === 'magic') {
            return currentSets.indexOf('ranged');
        }
        if (enemyStyle() === 'ranged') {
            return currentSets.indexOf('melee');
        }
        if (enemyStyle() === 'melee') {
            return currentSets.indexOf('magic');
        }
    };
    var autoGearSwap = function () {
        if (!isInCombat()) {
            return;
        }
        var wantedSetIndex = getWantedSet();
        if (wantedSetIndex < 0) {
            SEMIUtils.customNotify(imgSrc, 'WARNING: You do not have a valid equipment set. Running from combat.');
            SEMIUtils.stopSkill('Hitpoints');
            return;
        }
        if (wantedSetIndex === player.selectedEquipmentSet) {
            return;
        }
        player.changeEquipmentSet(wantedSetIndex);
    };
    SEMI.add(id, {
        ms: 1000,
        onLoop: autoGearSwap,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
        title: title,
        imgSrc: imgSrc,
        desc: desc,
    });
})();
