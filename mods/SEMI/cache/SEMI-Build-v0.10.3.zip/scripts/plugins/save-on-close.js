(function () {
    var id = 'save-on-close';
    var title = 'Save On Close';
    var desc = "This script automatically cloud saves when leaving the page so you don't forget";
    var imgSrc = 'assets/media/bank/rune_mind.png';
    var forceCloudSave = function (event) {
        forceSync(false, false);
        event.returnValue = "Wait for cloud save to complete.";
    };
    var enableListener = function () {
        window.addEventListener('beforeunload', forceCloudSave);
    };
    var disableListener = function () {
        window.removeEventListener('beforeunload', forceCloudSave);
    };
    SEMI.add(id, {
        ms: 0,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        onEnable: enableListener,
        onDisable: disableListener,
    });
})();
