(function () {
    var pluginKind = 'open';
    var id = "auto-" + pluginKind;
    var title = 'AutoOpen';
    var desc = 'AutoOpen is a script for opening containers like chests.';
    var imgSrc = 'assets/media/bank/elite_chest.png';
    var isItemEnabledToOpen = {};
    var fadeAll = function () {
        for (var i = 0; i < SEMIUtils.itemsLength(); i++) {
            var x = $("#" + id + "-img-" + i);
            if (x.length === 0) {
                continue;
            }
            var shouldBeFaded = !isItemEnabledToOpen[i];
            var currentState = typeof x.css('opacity') === 'undefined' ? '1' : x.css('opacity');
            var isFaded = currentState === '0.25';
            var isCorrect = isFaded === shouldBeFaded;
            var neededOpacity = shouldBeFaded ? 0.25 : 1;
            if (!isCorrect) {
                x.fadeTo(500, neededOpacity);
            }
        }
    };
    var toggleAutoEnabled = function (i) {
        isItemEnabledToOpen[i] = !isItemEnabledToOpen[i];
        fadeAll();
    };
    var emptyObj = { media: 'assets/media/main/question.svg', name: '???' };
    var el = function (i) {
        var empty = !SEMIUtils.isItemFound(i);
        var _a = empty ? emptyObj : items[i], media = _a.media, name = _a.name;
        var e = $("<img id=\"" + id + "-img-" + i + "\" class=\"skill-icon-md js-tooltip-enable\" src=\"" + media + "\" data-toggle=\"tooltip\" data-html=\"true\" data-placement=\"bottom\" title=\"\" data-original-title=\"" + name + "\">");
        if (!empty) {
            e.on('click', function () { return toggleAutoEnabled(i); });
        }
        return e;
    };
    var autoOpen = function () {
        var allButOneIsEnabled = SEMI.getItem(id + "-sell-one");
        if (SEMIUtils.isBankFull()) {
            return;
        }
        for (var i = bank.length - 1; i >= 0; i--) {
            var itemID = bank[i].id;
            if (isItemEnabledToOpen[itemID]) {
                var qty = void 0;
                if (allButOneIsEnabled) {
                    qty = bank[i].qty - 1;
                }
                else {
                    qty = bank[i].qty;
                }
                if (!qty) {
                    continue;
                }
                SEMIUtils.openItemWithoutConfirmation(itemID, qty);
                SEMIUtils.customNotify(items[itemID].media, "Opening " + numberWithCommas(qty) + " of " + items[itemID].name, { lowPriority: true });
            }
        }
    };
    var setupContainer = function () {
        $("#" + id + "-container").html('');
        for (var i = 0; i < SEMIUtils.itemsLength(); i++) {
            if (!('dropQty' in items[i])) {
                continue;
            }
            $("#" + id + "-container").append(el(i));
        }
        var loadedAutoEnabled = SEMI.getItem(id + "-config");
        if (loadedAutoEnabled !== null) {
            if (Array.isArray(loadedAutoEnabled)) {
                for (var i = 0; i < loadedAutoEnabled.length; i++) {
                    if (loadedAutoEnabled[i]) {
                        isItemEnabledToOpen[i] = true;
                    }
                }
            }
            else {
                isItemEnabledToOpen = loadedAutoEnabled;
            }
        }
        fadeAll();
    };
    var onDisable = function () {
        $("#" + id + "-status").addClass('btn-danger');
        $("#" + id + "-status").removeClass('btn-success');
    };
    var onEnable = function () {
        $("#" + id + "-status").addClass('btn-success');
        $("#" + id + "-status").removeClass('btn-danger');
    };
    var autoShow = function () {
        $("#modal-" + id).modal('show');
    };
    var allButOneToggle = function () {
        var allButOneIsEnabled = SEMI.getItem(id + "-open-one");
        if (allButOneIsEnabled) {
            $("#" + id + "-open-one").addClass('btn-danger');
            $("#" + id + "-open-one").removeClass('btn-success');
        }
        else {
            $("#" + id + "-open-one").addClass('btn-success');
            $("#" + id + "-open-one").removeClass('btn-danger');
        }
        SEMI.setItem(id + "-sell-one", !allButOneIsEnabled);
    };
    var injectGUI = function () {
        var x = $('#modal-item-log').clone().first();
        x.attr('id', "modal-" + id);
        $('#modal-item-log').parent().append(x);
        var y = $("#modal-" + id).children().children().children().children('.font-size-sm');
        y.children().children().attr('id', id + "-container");
        var allButOne = SEMI.getItem(id + "-open-one");
        var controlSection = $("<div class=\"col-12\">\n                <div class=\"row\">\n                    <div class=\"col-2\">\n                        <button class=\"btn btn-md btn-danger SEMI-modal-btn\" id=\"" + id + "-status\">Disabled</button>\n                    </div>\n                    <div class=\"col-2\">\n                        <button class=\"btn btn-md btn-" + (allButOne ? 'success' : 'danger') + " SEMI-modal-btn\" id=\"" + id + "-open-one\">All But One</button>\n                    </div>\n                </div>\n            </div>");
        y.before(controlSection);
        var enableAutoButton = $("button#" + id + "-status");
        var enableAllButOneButton = $("button#" + id + "-open-one");
        enableAutoButton.on('click', function () { return SEMI.toggle("" + id); });
        enableAllButOneButton.on('click', function () { return allButOneToggle(); });
        $("#modal-" + id + " .block-title").text(title + " Menu");
        $("#modal-" + id).on('hidden.bs.modal', function () {
            SEMI.setItem(id + "-config", isItemEnabledToOpen);
        });
        setupContainer();
        setTimeout(function () {
            $("#" + id + "-menu-button").on('click', autoShow);
            $("#" + id + "-menu-button").attr('href', null);
        }, 1000);
    };
    SEMI.add(id, { ms: 2000, onLoop: autoOpen, onEnable: onEnable, onDisable: onDisable, title: title, desc: desc });
    SEMI.add(id + '-menu', { title: title, desc: desc, imgSrc: imgSrc, injectGUI: injectGUI });
})();
