var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
(function () {
    var pluginKind = 'slayer-skip';
    var id = "auto-" + pluginKind;
    var title = 'AS AutoSkip';
    var desc = 'This script option for AutoSlayer will fight all monsters selected in this menu provided that the related option is enabled in AutoSlayer. Since v0.18 it will select a new slayer task in the same tier.';
    var imgSrc = 'assets/media/monsters/m13.svg';
    var showHiddenMonsters = false;
    var autoEnabled = [];
    var getNeededOpacity = function (monsterId) {
        return autoEnabled[monsterId] ? 0.25 : 1;
    };
    var toggleAutoEnabled = function (monsterId) {
        autoEnabled[monsterId] = !autoEnabled[monsterId];
        $("#" + id + "-img-" + monsterId).fadeTo(500, getNeededOpacity(monsterId));
    };
    var emptyObj = { media: 'assets/media/main/question.svg', name: '???' };
    var createImg = function (monsterId) {
        var empty = !SEMIUtils.isMonsterKilled(monsterId) && !showHiddenMonsters;
        var _a = empty ? emptyObj : MONSTERS[monsterId], media = _a.media, name = _a.name;
        var e = $("<img id=\"" + id + "-img-" + monsterId + "\" class=\"skill-icon-md\" src=\"" + media + "\" data-tippy-content=\"" + name + "\" data-tippy-placement=\"bottom\" style=\"opacity: " + getNeededOpacity(monsterId) + ";\">");
        if (!empty) {
            e.on('click', function () { return toggleAutoEnabled(monsterId); });
        }
        return e;
    };
    var doAll = function () {
        monsterIDs = autoEnabled.flatMap(function (enabled, i) { return (enabled ? i : []); });
        SEMI.setItem('ASS-monsterIDs', monsterIDs);
    };
    var setupContainer = function () {
        $("#" + id + "-container [data-tippy-content]").each(function (_, e) { return e._tippy.destroy(); });
        $("#" + id + "-container").html('');
        var monsterOrder = combatAreaDisplayOrder
            .flatMap(function (area) { return combatAreas[area].monsters; })
            .concat(slayerAreaDisplayOrder.flatMap(function (area) { return slayerAreas[area].monsters; }));
        var getMonsterSortOrder = function (monster) {
            var idx = monsterOrder.indexOf(monster);
            if (idx === -1) {
                return Infinity;
            }
            return idx;
        };
        var slayerTasks = MONSTERS.map(function (monster, id) { return [monster, id]; })
            .filter(function (_a) {
            var _b = __read(_a, 2), monster = _b[0], id = _b[1];
            return monster.canSlayer;
        })
            .map(function (_a) {
            var _b = __read(_a, 2), monster = _b[0], id = _b[1];
            return id;
        })
            .sort(function (a, b) { return getMonsterSortOrder(a) - getMonsterSortOrder(b); });
        for (var i = 0; i < slayerTasks.length; i++) {
            $("#" + id + "-container").append(createImg(slayerTasks[i]));
        }
        tippy("#" + id + "-container [data-tippy-content]", { animation: false });
    };
    var onDisable = function () {
        $("#" + id + "-menu-status").attr('class', 'fas fa-times text-danger');
    };
    var onEnable = function () {
        $("#" + id + "-menu-status").attr('class', 'fas fa-check text-success');
    };
    var autoShow = function () {
        $("#modal-" + id).modal('show');
    };
    var injectGUI = function () {
        autoEnabled = Array(MONSTERS.length).fill(false);
        var loadedAutoEnabled = SEMI.getItem(id + "-config");
        if (loadedAutoEnabled !== null) {
            autoEnabled = __spreadArray([], __read(loadedAutoEnabled));
        }
        var modal = $('#modal-monster-log').clone().first();
        modal.attr('id', "modal-" + id);
        $('#modal-monster-log').parent().append(modal);
        var y = modal.children().children().children().children('.font-size-sm');
        y.children().children().attr('id', id + "-container");
        var toggleHiddenMonsters = $("<button type=\"button\" class=\"btn-block-option\"><i class=\"far fa-eye\" title=\"Show hidden monsters\"></i></button>").on('click', function () {
            showHiddenMonsters = !showHiddenMonsters;
            setupContainer();
        });
        var refreshLogBtn = $("<button type=\"button\" class=\"btn-block-option\" aria-label=\"Refresh\">\n            <i class=\"fas fa-redo text-muted\" title=\"Refresh this log page to reflect your current monster log.\"></i>\n            </button>");
        refreshLogBtn.on('click', function () { return setupContainer(); });
        modal.find('.block-options').prepend(refreshLogBtn).prepend(toggleHiddenMonsters);
        modal.find('.block-title').text(title + " Menu");
        modal.find('#toggleMonsters').remove();
        modal.on('hidden.bs.modal', function () {
            SEMI.setItem(id + "-config", autoEnabled);
        });
        setupContainer();
        setTimeout(function () {
            $("#" + id + "-menu-button").on('click', autoShow);
            $("#" + id + "-menu-button").attr('href', null);
        }, 1000);
    };
    SEMI.add(id, {
        onLoop: doAll,
        onEnable: onEnable,
        onDisable: onDisable,
        title: title,
        desc: desc,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
        skill: 'Slayer',
    });
    SEMI.add(id + '-menu', {
        title: title + ' Menu',
        desc: desc,
        imgSrc: imgSrc,
        injectGUI: injectGUI,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
    });
})();
