(function () {
    var id = 'auto-loot';
    var title = 'AutoLoot';
    var desc = 'Self-splanatory. :)';
    var imgSrc = 'assets/media/main/bank_header.svg';
    SEMI.add(id, {
        ms: 500,
        imgSrc: imgSrc,
        onLoop: function () {
            if (player.manager.loot.drops.length !== 0)
                player.manager.loot.lootAll();
        },
        desc: desc,
        title: title,
        pluginType: SEMI.PLUGIN_TYPE.AUTO_COMBAT,
    });
})();
