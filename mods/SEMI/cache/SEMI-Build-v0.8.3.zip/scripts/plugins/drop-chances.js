var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
(function () {
    var id = 'drop-chances';
    var title = 'Show % Drop Chances';
    var desc = 'This script injects into the drop chances menu and displays the % chance of receiving any item in the table. Also shows average GP values';
    var imgSrc = getItemMedia(CONSTANTS.item.Crate_Of_Basic_Supplies);
    var dropChances = function () {
        window.viewMonsterDrops = function (monsterID) {
            if (monsterID === -1)
                monsterID = player.manager.enemy.data.id;
            if (monsterID >= 0 && MONSTERS[monsterID].lootTable !== undefined) {
                var drops = '';
                var dropsOrdered = [];
                var totalWeight = MONSTERS[monsterID].lootTable.reduce(function (sum, a) { return sum + a[1]; }, 0);
                if (MONSTERS[monsterID].lootChance != undefined) {
                    totalWeight = (totalWeight * 100) / MONSTERS[monsterID].lootChance;
                }
                for (var i = 0; i < MONSTERS[monsterID].lootTable.length; i++) {
                    dropsOrdered.push({
                        itemID: MONSTERS[monsterID].lootTable[i][0],
                        w: MONSTERS[monsterID].lootTable[i][1],
                        qty: MONSTERS[monsterID].lootTable[i][2],
                        chance: " (" + ((MONSTERS[monsterID].lootTable[i][1] / totalWeight) * 100).toPrecision(3) + "%)",
                    });
                }
                dropsOrdered.sort(function (a, b) {
                    return b.w - a.w;
                });
                for (var i = 0; i < dropsOrdered.length; i++) {
                    drops +=
                        'Up to ' +
                            dropsOrdered[i].qty +
                            ' x <img class="skill-icon-xs mr-2" src="' +
                            getItemMedia(dropsOrdered[i].itemID) +
                            '">' +
                            items[dropsOrdered[i].itemID].name +
                            dropsOrdered[i].chance +
                            '<br>';
                }
                var bones = '';
                if (MONSTERS[monsterID].bones !== -1)
                    bones =
                        'Always Drops:<br><small><img class="skill-icon-xs mr-2" src="' +
                            getItemMedia(MONSTERS[monsterID].bones) +
                            '">' +
                            items[MONSTERS[monsterID].bones].name +
                            '</small><br><br>';
                Swal.fire({
                    title: MONSTERS[monsterID].name,
                    html: bones + 'Possible Extra Drops:<br><small>In order of most common to least common<br>' + drops,
                    imageUrl: MONSTERS[monsterID].media,
                    imageWidth: 64,
                    imageHeight: 64,
                    imageAlt: MONSTERS[monsterID].name,
                });
            }
        };
        window.viewItemContents = function (itemID) {
            if (itemID === void 0) { itemID = -1; }
            if (itemID < 0)
                itemID = selectedBankItem;
            var drops = '';
            var dropsOrdered = [];
            var totalWeight = items[itemID].dropTable.reduce(function (sum, a) { return sum + a[1]; }, 0);
            for (var i = 0; i < items[itemID].dropTable.length; i++) {
                dropsOrdered.push({
                    itemID: items[itemID].dropTable[i][0],
                    w: items[itemID].dropTable[i][1],
                    id: i,
                    chance: " (" + ((items[itemID].dropTable[i][1] / totalWeight) * 100).toPrecision(3) + "%)",
                });
            }
            dropsOrdered.sort(function (a, b) {
                return b.w - a.w;
            });
            for (var i = 0; i < dropsOrdered.length; i++) {
                drops +=
                    'Up to ' +
                        numberWithCommas(items[itemID].dropQty[dropsOrdered[i].id]) +
                        ' x <img class="skill-icon-xs mr-2" src="' +
                        getItemMedia(dropsOrdered[i].itemID) +
                        '">' +
                        items[dropsOrdered[i].itemID].name +
                        dropsOrdered[i].chance +
                        '<br>';
            }
            Swal.fire({
                title: items[itemID].name,
                html: 'Possible Items:<br><small>' + drops,
                imageUrl: getItemMedia(itemID),
                imageWidth: 64,
                imageHeight: 64,
                imageAlt: items[itemID].name,
            });
        };
        thievingMenu.showNPCDrops = function (npc, area) {
            var sortedTable = __spreadArray([], __read(npc.lootTable)).sort(function (_a, _b) {
                var _c = __read(_a, 3), itemID = _c[0], weight = _c[1], maxQty = _c[2];
                var _d = __read(_b, 3), itemID2 = _d[0], weight2 = _d[1], maxQty2 = _d[2];
                return weight2 - weight;
            });
            var _a = game.thieving.getNPCGPRange(npc), minGP = _a.minGP, maxGP = _a.maxGP;
            var html = "<small><img class=\"skill-icon-xs mr-2\" src=\"" + cdnMedia('assets/media/main/coins.svg') + "\"> " + formatNumber(minGP) + "-" + formatNumber(maxGP) + " GP</small><br>";
            html += 'Possible Common Drops:<br><small>';
            if (sortedTable.length) {
                html += "In order of most to least common<br>";
                var totalWeight_1 = game.getLootTableWeight(npc.lootTable);
                html += sortedTable
                    .map(function (_a) {
                    var _b = __read(_a, 3), itemID = _b[0], weight = _b[1], maxQty = _b[2];
                    var text = "" + (maxQty > 1 ? '1-' : '') + maxQty + " x <img class=\"skill-icon-xs mr-2\" src=\"" + getItemMedia(itemID) + "\">" + items[itemID].name;
                    text += " (" + ((100 * weight) / totalWeight_1).toFixed(2) + "%)";
                    return text;
                })
                    .join('<br>');
                html += "<br>Average Value: " + game.getLootTableAverageGP(npc.lootTable).toFixed(2) + " GP<br>";
            }
            else {
                html += 'This NPC doesn&apos;t have any Common Drops';
            }
            html += "</small><br>";
            html += "Possible Rare Drops:<br><small>";
            html += Thieving.generalRareItems
                .map(function (_a) {
                var itemID = _a.itemID;
                return thievingMenu.formatSpecialDrop(items[itemID], 'rare');
            })
                .join('<br>');
            html += "</small><br>";
            if (area.uniqueDrops.length) {
                html += "Possible Area Unique Drops:<br><small>";
                html += area.uniqueDrops
                    .map(function (drop) { return thievingMenu.formatSpecialDrop(items[drop.itemID], 'area', drop.qty); })
                    .join('<br>');
                html += '</small><br>';
            }
            if (npc.uniqueDrop.itemID !== -1) {
                html += "Possible NPC Unique Drop:<br><small>" + thievingMenu.formatSpecialDrop(items[npc.uniqueDrop.itemID], 'npc', npc.uniqueDrop.qty) + "</small>";
            }
            Swal.fire({
                title: npc.name,
                html: html,
                imageUrl: npc.media,
                imageWidth: 64,
                imageHeight: 64,
                imageAlt: npc.name,
            });
        };
        thievingMenu.formatSpecialDrop = function (item, type, qty) {
            var _a;
            if (qty === void 0) { qty = 1; }
            var found = itemStats[item.id].stats[Stats.TimesFound];
            var media = found ? getItemMedia(item.id) : cdnMedia('assets/media/main/question.svg');
            var name = found ? item.name : 'Undiscovered Item';
            var specialDropChance = 0;
            switch (type) {
                case 'rare':
                    specialDropChance = (_a = Thieving.generalRareItems.filter(function (x) { return x.itemID == item.id; })[0]) === null || _a === void 0 ? void 0 : _a.chance;
                    break;
                case 'area':
                    var chanceMult = game.thieving.isPoolTierActive(3) ? 3 : 1;
                    specialDropChance = game.thieving.areaUniqueChance * chanceMult;
                    break;
                case 'npc':
                    specialDropChance = game.thieving.pickpocket;
                    break;
                default:
                    console.log('Drop Chances Error');
            }
            return formatNumber(qty) + " x <img class=\"skill-icon-xs mr-2\" src=\"" + media + "\">" + name + " (" + specialDropChance.toFixed(3) + "%)";
        };
    };
    var loadCheckInterval = setInterval(function () {
        if (isLoaded) {
            clearInterval(loadCheckInterval);
            dropChances();
        }
    }, 200);
    SEMI.add(id, {
        ms: 0,
        pluginType: SEMI.PLUGIN_TYPE.TWEAK,
        title: title,
        desc: desc,
        imgSrc: imgSrc,
        onEnable: dropChances,
    });
})();
